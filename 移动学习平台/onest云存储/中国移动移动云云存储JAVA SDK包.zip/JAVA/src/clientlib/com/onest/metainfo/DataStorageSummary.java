
package com.onest.metainfo;

public class DataStorageSummary{

	private long totalSpace;
	private long usedSpace;
	private int rackId;
	private int datanodeStatus;
	private int cpuRate;
	private int memRate;
	private int flushIoRate;
	private int fsRate;
	private String clusterKey;
	private String hostName;
	private String clientListenAddr;
	private String metaNodeListenAddr;
	private long weight;
	
	public long getTotalSpace() {
		return totalSpace;
	}

	public void setTotalSpace(long totalSpace) {
		this.totalSpace = totalSpace;
	}

	public long getUsedSpace() {
		return usedSpace;
	}

	public void setUsedSpace(long usedSpace) {
		this.usedSpace = usedSpace;
	}
	
	public long getLeftSpace() {
		return totalSpace - usedSpace;
	}
	
	public void setWeight(long weight)
	{
		this.weight = weight;
	}

	public long getWeight()
	{
		return weight ;
	}


	public int getRackId() {
		return rackId;
	}

	public void setRackId(int rackId) {
		this.rackId = rackId;
	}

	public String getClusterKey() {
		return clusterKey;
	}

	public void setClusterKey(String nClusterKey) {
		this.clusterKey = nClusterKey;
	}

	public int getDatanodeStatus() {
		return datanodeStatus;
	}

	public void setDatanodeStatus(int datanodeStatus) {
		this.datanodeStatus = datanodeStatus;
	}

	public int getCpuRate() {
		return cpuRate;
	}

	public void setCpuRate(int cpuRate) {
		this.cpuRate = cpuRate;
	}

	public int getMemRate() {
		return memRate;
	}

	public void setMemRate(int memRate) {
		this.memRate = memRate;
	}

	public int getFlushIoRate() {
		return flushIoRate;
	}

	public void setFlushIoRate(int flushIoRate) {
		this.flushIoRate = flushIoRate;
	}

	public int getFsRate() {
		return fsRate;
	}

	public void setFsRate(int fsRate) {
		this.fsRate = fsRate;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getClientListenAddr() {
		return clientListenAddr;
	}

	public void setClientListenAddr(String clientListenAddr) {
		this.clientListenAddr = clientListenAddr;
	}

	public String getMetaNodeListenAddr() {
		return metaNodeListenAddr;
	}

	public void setMetaNodeListenAddr(String metaNodeListenAddr) {
		this.metaNodeListenAddr = metaNodeListenAddr;
	}
	
	public String toString(){
		
		StringBuffer sb = new StringBuffer();
		sb.append("totalSpace=").append(totalSpace);
		return sb.toString();
	}
}