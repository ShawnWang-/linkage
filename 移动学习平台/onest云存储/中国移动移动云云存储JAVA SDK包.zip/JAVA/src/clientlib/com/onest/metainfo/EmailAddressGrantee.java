package com.onest.metainfo;


/**
 * Represents an e-mail grantee.  An e-mail grantee is a grantee 
 * identified by their e-mail
 * address and authenticated by an Onest system.
 * <p>
 * E-mail grants are internally converted to the canonical user representation
 * when creating the ACL. If the grantee changes their e-mail address, it
 * will not affect existing Onest permissions.
 * </p>
 * <p>
 * Adding a grantee by e-mail address only works if exactly one Onest account
 * corresponds to the specified e-mail address. If multiple Onest accounts are
 * associated with the e-mail address, an <code>AmbiguousGrantByEmail</code> 
 * error message is
 * returned. This happens rarely, but usually occurs if a user created 
 * an Onest account
 * in the past, forgotten the password, and created another Onest account using
 * the same e-mail address. If this occurs, the user should contact Onest 
 * customer service to have the accounts merged.
 * Alernatively, grant user access
 * specifying the canonical user representation.
 * </p>
 * 
 * @see EmailAddressGrantee#EmailAddressGrantee(String)
 */
public class EmailAddressGrantee implements Grantee {

    private String emailAddress = null;

    /**
     * Constructs a new {@link EmailAddressGrantee} object
     * with the given email address.
     *
     * @param emailAddress
     *        The e-mail address used to identify the e-mail grantee.
     */
    public EmailAddressGrantee(String emailAddress) {
        this.setIdentifier(emailAddress);
    }

    /**
     * Set the e-mail address as the grantee's ID.
     * 
     * @param emailAddress
     *        The e-mail address used to identify the e-mail grantee.
     *        
     * @see EmailAddressGrantee#getIdentifier()       
     */
    public void setIdentifier(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * Gets the grantee's e-mail address.
     * 
     * @see EmailAddressGrantee#setIdentifier(string)     
     */
    public String getIdentifier() {
        return emailAddress;
    }

    public boolean equals(Object obj) {
        if (obj instanceof EmailAddressGrantee) {
            return emailAddress.equals(((EmailAddressGrantee)obj).emailAddress);
        }
        return false;
    }

    public int hashCode() {
        return emailAddress.hashCode();
    }


}
