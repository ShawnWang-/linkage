package com.onest.handlers;

import com.onest.http.HttpResponse;
import com.onest.metainfo.Headers;
import com.onest.util.Unmarshallers;
import com.onest.util.XmlResponsesSaxParser.CopyObjectResultHandler;

/**
 * Custom response handler for the CopyObject operation. Handling this response
 * is slightly different from other responses since it involves combining
 * information from the XML payload in the response with information from the
 * HTTP response headers (version ID).
 */
public class CopyObjectResponseHandler extends
		OnestXmlResponseHandler<CopyObjectResultHandler> {
    public CopyObjectResponseHandler() {
        super(new Unmarshallers.CopyObjectUnmarshaller());
    }

    /* (non-Javadoc)
     * @see com.onest.handlers.OnestXmlResponseHandler#handle(com.onest.response.HttpResponse)
     */
    @Override
    public OnestWebServiceResponse<CopyObjectResultHandler> handle(HttpResponse response) throws Exception {
        /*
         * TODO: Might be nice to handle the rest of CopyObject's custom logic
         *       here, instead of in the OnestClient. We could detect an error
         *       XML response and throw the exception, otherwise just return the
         *       fully populated CopyObjectResult object.
         */
        OnestWebServiceResponse<CopyObjectResultHandler> onestResponse = super.handle(response);
        CopyObjectResultHandler copyObjectResultHandler = onestResponse.getResult();
        if (copyObjectResultHandler != null) {
            copyObjectResultHandler.setVersionId(response.getHeaders().get(Headers.ONEST_VERSION_ID));
        }

        return onestResponse;
    }
}
