package com.onest.handlers;

import com.onest.request.Request;

/**
 * Interface for addition request handling in clients. A request handler is
 * executed on a request object <b>before</b> it is sent to the client runtime
 * to be executed.
 */
public interface RequestHandler {
	 /**
     * Runs any additional processing logic on the specified request (before it
     * is executed by the client runtime), then hands back the updated request
     * object.
     * 
     * @param <T>
     *            Indicates the parameterized type of the request being
     *            processed by this handler.
     * 
     * @param request
     *            The request being processed by this handler.
     * 
     * @return The updated request object.
     */
    public <T> Request<T> handleRequest(Request<T> request);
}
