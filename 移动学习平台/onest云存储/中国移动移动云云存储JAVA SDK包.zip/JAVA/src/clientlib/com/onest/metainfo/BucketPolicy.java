package com.onest.metainfo;


/**
 * <p>
 * Represents a Onest bucket policy.
 * Bucket policies provide access control management at the bucket level for
 * both the bucket resource and contained object resources. Only one policy may
 * be specified per bucket.
 * </p>
 * <p>
 * Buckets have no policy text until one is explicitly specified. 
 * Requesting the bucket policy for a newly created bucket will return a
 * policy object with <code>null</code> policy text.
 * </p>
 */
public class BucketPolicy {
    /** The raw, policy JSON text, as returned by Onest */
    private String policyText;

    /**
     * Gets the raw policy JSON text as returned by Onest. If no policy
     * has been applied to the specified bucket, the policy text will be
     * null.
     * 
     * @return The raw policy JSON text as returned by Onest.
     *         If no policy has been applied to the specified bucket, this method returns
     *         null policy text.
     *         
     * @see BucketPolicy#setPolicyText()        
     */
    public String getPolicyText() {
        return policyText;
    }

    /**
     * Sets the raw policy JSON text. 
     * A bucket will have no policy text unless the policy text is explicitly
     * provided through this method.
     *
     * @param policyText
     *            The raw policy JSON text.
     *            
     * @see BucketPolicy#getPolicyText()           
     */
    public void setPolicyText(String policyText) {
        this.policyText = policyText;
    }
}
