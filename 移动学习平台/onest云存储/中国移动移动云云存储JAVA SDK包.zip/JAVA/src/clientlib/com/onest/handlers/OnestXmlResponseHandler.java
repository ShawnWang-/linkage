package com.onest.handlers;

import java.io.InputStream;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.onest.http.HttpResponse;
import com.onest.util.Unmarshaller;

/**
 * Onest Implementation of HttpResponseHandler. Relies on a SAX unmarshaller for
 * handling the response.
 */
public class OnestXmlResponseHandler<T> extends AbstractOnestResponseHandler<T> {
    /** The SAX unmarshaller to use when handling the response from Onest */
    private Unmarshaller<T, InputStream> responseUnmarshaller;

    /** Shared logger for profiling information */
    private static final Log log = LogFactory.getLog("com.onest");

    /** Response headers from the processed response */
    private Map<String, String> responseHeaders;

    /**
     * Constructs a new Onest response handler that will use the specified SAX
     * unmarshaller to turn the response into an object.
     *
     * @param responseUnmarshaller
     *            The SAX unmarshaller to use on the response from Onest.
     */
    public OnestXmlResponseHandler(Unmarshaller<T, InputStream> responseUnmarshaller) {
        this.responseUnmarshaller = responseUnmarshaller;
    }

    /**
     * @see com.onest.handlers.HttpResponseHandler#handle(com.onest.http.HttpResponse)
     */
    public OnestWebServiceResponse<T> handle(HttpResponse response) throws Exception {
        OnestWebServiceResponse<T> onestResponse = parseResponseMetadata(response);
        responseHeaders = response.getHeaders();

        if (responseUnmarshaller != null) {
            log.trace("Beginning to parse service response XML");
            T result = responseUnmarshaller.unmarshall(response.getContent());
            log.trace("Done parsing service response XML");
            onestResponse.setResult(result);
        }

        return onestResponse;
    }

    /**
     * Returns the headers from the processed response. Will return null until a
     * response has been handled.
     *
     * @return the headers from the processed response.
     */
    public Map<String, String> getResponseHeaders() {
        return responseHeaders;
    }
}
