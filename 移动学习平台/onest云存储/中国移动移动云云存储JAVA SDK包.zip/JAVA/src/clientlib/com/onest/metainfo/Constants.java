package com.onest.metainfo;

public class Constants {
    /** Default hostname for the onest endpoint */
    public static String ONEST_HOSTNAME = "obs.chinamobile.com/onest";//"10.24.1.43:48080/onest";;

    /** Service name for Onest */
    public static String ONEST_SERVICE_NAME = "Onest";

    /** Default encoding used for text data */
    public static String DEFAULT_ENCODING = "UTF-8";

    /** HMAC/SHA1 Algorithm per RFC 2104, used when signing Onest requests */
    public static final String HMAC_SHA1_ALGORITHM = "HmacSHA1";

    /** XML namespace URL used when sending Onest requests containing XML */
    public static final String XML_NAMESPACE = "http://obs.chinamobile.com/doc/2012-03-05/";

    /** Represents a null Onest version ID */
    public static final String NULL_VERSION_ID = "null";

    /**
     * HTTP status code indicating that preconditions failed and thus the
     * request failed.
     */
    public static final int FAILED_PRECONDITION_STATUS_CODE = 412;

    /** Kilobytes */
    public static final int KB = 1024;

    /** Megabytes */
    public static final int MB = 1024 * KB;

    /** Gigabytes */
    public static final long GB = 1024 * MB;

    /** The maximum allowed parts in a multipart upload. */
    public static final int MAXIMUM_UPLOAD_PARTS = 10000;

    /**
     * The default size of the buffer when uploading data from a stream. A
     * buffer of this size will be created and filled with the first bytes from
     * a stream being uploaded so that any transmit errors that occur in that
     * section of the data can be automatically retried without the caller's
     * intervention.
     */
    public static final int DEFAULT_STREAM_BUFFER_SIZE = 128 * KB;
}
