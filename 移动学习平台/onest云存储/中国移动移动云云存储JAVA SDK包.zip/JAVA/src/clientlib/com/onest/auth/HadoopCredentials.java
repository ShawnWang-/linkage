package com.onest.auth;

import java.net.URI;

import org.apache.hadoop.conf.Configuration;

public class HadoopCredentials implements OnestCredentials {
  
	  private String accessID;
	  private String accessSecretKey; 

	  /**
	   * @throws IllegalArgumentException if credentials for Onest cannot be
	   * determined.
	   */
	  public void initialize(URI uri, Configuration conf) {
	    if (uri.getHost() == null) {
	      throw new IllegalArgumentException("Invalid hostname in URI " + uri);
	    }
	    
	    String userInfo = uri.getUserInfo();
	    if (userInfo != null) {
	      int index = userInfo.indexOf(':');
	      if (index != -1) {
	        accessID = userInfo.substring(0, index);
	        accessSecretKey = userInfo.substring(index + 1);
	      } else {
	        accessID = userInfo;
	      }
	    }
	    
	    String scheme = uri.getScheme();
	    String accessKeyProperty = String.format("fs.%s.onestAccessKeyId", scheme);
	    String secretAccessKeyProperty =
	      String.format("fs.%s.onestSecretAccessKey", scheme);
	    if (accessID == null) {
	      accessID = conf.get(accessKeyProperty);
	    }
	    if (accessSecretKey == null) {
	      accessSecretKey = conf.get(secretAccessKeyProperty);
	    }
	    if (accessID == null && accessSecretKey == null) {
	      throw new IllegalArgumentException("Onest " +
	                                         "Access Key ID and Secret Access " +
	                                         "Key must be specified as the " +
	                                         "username or password " +
	                                         "(respectively) of a " + scheme +
	                                         " URL, or by setting the " +
	                                         accessKeyProperty + " or " +
	                                         secretAccessKeyProperty +
	                                         " properties (respectively).");
	    } else if (accessID == null) {
	      throw new IllegalArgumentException("Onest" +
	                                         "Access Key ID must be specified " +
	                                         "as the username of a " + scheme +
	                                         " URL, or by setting the " +
	                                         accessKeyProperty + " property.");
	    } else if (accessSecretKey == null) {
	      throw new IllegalArgumentException("Onest " +
	                                         "Secret Access Key must be " +
	                                         "specified as the password of a " +
	                                         scheme + " URL, or by setting the " +
	                                         secretAccessKeyProperty +
	                                         " property.");       
	    }

	  }
	  
	
	@Override
	public String getOnestAccessID() {
		// TODO Auto-generated method stub
		return accessID;
	}
	
	@Override
	public String getOnestAccessSecretKey() {
		// TODO Auto-generated method stub
		return accessSecretKey;
	}

}
