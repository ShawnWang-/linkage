/**
 * 
 */
package com.onest.client;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.onest.auth.*;
import com.onest.client.OnestServiceException.ErrorType;
import com.onest.handlers.*;
import com.onest.http.*;
import com.onest.metainfo.AccessControlList;
import com.onest.metainfo.AzNeInfoList;
import com.onest.metainfo.Bucket;
import com.onest.metainfo.BucketPolicy;
import com.onest.metainfo.BucketStat;
import com.onest.metainfo.CannedAccessControlList;
import com.onest.metainfo.CompleteMultipartUploadResult;
import com.onest.metainfo.Constants;
import com.onest.metainfo.CopyObjectResult;
import com.onest.metainfo.GroupGrantee;
import com.onest.metainfo.Headers;
import com.onest.metainfo.InitiateMultipartUploadResult;
import com.onest.metainfo.Mimetypes;
import com.onest.metainfo.MultipartUploadListing;
import com.onest.metainfo.ObjectListing;
import com.onest.metainfo.ObjectMetadata;
import com.onest.metainfo.OnestObject;
import com.onest.metainfo.OnestResponseMetadata;
import com.onest.metainfo.Owner;
import com.onest.metainfo.PartListing;
import com.onest.metainfo.Permission;
import com.onest.metainfo.ProgressEvent;
import com.onest.metainfo.PutObjectResult;
import com.onest.metainfo.Region;
import com.onest.metainfo.StorageClass;
import com.onest.metainfo.UploadPartResult;
import com.onest.metainfo.UserSpaceStat;
import com.onest.metainfo.VersionListing;
import com.onest.request.AbortMultipartUploadRequest;
import com.onest.request.CheckObjectReadAclRequest;
import com.onest.request.CompleteMultipartUploadRequest;
import com.onest.request.CopyObjectRequest;
import com.onest.request.CreateBucketRequest;
import com.onest.request.CreateGetBucketStatRequest;
import com.onest.request.CreateGetLocationRequest;
import com.onest.request.CreateGetUserStatRequest;
import com.onest.request.DefaultRequest;
import com.onest.request.DeleteBucketRequest;
import com.onest.request.DeleteObjectRequest;
import com.onest.request.DeleteVersionRequest;
import com.onest.request.GeneratePresignedUrlRequest;
import com.onest.request.GetObjectAccessUrlRequest;
import com.onest.request.GetObjectMetadataRequest;
import com.onest.request.GetObjectRequest;
import com.onest.request.InitiateMultipartUploadRequest;
import com.onest.request.ListAzNeInfoRequest;
import com.onest.request.ListBucketsRequest;
import com.onest.request.ListMultipartUploadsRequest;
import com.onest.request.ListObjectsRequest;
import com.onest.request.ListPartsRequest;
import com.onest.request.ListVersionsRequest;
import com.onest.request.OnestWebServiceRequest;
import com.onest.request.PutObjectRequest;
import com.onest.request.Request;
import com.onest.request.SetBucketLoggingConfigurationRequest;
import com.onest.request.SetBucketVersioningConfigurationRequest;
import com.onest.request.UploadPartRequest;
import com.onest.util.*;
import com.onest.util.XmlResponsesSaxParser.CompleteMultipartUploadHandler;
import com.onest.util.XmlResponsesSaxParser.CopyObjectResultHandler;


/**
 * <p>
 * Provides the client for accessing the Onest web service.
 * </p>
 * <p>
 * Onest provides storage for the Internet,
 * and is designed to make web-scale computing easier for developers.
 * </p>
 * <p>
 * The Onest Java SDK provides a simple interface that can be
 * used to store and retrieve any amount of data, at any time,
 * from anywhere on the web. It gives any developer access to the same
 * highly scalable, reliable, secure, fast, inexpensive infrastructure
 * that Onest uses to run its own global network of web sites.
 * The service aims to maximize benefits of scale and to pass those
 * benefits on to developers.
 * </p>
 */
public class OnestClient extends OnestWebServiceClient implements Onest {
	/** Shared logger for client events */
    private static Log log = LogFactory.getLog(OnestClient.class);	
    
    /**
     * The Onest credentials (access key ID and secret key) to use when
     * authenticating with Onest services.
     */
    private OnestCredentials onestCredentials;

    private boolean bAnonymousUser = false;
    
    private String userName;

    /**
     * Low level client for sending requests to Onest services.
     */
    protected final HttpClient client;

    /**
     * Optional request handlers for additional request processing.
     */
    private List<RequestHandler> requestHandlers = new ArrayList<RequestHandler>();

    /**
     * Responsible for handling error responses from all Onest service calls.
     */
    private OnestErrorResponseHandler errorResponseHandler =
        new OnestErrorResponseHandler();

    /**
     * Shared response handler for operations that don't need to unmarshall
     * anything.
     */
    private OnestXmlResponseHandler<Void> voidResponseHandler =
        new OnestXmlResponseHandler<Void>(null);

    /** Utilities for validating bucket names */
    private final BucketNameUtils bucketNameUtils = new BucketNameUtils();

    /** Shared factory for converting configuration objects to XML */
    private static final BucketConfigurationXmlFactory bucketConfigurationXmlFactory = new BucketConfigurationXmlFactory();


    /**
     * <p>
     * Constructs a new Onest client that will make <b>anonymous</b>
     * requests to Onest.
     * </p>
     * <p>
     * Only a subset of the Onest API will work with anonymous
     * (i.e. unsigned) requests, but this can prove useful in some situations.
     * For example:
     * <ul>
     * 	<li>If an Onest bucket has {@link Permission#Read} permission for the
     * 	{@link GroupGrantee#AllUsers} group, anonymous clients can call
     * 	{@link #listObjects(String)} to see what objects are stored in a bucket.</li>
     * 	<li>If an object has {@link Permission#Read} permission for the
     * 	{@link GroupGrantee#AllUsers} group, anonymous clients can call
     * 	{@link #getObject(String, String)} and
     * 	{@link #getObjectMetadata(String, String)} to pull object content and
     * 	metadata.</li>
     * 	<li>If a bucket has {@link Permission#Write} permission for the
     * 	{@link GroupGrantee#AllUsers} group, anonymous clients can upload objects
     * 	to the bucket.</li>
     * </ul>
     * </p>
     *
     * @see OnestClient#OnestClient(OnestCredentials)
     * @see OnestClient#OnestClient(OnestCredentials, ClientConfiguration)
     */
    public OnestClient() {
        this(null,"","");
    }

    public OnestClient(String hostName) {
        this(null,"",hostName);
    }
    
    public OnestClient(String userName, String hostName) {
        this(null, userName, hostName);
    }
    
    /**
     * <p>
     * Constructs a new Onest client using the specified Onest credentials to
     * access Onest.
     * </p>
     *
     * @param onestCredentials
     *            The Onest credentials to use when making requests to Onest
     *            with this client.
     *
     * @see OnestClient#OnestClient()
     * @see OnestClient#OnestClient(OnestCredentials, ClientConfiguration)
     */
    public OnestClient(OnestCredentials onestCredentials, String userName, String hostName) {
        this(onestCredentials, new ClientConfiguration(), userName, hostName);
    }

    public OnestClient(OnestCredentials onestCredentials, String hostName) {
        this(onestCredentials, new ClientConfiguration(), "", hostName);
    }
    
    public OnestClient(OnestCredentials onestCredentials, ClientConfiguration clientConfiguration) {
        this(onestCredentials, new ClientConfiguration(), "", "");
    }
   
    /**
     * <p>
     * Constructs a new Onest client using the specified Onest credentials and
     * client configuration to access Onest.
     * </p>
     *
     * @param OnestCredentials
     *            The Onest credentials to use when making requests to Onest
     *            with this client.
     * @param clientConfiguration
     *            The client configuration options controlling how this client
     *            connects to Onest (e.g. proxy settings, retry counts, etc).
     *
     * @see OnestClient#OnestClient()
     * @see OnestClient#OnestClient(OnestCredentials)
     */
    public OnestClient(OnestCredentials onestCredentials, ClientConfiguration clientConfiguration,
    		String userName, String hostName) {
        super(clientConfiguration);
        this.onestCredentials = onestCredentials;
        this.userName = userName;
        if(hostName == ""){        
        	setEndpoint(Constants.ONEST_HOSTNAME);
        }
        else {
        	setEndpoint(hostName);
		}
        client = new HttpClient(clientConfiguration);

        requestHandlers = new HandlerChainFactory().newRequestHandlerChain(
                "/com/onest/client/request.handlers");
        
        
    }

    public String getUserName(){
    	return userName;
    }
    
    public void setUserName(String userName){
    	this.userName = userName;
    }
    
    public boolean getBAnonymousUser(){
    	return bAnonymousUser;
    }
    
    public void setBAnonymousUser(boolean bAnonymousUser){
    	this.bAnonymousUser = bAnonymousUser;
    }
    
    /* (non-Javadoc)
     * @see com.onest.client.Onest#listNextBatchOfVersions(com.meta.VersionListing)
     */
    public VersionListing listNextBatchOfVersions(VersionListing previousVersionListing)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(previousVersionListing,
            "The previous version listing parameter must be specified when listing the next batch of versions in a bucket");

        if (!previousVersionListing.isTruncated()) {
            VersionListing emptyListing = new VersionListing();
            emptyListing.setBucketName(previousVersionListing.getBucketName());
            emptyListing.setDelimiter(previousVersionListing.getDelimiter());
            emptyListing.setKeyMarker(previousVersionListing.getNextKeyMarker());
            emptyListing.setVersionIdMarker(previousVersionListing.getNextVersionIdMarker());
            emptyListing.setMaxKeys(previousVersionListing.getMaxKeys());
            emptyListing.setPrefix(previousVersionListing.getPrefix());
            emptyListing.setTruncated(false);

            return emptyListing;
        }

        return listVersions(new ListVersionsRequest(
                previousVersionListing.getBucketName(),
                previousVersionListing.getPrefix(),
                previousVersionListing.getNextKeyMarker(),
                previousVersionListing.getNextVersionIdMarker(),
                previousVersionListing.getDelimiter(),
                new Integer( previousVersionListing.getMaxKeys() ) ));
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#listVersions(java.lang.String, java.lang.String)
     */
    public VersionListing listVersions(String bucketName, String prefix)
            throws OnestClientException, OnestServiceException {
        return listVersions(new ListVersionsRequest(bucketName, prefix, null, null, null, null));
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#listVersions(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Integer)
     */
    public VersionListing listVersions(String bucketName, String prefix, String keyMarker, String versionIdMarker, String delimiter, Integer maxResult)
            throws OnestClientException, OnestServiceException {

        ListVersionsRequest request = new ListVersionsRequest()
            .withBucketName(bucketName)
            .withPrefix(prefix)
            .withDelimiter(delimiter)
            .withKeyMarker(keyMarker)
            .withVersionIdMarker(versionIdMarker)
            .withMaxResults(maxResult);
        return listVersions(request);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#listVersions(com.request.ListVersionsRequest)
     */
    public VersionListing listVersions(ListVersionsRequest listVersionsRequest)
            throws OnestClientException, OnestServiceException {
        String bucketName = listVersionsRequest.getBucketName();
        String prefix = listVersionsRequest.getPrefix();
        String keyMarker = listVersionsRequest.getKeyMarker();
        String versionIdMarker = listVersionsRequest.getVersionIdMarker();
        String delimiter = listVersionsRequest.getDelimiter();
        Integer maxResults = listVersionsRequest.getMaxResults();

        assertParameterNotNull(bucketName, "The bucket name parameter must be specified when listing versions in a bucket");

        Request<Void> request = createRequest(bucketName, null, listVersionsRequest);
        request.addParameter("versions", null);

        if (prefix != null) request.addParameter("prefix", prefix);
        if (keyMarker != null) request.addParameter("key-marker", keyMarker);
        if (versionIdMarker != null) request.addParameter("version-id-marker", versionIdMarker);
        if (delimiter != null) request.addParameter("delimiter", delimiter);
        if (maxResults != null && maxResults.intValue() >= 0) request.addParameter("max-keys", maxResults.toString());

        signRequest(request, HttpMethodName.GET, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        OnestXmlResponseHandler<VersionListing> responseHandler =
            new OnestXmlResponseHandler<VersionListing>(new Unmarshallers.VersionListUnmarshaller());

        return (VersionListing)client.execute(httpRequest, responseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#listObjects(java.lang.String)
     */
    public ObjectListing listObjects(String bucketName)
            throws OnestClientException, OnestServiceException {
        return listObjects(new ListObjectsRequest(bucketName, null, null, null, null));
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#listObjects(java.lang.String, java.lang.String)
     */
    public ObjectListing listObjects(String bucketName, String prefix)
            throws OnestClientException, OnestServiceException {
        return listObjects(new ListObjectsRequest(bucketName, prefix, null, null, null));
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#listObjects(com.request.ListObjectsRequest)
     */
    public ObjectListing listObjects(ListObjectsRequest listObjectsRequest)
            throws OnestClientException, OnestServiceException {
        String bucketName = listObjectsRequest.getBucketName();
        String prefix = listObjectsRequest.getPrefix();
        String marker = listObjectsRequest.getMarker();
        String delimiter = listObjectsRequest.getDelimiter();
        Integer maxResult = listObjectsRequest.getMaxResult();

        assertParameterNotNull(bucketName, "The bucket name parameter must be specified when listing objects in a bucket");

        Request<Void> request = createRequest(bucketName, null, listObjectsRequest);
        if (prefix != null) request.addParameter("prefix", prefix);
        if (marker != null) request.addParameter("marker", marker);
        if (delimiter != null) request.addParameter("delimiter", delimiter);
        if (maxResult != null && maxResult.intValue() > 0) request.addParameter("maxResults", maxResult.toString());

        signRequest(request, HttpMethodName.GET, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        OnestXmlResponseHandler<ObjectListing> responseHandler =
            new OnestXmlResponseHandler<ObjectListing>(new Unmarshallers.ListObjectsUnmarshaller());

        return (ObjectListing)client.execute(httpRequest, responseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#listNextBatchOfObjects(com.meta.ObjectListing)
     */
    public ObjectListing listNextBatchOfObjects(ObjectListing previousObjectListing)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(previousObjectListing,
                "The previous object listing parameter must be specified when listing the next batch of objects in a bucket");

        if (!previousObjectListing.isTruncated()) {
            ObjectListing emptyListing = new ObjectListing();
            emptyListing.setBucketName(previousObjectListing.getBucketName());
            emptyListing.setDelimiter(previousObjectListing.getDelimiter());
            emptyListing.setMarker(previousObjectListing.getNextMarker());
            emptyListing.setMaxKeys(previousObjectListing.getMaxKeys());
            emptyListing.setPrefix(previousObjectListing.getPrefix());
            emptyListing.setTruncated(false);

            return emptyListing;
        }

        return listObjects(new ListObjectsRequest(
                previousObjectListing.getBucketName(),
                previousObjectListing.getPrefix(),
                previousObjectListing.getNextMarker(),
                previousObjectListing.getDelimiter(),
                new Integer( previousObjectListing.getMaxKeys() ) ));
    }


    /* (non-Javadoc)
     * @see com.onest.client.Onest#getOnestAccountOwner()
     */
    public Owner getOnestAccountOwner()
            throws OnestClientException, OnestServiceException {
        Request<Void> request = createRequest(null, null, null);

        signRequest(request, HttpMethodName.GET, null, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        OnestXmlResponseHandler<Owner> responseHandler =
            new OnestXmlResponseHandler<Owner>(new Unmarshallers.ListBucketsOwnerUnmarshaller());

        return (Owner)client.execute(httpRequest, responseHandler, errorResponseHandler);
    }
   
    /* (non-Javadoc)
     * @see com.onest.client.Onest#listAzNeInfo()
     */
    public AzNeInfoList listAzNeInfo(ListAzNeInfoRequest listAzNeInfoRequest)
            throws OnestClientException, OnestServiceException {
        Request<Void> request = createRequest(null, null, listAzNeInfoRequest);
        request.addParameter("manage", "");
        signRequest(request, HttpMethodName.GET, null, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        OnestXmlResponseHandler<AzNeInfoList> responseHandler =
            new OnestXmlResponseHandler<AzNeInfoList>(new Unmarshallers.ListAzNeInfoUnmarshaller());

        return (AzNeInfoList)client.execute(httpRequest, responseHandler, errorResponseHandler);
    }
        
    
    /* (non-Javadoc)
     * @see com.onest.client.Onest#listBuckets()
     */
    public List<Bucket> listBuckets(ListBucketsRequest listBucketsRequest)
            throws OnestClientException, OnestServiceException {
        Request<Void> request = createRequest(null, null, listBucketsRequest);

        signRequest(request, HttpMethodName.GET, null, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        OnestXmlResponseHandler<List<Bucket>> responseHandler =
            new OnestXmlResponseHandler<List<Bucket>>(new Unmarshallers.ListBucketsUnmarshaller());

        return (List<Bucket>)client.execute(httpRequest, responseHandler, errorResponseHandler);
    }
    
    
    /* (non-Javadoc)
     * @see com.onest.client.Onest#listBuckets()
     */
    public List<Bucket> listBuckets()
            throws OnestClientException, OnestServiceException {
        return listBuckets(new ListBucketsRequest());
    }

    /* (non-Javadoc)
     * @see com.Onest#createBucket(java.lang.String)
     */
    public Bucket createBucket(String bucketName)
            throws OnestClientException, OnestServiceException {
        return createBucket(new CreateBucketRequest(bucketName));
    }

    /* (non-Javadoc)
     * @see com.Onest#createBucket(java.lang.String, com.meta.Region)
     */
    public Bucket createBucket(String bucketName, Region region)
            throws OnestClientException, OnestServiceException {
        return createBucket(new CreateBucketRequest(bucketName, region));
    }

    /* (non-Javadoc)
     * @see com.Onest#createBucket(java.lang.String, java.lang.String)
     */
    public Bucket createBucket(String bucketName, String region)
            throws OnestClientException, OnestServiceException {
        return createBucket(new CreateBucketRequest(bucketName, region));
    }
    
    /* (non-Javadoc)
     * @see com.Onest#createBucket(java.lang.String, java.lang.String, java.lang.String)
     */
    public Bucket createBucket(String bucketName, String region, CannedAccessControlList acl,String copyPolicy)
            throws OnestClientException, OnestServiceException {
        return createBucket(new CreateBucketRequest(bucketName, region, acl));
    }

    /* (non-Javadoc)
     * @see com.Onest#createBucket(com.request.CreateBucketRequest)
     */
    public Bucket createBucket(CreateBucketRequest createBucketRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(createBucketRequest,"The CreateBucketRequest parameter must be specified when creating a bucket");
        String bucketName = createBucketRequest.getBucketName();        
        assertParameterNotNull(bucketName,"The bucket name parameter must be specified when creating a bucket");

        if (bucketName != null) bucketName = bucketName.trim();
        bucketNameUtils.validateBucketName(bucketName);

        Request<Void> request = createRequest(bucketName, null, createBucketRequest); 	        
                  
        if (request.getHeaders().get(Headers.CONTENT_LENGTH) == null) {
            request.addHeader(Headers.CONTENT_LENGTH, "0");
        }
        
        signRequest(request, HttpMethodName.PUT, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.PUT);
        
        client.execute(httpRequest, voidResponseHandler, errorResponseHandler);

        return new Bucket(bucketName);
    }

    public List<String> getLocation()
		    throws OnestClientException, OnestServiceException {
		return getLocation(new CreateGetLocationRequest());
    }
    
    public List<String> getLocation(boolean isOuterLocation, boolean isIntraSrvLocation)
		    throws OnestClientException, OnestServiceException {
		return getLocation(new CreateGetLocationRequest(isOuterLocation, isIntraSrvLocation));
	}

    public List<String> getLocation(CreateGetLocationRequest createGetLocationRequest)
    		throws OnestClientException, OnestServiceException {
		assertParameterNotNull(createGetLocationRequest,"The CreateGetLocationRequest parameter must be specified when creating a bucket");
        Request<Void> request = createLocationRequest(null, createGetLocationRequest);
        if(createGetLocationRequest.GetIsOuterLocation()){
        	request.addParameter("outerlocation", "");
        }  
        else if(createGetLocationRequest.GetIsIntraSrvLocation()){
			request.addParameter("intrasrvlocation", "");
		}else {
			request.addParameter("intramgrlocation", "");
		}
        signLocationRequest(request, HttpMethodName.GET, null, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        OnestXmlResponseHandler<List<String>> responseHandler =
            new OnestXmlResponseHandler<List<String>>(new Unmarshallers.LocationUnmarshaller());

        return (List<String>)client.execute(httpRequest, responseHandler, errorResponseHandler);
  	
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#getBucketLocation(java.lang.String)
     */
    public List<String> getBucketLocation(String bucketName)
		    throws OnestClientException, OnestServiceException {
		return getBucketLocation(new CreateGetLocationRequest(bucketName));
	}

    public List<String> getBucketLocation(boolean isOuterLocation, boolean isIntraSrvLocation)
		    throws OnestClientException, OnestServiceException {
		return getBucketLocation(new CreateGetLocationRequest(isOuterLocation, isIntraSrvLocation));
	}
    
    public List<String> getBucketLocation(String bucketName, boolean isOuterLocation, boolean isIntraSrvLocation)
		    throws OnestClientException, OnestServiceException {
		return getBucketLocation(new CreateGetLocationRequest(bucketName,isOuterLocation, isIntraSrvLocation));
	}

    public List<String> getBucketLocation(CreateGetLocationRequest createGetBucketLocationRequest)
			throws OnestClientException, OnestServiceException {
    	assertParameterNotNull(createGetBucketLocationRequest,"The CreateGetLocationRequest parameter must be specified when creating a bucket");
		String bucketName = createGetBucketLocationRequest.GetBucketName();
		
		Request<Void> request = createLocationRequest(bucketName, createGetBucketLocationRequest);
		if(createGetBucketLocationRequest.GetIsOuterLocation()){
			request.addParameter("outerlocation", "");
		}        	
		else if(createGetBucketLocationRequest.GetIsIntraSrvLocation()){
			request.addParameter("intrasrvlocation", "");
		}else {
			request.addParameter("intramgrlocation", "");
		}
		signLocationRequest(request, HttpMethodName.GET, bucketName, null);
		HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);
		
		OnestXmlResponseHandler<List<String>> responseHandler =
		    new OnestXmlResponseHandler<List<String>>(new Unmarshallers.LocationUnmarshaller());
		
		return (List<String>)client.execute(httpRequest, responseHandler, errorResponseHandler);
		
    }
    
    /* (non-Javadoc)
     * @see com.onest.client.Onest#getObjectAcl(java.lang.String, java.lang.String)
     */
    public AccessControlList getObjectAcl(String bucketName, String key)
            throws OnestClientException, OnestServiceException {
        return getObjectAcl(bucketName, key, null);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#getObjectAcl(java.lang.String, java.lang.String, java.lang.String)
     */
    public AccessControlList getObjectAcl(String bucketName, String key, String versionId)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName, "The bucket name parameter must be specified when requesting an object's ACL");
        assertParameterNotNull(key, "The key parameter must be specified when requesting an object's ACL");

        return getAcl(bucketName, key, versionId);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#setObjectAcl(java.lang.String, java.lang.String, com.meta.AccessControlList)
     */
    public void setObjectAcl(String bucketName, String key, AccessControlList acl)
            throws OnestClientException, OnestServiceException {
        setObjectAcl(bucketName, key, null, acl);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#setObjectAcl(java.lang.String, java.lang.String, com.meta.CannedAccessControlList)
     */
    public void setObjectAcl(String bucketName, String key, CannedAccessControlList acl)
            throws OnestClientException, OnestServiceException {
        setObjectAcl(bucketName, key, null, acl);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#setObjectAcl(java.lang.String, java.lang.String, java.lang.String, com.meta.AccessControlList)
     */
    public void setObjectAcl(String bucketName, String key, String versionId, AccessControlList acl)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName, "The bucket name parameter must be specified when setting an object's ACL");
        assertParameterNotNull(key, "The key parameter must be specified when setting an object's ACL");
        assertParameterNotNull(acl, "The ACL parameter must be specified when setting an object's ACL");

        setAcl(bucketName, key, versionId, acl);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#setObjectAcl(java.lang.String, java.lang.String, java.lang.String, com.meta.CannedAccessControlList)
     */
    public void setObjectAcl(String bucketName, String key, String versionId, CannedAccessControlList acl)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName, "The bucket name parameter must be specified when setting an object's ACL");
        assertParameterNotNull(key, "The key parameter must be specified when setting an object's ACL");
        assertParameterNotNull(acl, "The ACL parameter must be specified when setting an object's ACL");

        setAcl(bucketName, key, versionId, acl);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#getBucketAcl(java.lang.String)
     */
    public AccessControlList getBucketAcl(String bucketName)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName, "The bucket name parameter must be specified when requesting a bucket's ACL");

        return getAcl(bucketName, null, null);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#setBucketAcl(java.lang.String, com.meta.AccessControlList)
     */
    public void setBucketAcl(String bucketName, AccessControlList acl)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName, "The bucket name parameter must be specified when setting a bucket's ACL");
        assertParameterNotNull(acl, "The ACL parameter must be specified when setting a bucket's ACL");

        setAcl(bucketName, null, null, acl);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#setBucketAcl(java.lang.String, com.meta.CannedAccessControlList)
     */
    public void setBucketAcl(String bucketName, CannedAccessControlList acl)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName, "The bucket name parameter must be specified when setting a bucket's ACL");
        assertParameterNotNull(acl, "The ACL parameter must be specified when setting a bucket's ACL");

        setAcl(bucketName, null, null, acl);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#getObjectMetadata(java.lang.String, java.lang.String)
     */
    public ObjectMetadata getObjectMetadata(String bucketName, String key)
            throws OnestClientException, OnestServiceException {
        return getObjectMetadata(new GetObjectMetadataRequest(bucketName, key));
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#getObjectMetadata(com.request.GetObjectMetadataRequest)
     */
    public ObjectMetadata getObjectMetadata(GetObjectMetadataRequest getObjectMetadataRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(getObjectMetadataRequest, "The GetObjectMetadataRequest parameter must be specified when requesting an object's metadata");

        String bucketName = getObjectMetadataRequest.getBucketName();
        String key = getObjectMetadataRequest.getKey();
        String versionId = getObjectMetadataRequest.getVersionId();

        assertParameterNotNull(bucketName, "The bucket name parameter must be specified when requesting an object's metadata");
        assertParameterNotNull(key, "The key parameter must be specified when requesting an object's metadata");

        Request<Void> request = createRequest(bucketName, key, getObjectMetadataRequest);
        if (versionId != null) request.addParameter("versionId", versionId);

        signRequest(request, HttpMethodName.HEAD, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.HEAD);

        OnestMetadataResponseHandler responseHandler = new OnestMetadataResponseHandler();
        return (ObjectMetadata)client.execute(httpRequest, responseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#setObjectMetadata(java.lang.String, java.lang.String, java.lang.String, java.util.map)
     */
    public void setObjectMetadata(String bucketName, String key, ObjectMetadata userMeta)
			throws OnestClientException, OnestServiceException{
    	setObjectMetadata(bucketName, key, null, userMeta.getUserMetadata());
    }
    
    /* (non-Javadoc)
     * @see com.onest.client.Onest#setObjectMetadata(java.lang.String, java.lang.String, java.lang.String, java.util.map)
     */
    public void setObjectMetadata(String bucketName, String key, Map<String, String> userMeta)
			throws OnestClientException, OnestServiceException{
    	setObjectMetadata(bucketName, key, null, userMeta);
    }
    
    /* (non-Javadoc)
     * @see com.onest.client.Onest#setObjectMetadata(java.lang.String, java.lang.String, java.lang.String, java.util.map)
     */
    public void setObjectMetadata(String bucketName, String key, String versionId, Map<String, String> userMeta)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName, "The bucket name parameter must be specified when setting an object's Metadata");
        assertParameterNotNull(key, "The key parameter must be specified when setting an object's Metadata");
        assertParameterNotNull(userMeta, "The userMeta parameter must be specified when setting an object's Metadata");

        Request<Void> request = createRequest(bucketName, key, null);
        request.addParameter("meta", null);
        if (versionId != null) request.addParameter("versionId", versionId);
        
        for (Entry<String, String> entry : userMeta.entrySet()) {
            request.addHeader(Headers.ONEST_USER_METADATA_PREFIX + entry.getKey(), entry.getValue().toString());
        }
        
        signRequest(request, HttpMethodName.PUT, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.PUT);

        client.execute(httpRequest, voidResponseHandler, errorResponseHandler);
        
    }
    
    
    /* (non-Javadoc)
     * @see com.onest.client.Onest#getObject(java.lang.String, java.lang.String)
     */
    public OnestObject getObject(String bucketName, String key)
            throws OnestClientException, OnestServiceException {
        return getObject(new GetObjectRequest(bucketName, key));
    }

   
    /* (non-Javadoc)
     * @see com.onest.client.Onest#doesBucketExist(java.lang.String)
     */
    public boolean doesBucketExist(String bucketName)
        throws OnestClientException, OnestServiceException {

        try {
            listObjects(new ListObjectsRequest(bucketName, null, null, null, 0));

            // it exists and the current account owns it
            return true;
        } catch (OnestServiceException ase) {
            switch (ase.getStatusCode()) {
            case 403:
                /*
                 * A permissions error means the bucket exists, but is owned by
                 * another account.
                 */
                return true;
            case 404:
                return false;
            default:
                throw ase;
            }
        }
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#changeStorageClass(java.lang.String, java.lang.String, java.lang.String)
     */
    public void changeObjectStorageClass(String bucketName, String key, StorageClass newStorageClass)
        throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName,
            "The bucketName parameter must be specified when changing an object's storage class");
        assertParameterNotNull(key,
            "The key parameter must be specified when changing an object's storage class");
        assertParameterNotNull(newStorageClass,
            "The newStorageClass parameter must be specified when changing an object's storage class");

        copyObject(new CopyObjectRequest(bucketName, key, bucketName, key)
            .withStorageClass(newStorageClass.toString()));
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#getObject(com.request.GetObjectRequest)
     */
    public OnestObject getObject(GetObjectRequest getObjectRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(getObjectRequest,
                "The GetObjectRequest parameter must be specified when requesting an object");
        assertParameterNotNull(getObjectRequest.getBucketName(),
                "The bucket name parameter must be specified when requesting an object");
        assertParameterNotNull(getObjectRequest.getKey(),
                "The key parameter must be specified when requesting an object");

        String bucketName = getObjectRequest.getBucketName();
        String key = getObjectRequest.getKey();

        Request<Void> request = createRequest(bucketName, key, getObjectRequest);

        if (getObjectRequest.getVersionId() != null) {
            request.addParameter("versionId", getObjectRequest.getVersionId());
        }

        // Range
        if (getObjectRequest.getRange() != null) {
            long[] range = getObjectRequest.getRange();
            if(range[1] == -1)
            	request.addHeader(Headers.RANGE, "bytes=" + Long.toString(range[0]) + "-");
            else
            	request.addHeader(Headers.RANGE, "bytes=" + Long.toString(range[0]) + "-" + Long.toString(range[1]));
        }

        addDateHeader(request, Headers.GET_OBJECT_IF_MODIFIED_SINCE,
                getObjectRequest.getModifiedSinceConstraint());
        addDateHeader(request, Headers.GET_OBJECT_IF_UNMODIFIED_SINCE,
                getObjectRequest.getUnmodifiedSinceConstraint());
        addStringListHeader(request, Headers.GET_OBJECT_IF_MATCH,
                getObjectRequest.getMatchingETagConstraints());
        addStringListHeader(request, Headers.GET_OBJECT_IF_NONE_MATCH,
                getObjectRequest.getNonmatchingETagConstraints());

        signRequest(request, HttpMethodName.GET, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        try {
            OnestObjectResponseHandler responseHandler = new OnestObjectResponseHandler();
            OnestObject onestObject = (OnestObject)client.execute(httpRequest, responseHandler, errorResponseHandler);

            /*
             * TODO: For now, it's easiest to set there here in the client, but
             *       we could push this back into the response handler with a
             *       little more work.
             */
            onestObject.setBucketName(bucketName);
            onestObject.setKey(key);

            /*
             * TODO: It'd be nice to check the integrity of the data was received from Onest,
             *       but we'd have to read off the stream and buffer the contents somewhere
             *       in order to do that.
             *
             *       We could consider adding an option for this in the future, or wrapping
             *       the InputStream in another implementation of FilterInputStream that
             *       would calculate the checksum when the user reads the data and then
             *       notify them somehow if there was a problem.
             */
            return onestObject;
        } catch (OnestException oe) {
            /*
             * If the request failed because one of the specified constraints
             * was not met (ex: matching ETag, modified since date, etc.), then
             * return null, so that users don't have to wrap their code in
             * try/catch blocks and check for this status code if they want to
             * use constraints.
             */
            if (oe.getStatusCode() == 412 || oe.getStatusCode() == 304) {
                return null;
            }

            throw oe;
        }
    }

	
    /* (non-Javadoc)
     * @see com.onest.client.Onest#getObject(com.request.GetObjectRequest, java.io.File)
     */
    public ObjectMetadata getObject(GetObjectRequest getObjectRequest, File destinationFile)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(destinationFile,
                "The destination file parameter must be specified when downloading an object directly to a file");

        OnestObject onestObject = getObject(getObjectRequest);
        // getObject can return null if constraints were specified but not met
        if (onestObject == null) return null;

        OutputStream outputStream = null;
        try {
            outputStream = new BufferedOutputStream(new FileOutputStream(destinationFile));
            byte[] buffer = new byte[1024*10];
            int bytesRead;
            while ((bytesRead = onestObject.getObjectContent().read(buffer)) > -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            throw new OnestClientException(
                    "Unable to store object contents to disk: " + e.getMessage(), e);
        } finally {
            try {outputStream.close();} catch (Exception e) {}
            try {onestObject.getObjectContent().close();} catch (Exception e) {}
        }

        try {
            byte[] clientSideHash = ServiceUtils.computeMD5Hash(new FileInputStream(destinationFile));
            byte[] serverSideHash = ServiceUtils.fromHex(onestObject.getObjectMetadata().getETag());

            if (!Arrays.equals(clientSideHash, serverSideHash)) {
                throw new OnestClientException("Unable to verify integrity of data download.  " +
                        "Client calculated content hash didn't match hash calculated by Onest.  " +
                        "The data stored in '" + destinationFile.getAbsolutePath() + "' may be corrupt.");
            }
        } catch (Exception e) {
            log.warn("Unable to calculate MD5 hash to validate download: " + e.getMessage(), e);
        }

        return onestObject.getObjectMetadata();
    }
	

    /* (non-Javadoc)
     * @see com.onest.client.Onest#deleteBucket(java.lang.String)
     */
    public void deleteBucket(String bucketName)
            throws OnestClientException, OnestServiceException {
        deleteBucket(new DeleteBucketRequest(bucketName));
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#deleteBucket(com.request.DeleteBucketRequest)
     */
    public void deleteBucket(DeleteBucketRequest deleteBucketRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(deleteBucketRequest,
                "The DeleteBucketRequest parameter must be specified when deleting a bucket");

        String bucketName = deleteBucketRequest.getBucketName();
        assertParameterNotNull(bucketName,
                "The bucket name parameter must be specified when deleting a bucket");

        Request<Void> request = createRequest(bucketName, null, deleteBucketRequest);
        signRequest(request, HttpMethodName.DELETE, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.DELETE);
        client.execute(httpRequest, voidResponseHandler, errorResponseHandler);
    }

	
    /* (non-Javadoc)
     * @see com.onest.client.Onest#putObject(java.lang.String, java.lang.String, java.io.File)
     */
    public PutObjectResult putObject(String bucketName, String key, File file)
            throws OnestClientException, OnestServiceException {
        return putObject(new PutObjectRequest(bucketName, key, file)
            .withMetadata(new ObjectMetadata()));
    }
	

    /* (non-Javadoc)
     * @see com.onest.client.Onest#putObject(java.lang.String, java.lang.String, java.io.InputStream, com.meta.ObjectMetadata)
     */
    public PutObjectResult putObject(String bucketName, String key, InputStream input, ObjectMetadata metadata)
            throws OnestClientException, OnestServiceException {
        return putObject(new PutObjectRequest(bucketName, key, input, metadata));
    }


    /* (non-Javadoc)
     * @see com.onest.client.Onest#putObject(com.request.PutObjectRequest)
     */
    public PutObjectResult putObject(PutObjectRequest putObjectRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(putObjectRequest, "The PutObjectRequest parameter must be specified when uploading an object");

        String bucketName = putObjectRequest.getBucketName();
        String key = putObjectRequest.getKey();
        ObjectMetadata metadata = putObjectRequest.getMetadata();
        InputStream input = putObjectRequest.getInputStream();
        ProgressListener progressListener = putObjectRequest.getProgressListener();
        if (metadata == null) metadata = new ObjectMetadata();

        assertParameterNotNull(bucketName, "The bucket name parameter must be specified when uploading an object");
        assertParameterNotNull(key, "The key parameter must be specified when uploading an object");

		
        // If a file is specified for upload, we need to pull some additional
        // information from it to auto-configure a few options
        if (putObjectRequest.getFile() != null) {
            File file = putObjectRequest.getFile();

            // Always set the content length, even if it's already set
            metadata.setContentLength(file.length());

            // Only set the content type if it hasn't already been set
            if (metadata.getContentType() == null) {
                metadata.setContentType(Mimetypes.getInstance().getMimetype(file));
            }

            FileInputStream fileInputStream = null;
            try {
                fileInputStream = new FileInputStream(file);
                byte[] md5Hash = ServiceUtils.computeMD5Hash(fileInputStream);
                metadata.setContentMD5(ServiceUtils.toBase64(md5Hash));
            } catch (Exception e) {
                throw new OnestClientException(
                        "Unable to calculate MD5 hash: " + e.getMessage(), e);
            } finally {
                try {fileInputStream.close();} catch (Exception e) {}
            }

            try {
                input = new RepeatableFileInputStream(file);
            } catch (FileNotFoundException fnfe) {
                throw new OnestClientException("Unable to find file to upload", fnfe);
            }
        }
		

        Request<Void> request = createRequest(bucketName, key, putObjectRequest);

        if (putObjectRequest.getCannedAcl() != null) {
            request.addHeader(Headers.ONEST_CANNED_ACL, putObjectRequest.getCannedAcl().toString());
        }

        if (putObjectRequest.getStorageClass() != null) {
            request.addHeader(Headers.STORAGE_CLASS, putObjectRequest.getStorageClass());
        }
        
        if (metadata.getContentLength() < 0) {
            /*
             * There's nothing we can do except for let the HTTP client buffer
             * the input stream contents if the caller doesn't tell us how much
             * data to expect in a stream since we have to explicitly tell
             * Onest how much we're sending before we start sending any of
             * it.
             */
            log.warn("No content length specified for stream data.  " +
                     "Stream contents will be buffered in memory and could result in " +
                     "out of memory errors.");
        }

        if (progressListener != null) {
            input = new ProgressReportingInputStream(input, progressListener);
            fireProgressEvent(progressListener, ProgressEvent.STARTED_EVENT_CODE);
        }

        if (input!= null && !input.markSupported()) {
            input = new RepeatableInputStream(input, Constants.DEFAULT_STREAM_BUFFER_SIZE);
        }

        MD5DigestCalculatingInputStream md5DigestStream = null;
        if (metadata.getContentMD5() == null) {
            /*
             * If the user hasn't set the content MD5, then we don't want to
             * buffer the whole stream in memory just to calculate it. Instead,
             * we can calculate it on the fly and validate it with the returned
             * ETag from the object upload.
             */
            try {
                md5DigestStream = new MD5DigestCalculatingInputStream(input);
                input = md5DigestStream;
            } catch (NoSuchAlgorithmException e) {
                log.warn("No MD5 digest algorithm available.  Unable to calculate " +
                         "checksum and verify data integrity.", e);
            }
        }

        if (metadata.getContentType() == null) {
            /*
             * Default to the "application/octet-stream" if the user hasn't
             * specified a content type.
             */
            metadata.setContentType(Mimetypes.MIMETYPE_OCTET_STREAM);
        }

        populateRequestMetadata(request, metadata);
        signRequest(request, HttpMethodName.PUT, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.PUT);
        httpRequest.setContent(input);

        ObjectMetadata returnedMetadata = null;
        try {
            OnestMetadataResponseHandler responseHandler = new OnestMetadataResponseHandler();
            returnedMetadata = (ObjectMetadata)client.execute(httpRequest, responseHandler, errorResponseHandler);
        } catch (OnestClientException oce) {
            fireProgressEvent(progressListener, ProgressEvent.FAILED_EVENT_CODE);
            throw oce;
        } finally {
            try {
	            	if(input != null)
	            		input.close();
            	} catch (Exception e)
            	{
            		log.warn("Unable to cleanly close input stream: " + e.getMessage(), e);
            	}
        }

        String contentMd5 = metadata.getContentMD5();
        if (md5DigestStream != null) {
            contentMd5 = ServiceUtils.toBase64(md5DigestStream.getMd5Digest());
        }

        fireProgressEvent(progressListener, ProgressEvent.COMPLETED_EVENT_CODE);
        
        PutObjectResult result = new PutObjectResult();
        result.setETag(returnedMetadata.getETag());
        result.setVersionId(returnedMetadata.getVersionId());
        return result;
    }
    
    /* (non-Javadoc)
     * @see com.onest.client.Onest#copyObject(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    public CopyObjectResult copyObject(String sourceBucketName, String sourceKey,
                                       String destinationBucketName, String destinationKey)
            throws OnestClientException, OnestServiceException {
        return copyObject(new CopyObjectRequest(sourceBucketName, sourceKey,
                                                destinationBucketName, destinationKey));
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#copyObject(com.request.CopyObjectRequest)
     */
    public CopyObjectResult copyObject(CopyObjectRequest copyObjectRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(copyObjectRequest.getSourceBucketName(),
                "The source bucket name must be specified when copying an object");
        assertParameterNotNull(copyObjectRequest.getSourceKey(),
                "The source object key must be specified when copying an object");
        assertParameterNotNull(copyObjectRequest.getDestinationBucketName(),
                "The destination bucket name must be specified when copying an object");
        assertParameterNotNull(copyObjectRequest.getDestinationKey(),
                "The destination object key must be specified when copying an object");

        String destinationKey = copyObjectRequest.getDestinationKey();
        String destinationBucketName = copyObjectRequest.getDestinationBucketName();

        Request<Void> request = createRequest(destinationBucketName, destinationKey, copyObjectRequest);

        populateRequestWithCopyObjectParameters(request, copyObjectRequest);
        /*
         * We can't send the Content-Length header if the user specified it,
         * otherwise it messes up the HTTP connection when the remote server
         * thinks there's more data to pull.
         */
        //request.getHeaders().remove(Headers.CONTENT_LENGTH);
        request.addHeader(Headers.CONTENT_LENGTH, "0");
        
        signRequest(request, HttpMethodName.PUT, destinationBucketName, destinationKey);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.PUT);

        CopyObjectResultHandler copyObjectResultHandler = null;
        try {
            // TODO: Should we move some more of this logic into CopyObjectResponseHandler?
            //       For example, detecting the different failure modes?
            CopyObjectResponseHandler responseHandler = new CopyObjectResponseHandler();
            copyObjectResultHandler =
                (CopyObjectResultHandler)client.execute(httpRequest, responseHandler, errorResponseHandler);
        } catch (OnestException ase) {
            /*
             * If the request failed because one of the specified constraints
             * was not met (ex: matching ETag, modified since date, etc.), then
             * return null, so that users don't have to wrap their code in
             * try/catch blocks and check for this status code if they want to
             * use constraints.
             */
            if (ase.getStatusCode() == Constants.FAILED_PRECONDITION_STATUS_CODE) {
               return null;
            }

            throw ase;
        }

        /*
         * CopyObject has two failure modes:
         *  1 - An HTTP error code is returned and the error is processed like any
         *      other error response.
         *  2 - An HTTP 200 OK code is returned, but the response content contains
         *      an XML error response.
         *
         * This makes it very difficult for the client runtime to cleanly detect
         * this case and handle it like any other error response.  We could
         * extend the runtime to have a more flexible/customizable definition of
         * success/error (per request), but it's probably overkill for this
         * one special case.
         */
        if (copyObjectResultHandler.getErrorCode() != null) {
            String errorCode = copyObjectResultHandler.getErrorCode();
            String errorMessage = copyObjectResultHandler.getErrorMessage();
            String requestId = copyObjectResultHandler.getErrorRequestId();
            String hostId = copyObjectResultHandler.getErrorHostId();

            OnestException ase = new OnestException(errorMessage);
            ase.setErrorCode(errorCode);
            ase.setErrorType(ErrorType.Service);
            ase.setRequestId(requestId);
            ase.setExtendedRequestId(hostId);
            ase.setServiceName(request.getServiceName());
            ase.setStatusCode(200);

            throw ase;
        }

        // TODO: Might be nice to create this in our custom CopyObjectResponseHandler
        CopyObjectResult copyObjectResult = new CopyObjectResult();
        copyObjectResult.setETag(copyObjectResultHandler.getETag());
        copyObjectResult.setLastModifiedDate(
                copyObjectResultHandler.getLastModified());
        copyObjectResult.setVersionId(copyObjectResultHandler.getVersionId());

        return copyObjectResult;
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#deleteObject(java.lang.String, java.lang.String)
     */
    public void deleteObject(String bucketName, String key)
            throws OnestClientException, OnestServiceException {
        deleteObject(new DeleteObjectRequest(bucketName, key));
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#deleteObject(com.request.DeleteObjectRequest)
     */
    public void deleteObject(DeleteObjectRequest deleteObjectRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(deleteObjectRequest,
            "The delete object request must be specified when deleting an object");

        String bucketName = deleteObjectRequest.getBucketName();
        String key = deleteObjectRequest.getKey();

        assertParameterNotNull(bucketName, "The bucket name must be specified when deleting an object");
        assertParameterNotNull(key, "The key must be specified when deleting an object");

        Request<Void> request = createRequest(bucketName, key, deleteObjectRequest);
        signRequest(request, HttpMethodName.DELETE, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.DELETE);

        client.execute(httpRequest, voidResponseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#deleteObjectVersion(java.lang.String, java.lang.String, java.lang.String)
     */
    public void deleteVersion(String bucketName, String key, String versionId)
            throws OnestClientException, OnestServiceException {
        deleteVersion(new DeleteVersionRequest(bucketName, key, versionId));
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#deleteVersion(com.request.DeleteVersionRequest)
     */
    public void deleteVersion(DeleteVersionRequest deleteVersionRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(deleteVersionRequest,
            "The delete version request object must be specified when deleting a version");

        String bucketName = deleteVersionRequest.getBucketName();
        String key = deleteVersionRequest.getKey();
        String versionId = deleteVersionRequest.getVersionId();

        assertParameterNotNull(bucketName, "The bucket name must be specified when deleting a version");
        assertParameterNotNull(key, "The key must be specified when deleting a version");
        assertParameterNotNull(versionId, "The version ID must be specified when deleting a version");

        Request<Void> request = createRequest(bucketName, key, deleteVersionRequest);
        if (versionId != null) request.addParameter("versionId", versionId);

        if (deleteVersionRequest.getMfa() != null) {
            populateRequestWithMfaDetails(request, deleteVersionRequest.getMfa());
        }

        signRequest(request, HttpMethodName.DELETE, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.DELETE);

        client.execute(httpRequest, voidResponseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#setBucketVersioningConfiguration(com.request.SetBucketVersioningConfigurationRequest)
     */
    public void setBucketVersioningConfiguration(SetBucketVersioningConfigurationRequest setBucketVersioningConfigurationRequest)
        throws OnestClientException, OnestServiceException {
        assertParameterNotNull(setBucketVersioningConfigurationRequest,
            "The SetBucketVersioningConfigurationRequest object must be specified when setting versioning configuration");

        String bucketName = setBucketVersioningConfigurationRequest.getBucketName();
        BucketVersioningConfiguration versioningConfiguration = setBucketVersioningConfigurationRequest.getVersioningConfiguration();

        assertParameterNotNull(bucketName,
            "The bucket name parameter must be specified when setting versioning configuration");
        assertParameterNotNull(versioningConfiguration,
            "The bucket versioning parameter must be specified when setting versioning configuration");
        if (versioningConfiguration.isMfaDeleteEnabled() != null) {
            assertParameterNotNull(setBucketVersioningConfigurationRequest.getMfa(),
                "The MFA parameter must be specified when changing MFA Delete status in the versioning configuration");
        }

        Request<Void> request = createRequest(bucketName, null, setBucketVersioningConfigurationRequest);
        request.addParameter("versioning", null);

        if (versioningConfiguration.isMfaDeleteEnabled() != null) {
            if (setBucketVersioningConfigurationRequest.getMfa() != null) {
                populateRequestWithMfaDetails(request, setBucketVersioningConfigurationRequest.getMfa());
            }
        }

        signRequest(request, HttpMethodName.PUT, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.PUT);

        byte[] bytes = bucketConfigurationXmlFactory.convertToXmlByteArray(versioningConfiguration);
        httpRequest.setContent(new ByteArrayInputStream(bytes));

        client.execute(httpRequest, voidResponseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#getBucketVersioningConfiguration(java.lang.String)
     */
    public BucketVersioningConfiguration getBucketVersioningConfiguration(String bucketName)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName,
                "The bucket name parameter must be specified when querying versioning configuration");

        Request<Void> request = createRequest(bucketName, null, null);
        request.addParameter("versioning", null);

        signRequest(request, HttpMethodName.GET, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        OnestXmlResponseHandler<BucketVersioningConfiguration> responseHandler =
            new OnestXmlResponseHandler<BucketVersioningConfiguration>(new Unmarshallers.BucketVersioningConfigurationUnmarshaller());

        return (BucketVersioningConfiguration)client.execute(httpRequest, responseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#setBucketNotificationConfiguration(java.lang.String,com.util.BucketNotificationConfiguration)
     */
    public void setBucketNotificationConfiguration(String bucketName, BucketNotificationConfiguration bucketNotificationConfiguration)
        throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName,
            "The bucket name parameter must be specified when setting notification configuration");
        assertParameterNotNull(bucketNotificationConfiguration,
            "The bucket notification parameter must be specified when setting notification configuration");

        Request<Void> request = createRequest(bucketName, null, null);
        request.addParameter("notification", null);

        signRequest(request, HttpMethodName.PUT, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.PUT);

        byte[] bytes = bucketConfigurationXmlFactory.convertToXmlByteArray(bucketNotificationConfiguration);
        httpRequest.setContent(new ByteArrayInputStream(bytes));

        client.execute(httpRequest, voidResponseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#getBucketNotificationConfiguration(java.lang.String)
     */
    public BucketNotificationConfiguration getBucketNotificationConfiguration(String bucketName)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName,
                "The bucket name parameter must be specified when querying notification configuration");

        Request<Void> request = createRequest(bucketName, null, null);
        request.addParameter("notification", null);

        signRequest(request, HttpMethodName.GET, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        OnestXmlResponseHandler<BucketNotificationConfiguration> responseHandler =
            new OnestXmlResponseHandler<BucketNotificationConfiguration>(new Unmarshallers.BucketNotificationConfigurationUnmarshaller());

        return (BucketNotificationConfiguration)client.execute(httpRequest, responseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#getBucketLoggingConfiguration(java.lang.String)
     */
    public BucketLoggingConfiguration getBucketLoggingConfiguration(String bucketName)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName,
                "The bucket name parameter must be specified when requesting a bucket's logging status");

        Request<Void> request = createRequest(bucketName, null, null);
        request.addParameter("logging", null);

        signRequest(request, HttpMethodName.GET, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        OnestXmlResponseHandler<BucketLoggingConfiguration> responseHandler =
            new OnestXmlResponseHandler<BucketLoggingConfiguration>(new Unmarshallers.BucketLoggingConfigurationnmarshaller());

        return (BucketLoggingConfiguration)client.execute(httpRequest, responseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#setBucketLoggingConfiguration(com.request.SetBucketLoggingConfigurationRequest)
     */
    public void setBucketLoggingConfiguration(SetBucketLoggingConfigurationRequest setBucketLoggingConfigurationRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(setBucketLoggingConfigurationRequest,
            "The set bucket logging configuration request object must be specified when enabling server access logging");

        String bucketName = setBucketLoggingConfigurationRequest.getBucketName();
        BucketLoggingConfiguration loggingConfiguration = setBucketLoggingConfigurationRequest.getLoggingConfiguration();

        assertParameterNotNull(bucketName,
            "The bucket name parameter must be specified when enabling server access logging");
        assertParameterNotNull(bucketName,
            "The logging configuration parameter must be specified when enabling server access logging");

        Request<Void> request = createRequest(bucketName, null, setBucketLoggingConfigurationRequest);
        request.addParameter("logging", null);

        signRequest(request, HttpMethodName.PUT, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.PUT);

        byte[] bytes = bucketConfigurationXmlFactory.convertToXmlByteArray(loggingConfiguration);
        httpRequest.setContent(new ByteArrayInputStream(bytes));

        client.execute(httpRequest, voidResponseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#getBucketPolicy(java.lang.String)
     */
    public BucketPolicy getBucketPolicy(String bucketName)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName,
            "The bucket name must be specified when getting a bucket policy");

        Request<Void> request = createRequest(bucketName, null, null);
        request.addParameter("policy", null);
        signRequest(request, HttpMethodName.GET, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        BucketPolicy result = new BucketPolicy();
        try {
            String policyText = client.execute(httpRequest, new OnestStringResponseHandler(), errorResponseHandler);
            result.setPolicyText(policyText);
            return result;
        } catch (OnestServiceException ase) {
            /*
             * If we receive an error response telling us that no policy has
             * been set for this bucket, then instead of forcing the user to
             * deal with the exception, we'll just return an empty result. Any
             * other exceptions will be rethrown for the user to handle.
             */
            if (ase.getErrorCode().equals("NoSuchBucketPolicy")) return result;
            throw ase;
        }
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#setBucketPolicy(java.lang.String, java.lang.String)
     */
    public void setBucketPolicy(String bucketName, String policyText)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName,
            "The bucket name must be specified when setting a bucket policy");
        assertParameterNotNull(policyText,
            "The policy text must be specified when setting a bucket policy");

        Request<Void> request = createRequest(bucketName, null, null);
        request.addParameter("policy", null);
        signRequest(request, HttpMethodName.PUT, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.PUT);
        httpRequest.setContent(new ByteArrayInputStream(ServiceUtils.toByteArray(policyText)));

        client.execute(httpRequest, voidResponseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#deleteBucketPolicy(java.lang.String)
     */
    public void deleteBucketPolicy(String bucketName)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(bucketName,
                "The bucket name must be specified when deleting a bucket policy");

        Request<Void> request = createRequest(bucketName, null, null);
        request.addParameter("policy", null);
        signRequest(request, HttpMethodName.DELETE, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.DELETE);

        client.execute(httpRequest, this.voidResponseHandler, this.errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#generatePresignedUrl(java.lang.String, java.lang.String, java.util.Date)
     */
    public URL generatePresignedUrl(String bucketName, String key, Date expiration)
            throws OnestClientException {
        return generatePresignedUrl(bucketName, key, expiration, HttpMethod.GET);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#generatePresignedUrl(java.lang.String, java.lang.String, java.util.Date, com.amazonaws.HttpMethod)
     */
    public URL generatePresignedUrl(String bucketName, String key, Date expiration, HttpMethod method)
            throws OnestClientException {
        GeneratePresignedUrlRequest request = new GeneratePresignedUrlRequest(bucketName, key, method);
        request.setExpiration(expiration);

        return generatePresignedUrl(request);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#generatePresignedUrl(com.request.GeneratePresignedUrlRequest)
     */
    public URL generatePresignedUrl(GeneratePresignedUrlRequest generatePresignedUrlRequest)
            throws OnestClientException {
        assertParameterNotNull(generatePresignedUrlRequest,
            "The request parameter must be specified when generating a pre-signed URL");

        String bucketName = generatePresignedUrlRequest.getBucketName();
        String key = generatePresignedUrlRequest.getKey();

        assertParameterNotNull(bucketName,
            "The bucket name parameter must be specified when generating a pre-signed URL");
        assertParameterNotNull(generatePresignedUrlRequest.getMethod(),
            "The HTTP method request parameter must be specified when generating a pre-signed URL");

        if (generatePresignedUrlRequest.getExpiration() == null) {
            generatePresignedUrlRequest.setExpiration(
                    new Date(System.currentTimeMillis() + 1000 * 60 * 15));
        }

        Request<Void> request = createRequest(bucketName, key, generatePresignedUrlRequest);
        for (Entry<String, String> entry : generatePresignedUrlRequest.getRequestParameters().entrySet()) {
            request.addParameter(entry.getKey(), entry.getValue());
        }

        presignRequest(request, generatePresignedUrlRequest.getMethod(),
                bucketName, key, generatePresignedUrlRequest.getExpiration(), null);

        return ServiceUtils.convertRequestToUrl(request);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#abortMultipartUpload(com.request.AbortMultipartUploadRequest)
     */
    public void abortMultipartUpload(AbortMultipartUploadRequest abortMultipartUploadRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(abortMultipartUploadRequest,
            "The request parameter must be specified when aborting a multipart upload");
        assertParameterNotNull(abortMultipartUploadRequest.getBucketName(),
            "The bucket name parameter must be specified when aborting a multipart upload");
        assertParameterNotNull(abortMultipartUploadRequest.getKey(),
            "The key parameter must be specified when aborting a multipart upload");
        assertParameterNotNull(abortMultipartUploadRequest.getUploadId(),
            "The upload ID parameter must be specified when aborting a multipart upload");

        String bucketName = abortMultipartUploadRequest.getBucketName();
        String key = abortMultipartUploadRequest.getKey();

        Request<Void> request = createRequest(bucketName, key, abortMultipartUploadRequest);
        request.addParameter("uploadId", abortMultipartUploadRequest.getUploadId());
        signRequest(request, HttpMethodName.DELETE, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.DELETE);

        client.execute(httpRequest, this.voidResponseHandler, this.errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#completeMultipartUpload(com.request.CompleteMultipartUploadRequest)
     */
    public CompleteMultipartUploadResult completeMultipartUpload(
            CompleteMultipartUploadRequest completeMultipartUploadRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(completeMultipartUploadRequest,
            "The request parameter must be specified when completing a multipart upload");

        String bucketName = completeMultipartUploadRequest.getBucketName();
        String key = completeMultipartUploadRequest.getKey();
        String uploadId = completeMultipartUploadRequest.getUploadId();
        assertParameterNotNull(bucketName,
            "The bucket name parameter must be specified when completing a multipart upload");
        assertParameterNotNull(key,
            "The key parameter must be specified when completing a multipart upload");
        assertParameterNotNull(uploadId,
            "The upload ID parameter must be specified when completing a multipart upload");
        assertParameterNotNull(completeMultipartUploadRequest.getPartETags(),
            "The part ETags parameter must be specified when completing a multipart upload");

        Request<Void> request = createRequest(bucketName, key, completeMultipartUploadRequest);
        request.addParameter("uploadId", uploadId);

        byte[] xml = RequestXmlFactory.convertToXmlByteArray(completeMultipartUploadRequest.getPartETags());
        request.addHeader("Content-Type", Mimetypes.MIMETYPE_OCTET_STREAM);
        request.addHeader("Content-Length", String.valueOf(xml.length));

        signRequest(request, HttpMethodName.POST, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.POST);
        httpRequest.setContent(new ByteArrayInputStream(xml));

        OnestXmlResponseHandler<CompleteMultipartUploadHandler> responseHandler =
            new OnestXmlResponseHandler<CompleteMultipartUploadHandler>(new Unmarshallers.CompleteMultipartUploadResultUnmarshaller());

        CompleteMultipartUploadHandler handler = client.execute(httpRequest, responseHandler, errorResponseHandler);
        if (handler.getCompleteMultipartUploadResult() != null) {
            String versionId = responseHandler.getResponseHeaders().get(Headers.ONEST_VERSION_ID);
            handler.getCompleteMultipartUploadResult().setVersionId(versionId);
            return handler.getCompleteMultipartUploadResult();
        } else {
            throw handler.getOnestException();
        }
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#initiateMultipartUpload(com.request.InitiateMultipartUploadRequest)
     */
    public InitiateMultipartUploadResult initiateMultipartUpload(
            InitiateMultipartUploadRequest initiateMultipartUploadRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(initiateMultipartUploadRequest,
            "The request parameter must be specified when initiating a multipart upload");

        String bucketName = initiateMultipartUploadRequest.getBucketName();
        String key = initiateMultipartUploadRequest.getKey();
        CannedAccessControlList cannedACL = initiateMultipartUploadRequest.getCannedACL();
        ObjectMetadata objectMetadata = initiateMultipartUploadRequest.objectMetadata;

        assertParameterNotNull(bucketName,
            "The bucket name parameter must be specified when initiating a multipart upload");
        assertParameterNotNull(key,
            "The key parameter must be specified when initiating a multipart upload");

        Request<Void> request = createRequest(bucketName, key, initiateMultipartUploadRequest);
        request.addParameter("uploads", null);

        if (cannedACL != null)
            request.addHeader(Headers.ONEST_CANNED_ACL, cannedACL.toString());

        if (initiateMultipartUploadRequest.getCopyPolicy() != null) {
            request.addHeader(Headers.COPYPOLICY, initiateMultipartUploadRequest.getCopyPolicy());
        }
 
        if (objectMetadata == null) objectMetadata = new ObjectMetadata();
        objectMetadata.setContentLength(0);
        
        if (objectMetadata.getContentType() == null) {
        	objectMetadata.setContentType(Mimetypes.MIMETYPE_OCTET_STREAM);
        }
        
        if (objectMetadata != null) populateRequestMetadata(request, objectMetadata);       
        
        signRequest(request, HttpMethodName.POST, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.POST);
        // Set the request content to be empty (but not null) to force the runtime to pass
        // any query params in the query string and not the request body, to keep Onest happy.
        httpRequest.setContent(new ByteArrayInputStream(new byte[0]));

        OnestXmlResponseHandler<InitiateMultipartUploadResult> responseHandler =
            new OnestXmlResponseHandler<InitiateMultipartUploadResult>(new Unmarshallers.InitiateMultipartUploadResultUnmarshaller());

        return (InitiateMultipartUploadResult)client.execute(httpRequest, responseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#listMultipartUploads(com.request.ListMultipartUploadsRequest)
     */
    public MultipartUploadListing listMultipartUploads(ListMultipartUploadsRequest listMultipartUploadsRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(listMultipartUploadsRequest,
            "The request parameter must be specified when listing multipart uploads");

        String bucketName = listMultipartUploadsRequest.getBucketName();
        String keyMarker = listMultipartUploadsRequest.getKeyMarker();
        Integer maxUploads = listMultipartUploadsRequest.getMaxUploads();
        String uploadIdMarker = listMultipartUploadsRequest.getUploadIdMarker();

        assertParameterNotNull(bucketName,
            "The bucket name parameter must be specified when listing multipart uploads");

        Request<Void> request = createRequest(bucketName, null, listMultipartUploadsRequest);
        request.addParameter("uploads", null);

        if (keyMarker != null) request.addParameter("key-marker", keyMarker);
        if (maxUploads != null) request.addParameter("max-uploads", maxUploads.toString());
        if (uploadIdMarker != null) request.addParameter("upload-id-marker", uploadIdMarker);

        signRequest(request, HttpMethodName.GET, bucketName, null);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        OnestXmlResponseHandler<MultipartUploadListing> responseHandler =
            new OnestXmlResponseHandler<MultipartUploadListing>(new Unmarshallers.ListMultipartUploadsResultUnmarshaller());

        return (MultipartUploadListing)client.execute(httpRequest, responseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#listParts(com.request.ListPartsRequest)
     */
    public PartListing listParts(ListPartsRequest listPartsRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(listPartsRequest,
            "The request parameter must be specified when listing parts");

        String bucketName = listPartsRequest.getBucketName();
        String key = listPartsRequest.getKey();
        String uploadId = listPartsRequest.getUploadId();
        Integer maxParts = listPartsRequest.getMaxParts();
        Integer partNumberMarker = listPartsRequest.getPartNumberMarker();

        assertParameterNotNull(bucketName,
            "The bucket name parameter must be specified when listing parts");
        assertParameterNotNull(key,
            "The key parameter must be specified when listing parts");
        assertParameterNotNull(uploadId,
            "The upload ID parameter must be specified when listing parts");

        Request<Void> request = createRequest(bucketName, key, listPartsRequest);
        request.addParameter("uploadId", uploadId);

        if (maxParts != null) request.addParameter("max-parts", maxParts.toString());
        if (partNumberMarker != null) request.addParameter("part-number-marker", partNumberMarker.toString());

        signRequest(request, HttpMethodName.GET, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        OnestXmlResponseHandler<PartListing> responseHandler =
            new OnestXmlResponseHandler<PartListing>(new Unmarshallers.ListPartsResultUnmarshaller());

        return (PartListing)client.execute(httpRequest, responseHandler, errorResponseHandler);
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#uploadPart(com.request.UploadPartRequest)
     */
    public UploadPartResult uploadPart(UploadPartRequest uploadPartRequest)
            throws OnestClientException, OnestServiceException {
        assertParameterNotNull(uploadPartRequest,
            "The request parameter must be specified when uploading a part");

        String bucketName = uploadPartRequest.getBucketName();
        String key        = uploadPartRequest.getKey();
        String uploadId   = uploadPartRequest.getUploadId();
        int partNumber    = uploadPartRequest.getPartNumber();
        long partSize     = uploadPartRequest.getPartSize();

        assertParameterNotNull(bucketName,
            "The bucket name parameter must be specified when uploading a part");
        assertParameterNotNull(key,
            "The key parameter must be specified when uploading a part");
        assertParameterNotNull(uploadId,
            "The upload ID parameter must be specified when uploading a part");
        assertParameterNotNull(partNumber,
            "The part number parameter must be specified when uploading a part");
        assertParameterNotNull(partSize,
            "The part size parameter must be specified when uploading a part");

        Request<Void> request = createRequest(bucketName, key, uploadPartRequest);
        request.addParameter("uploadId", uploadId);
        request.addParameter("partNumber", Integer.toString(partNumber));

        if (uploadPartRequest.getMd5Digest() != null)
            request.addHeader(Headers.CONTENT_MD5, uploadPartRequest.getMd5Digest());

        request.addHeader(Headers.CONTENT_OFFSET, Long.toString(uploadPartRequest.getFileOffset()));
            
        signRequest(request, HttpMethodName.PUT, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.PUT);
        httpRequest.addHeader(Headers.CONTENT_LENGTH, Long.toString(partSize));
        
        InputStream inputStream = null;
        if (uploadPartRequest.getInputStream() != null) {
            inputStream = uploadPartRequest.getInputStream();
            request.addHeader(Headers.CONTENT_TYPE, Mimetypes.MIMETYPE_OCTET_STREAM);
        } else if (uploadPartRequest.getFile() != null) {
            try { 
            	File file = uploadPartRequest.getFile();
                inputStream = new InputSubstream(new FileInputStream(file),
                        uploadPartRequest.getFileOffset(), partSize);
                request.addHeader(Headers.CONTENT_TYPE, Mimetypes.getInstance().getMimetype(file));
            } catch (FileNotFoundException e) {
                throw new IllegalArgumentException("The specified file doesn't exist", e);
            }
        } else {
            throw new IllegalArgumentException("A File or InputStream must be specified when uploading part");
        }

        ProgressListener progressListener = uploadPartRequest.getProgressListener();
        if (progressListener != null) {
            inputStream = new ProgressReportingInputStream(inputStream, progressListener);
            fireProgressEvent(progressListener, ProgressEvent.PART_STARTED_EVENT_CODE);
        }

        try {
            httpRequest.setContent(inputStream);
            OnestMetadataResponseHandler responseHandler = new OnestMetadataResponseHandler();
            ObjectMetadata metadata = client.execute(httpRequest, responseHandler, errorResponseHandler);
            fireProgressEvent(progressListener, ProgressEvent.PART_COMPLETED_EVENT_CODE);
            
            UploadPartResult result = new UploadPartResult();
            result.setETag(metadata.getETag());
            result.setPartNumber(partNumber);
            return result;
        } catch (OnestClientException ace) {
            fireProgressEvent(progressListener, ProgressEvent.PART_FAILED_EVENT_CODE);
            throw ace;
        } finally {
            if (inputStream != null) {
                try {inputStream.close();}
                catch (Exception e) {}
            }
        }
    }

    /* (non-Javadoc)
     * @see com.onest.client.Onest#getResponseMetadataForRequest(com.request.OnestWebServiceRequest)
     */
    public OnestResponseMetadata getCachedResponseMetadata(OnestWebServiceRequest request) {
        return (OnestResponseMetadata)client.getResponseMetadataForRequest(request);
    }

    /*
     * Private Interface
     */

    /**
     * <p>
     * Asserts that the specified parameter value is not <code>null</code> and if it is,
     * throws an <code>IllegalArgumentException</code> with the specified error message.
     * </p>
     *
     * @param parameterValue
     *            The parameter value being checked.
     * @param errorMessage
     *            The error message to include in the IllegalArgumentException
     *            if the specified parameter is null.
     */
    private void assertParameterNotNull(Object parameterValue, String errorMessage) {
        if (parameterValue == null) throw new IllegalArgumentException(errorMessage);
    }

    /**
     * Fires a progress event with the specified event type to the specified
     * listener.
     * 
     * @param listener
     *            The listener to receive the event.
     * @param eventType
     *            The type of event to fire.
     */
    private void fireProgressEvent(ProgressListener listener, int eventType) {
        if (listener == null) return;
        ProgressEvent event = new ProgressEvent(0);
        event.setEventCode(eventType);
        listener.progressChanged(event);
    }

    /**
     * <p>
     * Gets the Onest {@link AccessControlList} (ACL) for the specified resource.
     * (bucket if only the bucketName parameter is specified, otherwise the object with the
     * specified key in the bucket).
     * </p>
     *
     * @param bucketName
     *            The name of the bucket whose ACL should be returned if the key
     *            parameter is not specified, otherwise the bucket containing
     *            the specified key.
     * @param key
     *            The object key whose ACL should be retrieve. If not specified,
     *            the bucket's ACL is returned.
     * @param versionId
     *            The version ID of the object version whose ACL is being
     *            retrieved.
     *
     * @return The Onest ACL for the specified resource.
     */
    private AccessControlList getAcl(String bucketName, String key, String versionId) {
        Request<Void> request = createRequest(bucketName, key, null);
        request.addParameter("acl", null);
        if (versionId != null) request.addParameter("versionId", versionId);

        signRequest(request, HttpMethodName.GET, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);

        OnestXmlResponseHandler<AccessControlList> responseHandler =
            new OnestXmlResponseHandler<AccessControlList>(new Unmarshallers.AccessControlListUnmarshaller());

        return (AccessControlList)client.execute(httpRequest, responseHandler, errorResponseHandler);
    }

    /**
     * Creates and initializes a new request object for the specified Onest
     * resource. This method is responsible for determining the right way to
     * address resources. For example, bucket names that are not DNS addressable
     * cannot be addressed in virtual host style, and instead must use path style. 
     * The returned request object has the service name, endpoint
     * and resource path correctly populated. Callers can take the request, add
     * any additional headers or parameters, then sign and execute the request.
     *
     * @param bucketName
     *            An optional parameter indicating the name of the bucket
     *            containing the resource involved in the request.
     * @param key
     *            An optional parameter indicating the key under which the
     *            desired resource is stored in the specified bucket.
     * @param originalRequest
     *            The original request, as created by the user.
     *
     * @return A new request object, populated with endpoint, resource path, and
     *         service name, ready for callers to populate any additional
     *         headers or parameters, and execute.
     */
    protected Request<Void> createRequest(String bucketName, String key, OnestWebServiceRequest originalRequest) {
        Request<Void> request = new DefaultRequest<Void>(originalRequest, Constants.ONEST_SERVICE_NAME);
        if (request.getHeaders().get(Headers.HOST) == null) {
            request.addHeader(Headers.HOST, "obs.chinamobile.com");
        } 
        request.setEndpoint(endpoint);
        
        if (bucketName != null) {
        	request.setResourcePath(bucketName 
                    + (key != null ? ("/" + ServiceUtils.urlEncode(key)) : ""));            	
        }
        else{
        	request.setResourcePath("/");
        }   
        
        return request;
    }
    
    protected Request<Void> createLocationRequest(String bucketName, OnestWebServiceRequest originalRequest) {
        Request<Void> request = new DefaultRequest<Void>(originalRequest, Constants.ONEST_SERVICE_NAME);
        if (request.getHeaders().get(Headers.HOST) == null) {
            request.addHeader(Headers.HOST, "obs.chinamobile.com");
        } 
        request.setEndpoint(endpoint);
        
        if (bucketName != null) {
        	request.setResourcePath("/rest/" + bucketName);            	
        }
        else{
        	request.setResourcePath("/rest/");
        }   
        
        return request;
    }

    /**
     * Sets the Canned ACL for the specified resource in Onest. If only bucketName
     * is specified, the canned ACL will be applied to the bucket, otherwise if
     * bucketName and key are specified, the canned ACL will be applied to the
     * object.
     *
     * @param bucketName
     *            The name of the bucket containing the specified key, or if no
     *            key is listed, the bucket whose ACL will be set.
     * @param key
     *            The optional object key within the specified bucket whose ACL
     *            will be set. If not specified, the bucket ACL will be set.
     * @param versionId
     *            The version ID of the object version whose ACL is being set.
     * @param cannedAcl
     *            The canned ACL to apply to the resource.
     */
    private void setAcl(String bucketName, String key, String versionId, CannedAccessControlList cannedAcl) {
        Request<Void> request = createRequest(bucketName, key, null);
        request.addParameter("acl", null);
        request.addHeader(Headers.ONEST_CANNED_ACL, cannedAcl.toString());
        if (versionId != null) request.addParameter("versionId", versionId);

        signRequest(request, HttpMethodName.PUT, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.PUT);

        client.execute(httpRequest, voidResponseHandler, errorResponseHandler);
    }

    /**
     * Sets the ACL for the specified resource in Onest. If only bucketName is
     * specified, the ACL will be applied to the bucket, otherwise if bucketName
     * and key are specified, the ACL will be applied to the object.
     *
     * @param bucketName
     *            The name of the bucket containing the specified key, or if no
     *            key is listed, the bucket whose ACL will be set.
     * @param key
     *            The optional object key within the specified bucket whose ACL
     *            will be set. If not specified, the bucket ACL will be set.
     * @param versionId
     *            The version ID of the object version whose ACL is being set.
     * @param acl
     *            The ACL to apply to the resource.
     */
    private void setAcl(String bucketName, String key, String versionId, AccessControlList acl) {
        Request<Void> request = createRequest(bucketName, key, null);
        request.addParameter("acl", null);
        if (versionId != null) request.addParameter("versionId", versionId);

        byte[] aclAsXml = new AclXmlFactory().convertToXmlByteArray(acl);
        //request.addHeader("Content-Type", "text/plain");
        request.addHeader("Content-Length", String.valueOf(aclAsXml.length));

        signRequest(request, HttpMethodName.PUT, bucketName, key);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.PUT);
        httpRequest.setContent(new ByteArrayInputStream(aclAsXml));

        client.execute(httpRequest, voidResponseHandler, errorResponseHandler);
    }

    /**
     * Signs the specified request.
     *
     * @param request
     *            The request to sign.
     * @param methodName
     *            The HTTP method (GET, PUT, DELETE, HEAD) for the specified
     *            request.
     * @param bucketName
     *            The name of the bucket involved in the request. If the request
     *            is not an operation on a bucket this parameter should be null.
     * @param key
     *            The object key involved in the request. If the request is not
     *            an operation on an object, this parameter should be null.
     */
    protected <T> void signRequest(Request<T> request, HttpMethodName methodName, String bucketName, String key) {
        // Run any additional request handlers if necessary
        if (requestHandlers != null) {
            for (RequestHandler requestHandler : requestHandlers) {
                request = requestHandler.handleRequest(request);
            }
        }

        // Nothing to sign if the client is anonymous and we have no credentials
        if (onestCredentials == null) return;

        if (bAnonymousUser) return;

        /*
         * The string we sign needs to include the exact headers that we
         * send with the request, but the client runtime layer adds the
         * Content-Type header before the request is sent if one isn't set, so
         * we have to set something here otherwise the request will fail.
         */
        /*
        if (request.getHeaders().get("Content-Type") == null) {
            request.addHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
        }*/
        
        try {
        	String resourcePath =
                "/" +
                ((bucketName != null) ? bucketName : "") +
                ((key != null) ? ("/" + key) : "");
                //((key != null) ? ("/" + ServiceUtils.urlEncode(key)) : "");            
        	new OnestSigner(onestCredentials, methodName.toString(), resourcePath).sign(request, null, null);
        } catch (SignatureException e) {
            throw new OnestClientException("Unable to sign request: " + e.getMessage(), e);
        }
    }
    
    protected <T> void signLocationRequest(Request<T> request, HttpMethodName methodName, String bucketName, String key) {
        // Run any additional request handlers if necessary
        if (requestHandlers != null) {
            for (RequestHandler requestHandler : requestHandlers) {
                request = requestHandler.handleRequest(request);
            }
        }

        // Nothing to sign if the client is anonymous and we have no credentials
        if (onestCredentials == null) return;

        if (bAnonymousUser) return;
        
        /*
         * The string we sign needs to include the exact headers that we
         * send with the request, but the client runtime layer adds the
         * Content-Type header before the request is sent if one isn't set, so
         * we have to set something here otherwise the request will fail.
         */
        /*
        if (request.getHeaders().get("Content-Type") == null) {
            request.addHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
        }*/
        
        try {
        	String resourcePath =
                "/rest/" +
                ((bucketName != null) ? bucketName : "") +
                ((key != null) ? ("/" + key) : "");
                //((key != null) ? ("/" + ServiceUtils.urlEncode(key)) : "");            
        	new OnestSigner(onestCredentials, methodName.toString(), resourcePath).sign(request, null, null);
        } catch (SignatureException e) {
            throw new OnestClientException("Unable to sign request: " + e.getMessage(), e);
        }
    }

    /**
     * Pre-signs the specified request, using a signature query-string
     * parameter.
     *
     * @param request
     *            The request to sign.
     * @param methodName
     *            The HTTP method (GET, PUT, DELETE, HEAD) for the specified
     *            request.
     * @param bucketName
     *            The name of the bucket involved in the request. If the request
     *            is not an operation on a bucket this parameter should be null.
     * @param key
     *            The object key involved in the request. If the request is not
     *            an operation on an object, this parameter should be null.
     * @param expiration
     *            The time at which the signed request is no longer valid, and
     *            will stop working.
     * @param subResource
     *            The optional sub-resource being requested as part of the
     *            request (e.g. "location", "acl", or "logging").
     */
    private <T> void presignRequest(Request<T> request, HttpMethod methodName,
            String bucketName, String key, Date expiration, String subResource) {
        // Run any additional request handlers if necessary
        if (requestHandlers != null) {
            for (RequestHandler requestHandler : requestHandlers) {
                request = requestHandler.handleRequest(request);
            }
        }

        try {
            String resourcePath =
                "/" +
                ((bucketName != null) ? bucketName + "/" : "") +
                ((key != null) ? ServiceUtils.urlEncode(key) : "") +
                ((subResource != null) ? "?" + subResource : "");
            new OnestQueryStringSigner<T>(onestCredentials, methodName.toString(), resourcePath, expiration).sign(request);
        } catch (SignatureException e) {
            throw new OnestClientException("Unable to sign request: " + e.getMessage(), e);
        }

        // The Onest DevPay token header is a special exception and can be safely moved
        // from the request's headers into the query string to ensure that it travels along
        // with the pre-signed URL when it's sent back to Onest.
        if (request.getHeaders().containsKey(Headers.SECURITY_TOKEN)) {
            String value = request.getHeaders().get(Headers.SECURITY_TOKEN);
            request.addParameter(Headers.SECURITY_TOKEN, value);
            request.getHeaders().remove(Headers.SECURITY_TOKEN);
        }
    }

    /**
     * Converts the current endpoint set for this client into virtual addressing
     * style, by placing the name of the specified bucket before the Onest service
     * endpoint.
     *
     * @param bucketName
     *            The name of the bucket to use in the virtual addressing style
     *            of the returned URI.
     *
     * @return A new URI, creating from the current service endpoint URI and the
     *         specified bucket.
     */
    private URI convertToVirtualHostEndpoint(String bucketName) {
        try {
            return new URI(endpoint.getScheme() + "://" + bucketName + "." + endpoint.getAuthority());
        } catch (URISyntaxException e) {
            throw new OnestClientException("Can't turn bucket name into a URI: " + e.getMessage(), e);
        }
    }

    /**
     * <p>
     * Populates the specified request object with the appropriate headers from
     * the {@link ObjectMetadata} object.
     * </p>
     *
     * @param request
     *            The request to populate with headers.
     * @param metadata
     *            The metadata containing the header information to include in
     *            the request.
     */
    protected static void populateRequestMetadata(Request<Void> request, ObjectMetadata metadata) {
        Map<String, Object> rawMetadata = metadata.getRawMetadata();
        if (rawMetadata != null) {
            for (Entry<String, Object> entry : rawMetadata.entrySet()) {
                request.addHeader(entry.getKey(), entry.getValue().toString());
            }
        }

        Map<String, String> userMetadata = metadata.getUserMetadata();
        if (userMetadata != null) {
            for (Entry<String, String> entry : userMetadata.entrySet()) {
                request.addHeader(Headers.ONEST_USER_METADATA_PREFIX + entry.getKey(), entry.getValue());
            }
        }
    }

    /**
     * <p>
     * Populates the specified request with the specified Multi-Factor
     * Authentication (MFA) details. This includes the MFA header with device serial
     * number and generated token. Since all requests which include the MFA
     * header must be sent over HTTPS, this operation also configures the request object to
     * use HTTPS instead of HTTP.
     * </p>
     *
     * @param request
     *            The request to populate.
     * @param mfa
     *            The Multi-Factor Authentication information.
     */
    private void populateRequestWithMfaDetails(Request<Void> request, MultiFactorAuthentication mfa) {
        if (mfa == null) return;

        String endpoint = request.getEndpoint().toString();
        if (endpoint.startsWith("http://")) {
            String httpsEndpoint = endpoint.replace("http://", "https://");
            request.setEndpoint(URI.create(httpsEndpoint));
            log.info("Overriding current endpoint to use HTTPS " +
                    "as required by Onest for requests containing an MFA header");
        }

        request.addHeader(Headers.ONEST_MFA,
                mfa.getDeviceSerialNumber() + " " + mfa.getToken());
    }

    /**
     * <p>
     * Populates the specified request with the numerous options available in
     * <code>CopyObjectRequest</code>.
     * </p>
     *
     * @param request
     *            The request to populate with headers to represent all the
     *            options expressed in the <code>CopyObjectRequest</code> object.
     * @param copyObjectRequest
     *            The object containing all the options for copying an object in
     *            Onest.
     */
    private static void populateRequestWithCopyObjectParameters(Request<Void> request, CopyObjectRequest copyObjectRequest) {
        String copySourceHeader =
             //"/" + 
             ServiceUtils.urlEncode(copyObjectRequest.getSourceBucketName())
           + "/" + ServiceUtils.urlEncode(copyObjectRequest.getSourceKey());
        if (copyObjectRequest.getSourceVersionId() != null) {
            copySourceHeader += "?versionId=" + copyObjectRequest.getSourceVersionId();
        }
        request.addHeader("onest-copy-source", copySourceHeader);

        addDateHeader(request, Headers.COPY_SOURCE_IF_MODIFIED_SINCE,
                copyObjectRequest.getModifiedSinceConstraint());
        addDateHeader(request, Headers.COPY_SOURCE_IF_UNMODIFIED_SINCE,
                copyObjectRequest.getUnmodifiedSinceConstraint());

        addStringListHeader(request, Headers.COPY_SOURCE_IF_MATCH,
                copyObjectRequest.getMatchingETagConstraints());
        addStringListHeader(request, Headers.COPY_SOURCE_IF_NO_MATCH,
                copyObjectRequest.getNonmatchingETagConstraints());

        if (copyObjectRequest.getCannedAccessControlList() != null) {
            request.addHeader(Headers.ONEST_CANNED_ACL,
                    copyObjectRequest.getCannedAccessControlList().toString());
        }

        if (copyObjectRequest.getStorageClass() != null) {
            request.addHeader(Headers.STORAGE_CLASS, copyObjectRequest.getStorageClass());
        }

        ObjectMetadata newObjectMetadata = copyObjectRequest.getNewObjectMetadata();
        if (newObjectMetadata != null) {
            request.addHeader(Headers.METADATA_DIRECTIVE, "REPLACE");
            populateRequestMetadata(request, newObjectMetadata);
        }
    }

    /**
     * <p>
     * Adds the specified date header in RFC 822 date format to the specified
     * request.
     * This method will not add a date header if the specified date value is <code>null</code>.
     * </p>
     *
     * @param request
     *            The request to add the header to.
     * @param header
     *            The header name.
     * @param value
     *            The header value.
     */
    private static void addDateHeader(Request<?> request, String header, Date value) {
        if (value != null) {
            request.addHeader(header, ServiceUtils.formatRfc822Date(value));
        }
    }

    /**
     * <p>
     * Adds the specified string list header, joined together separated with
     * commas, to the specified request.
     * This method will not add a string list header if the specified values
     * are <code>null</code> or empty.
     * </p>
     *
     * @param request
     *            The request to add the header to.
     * @param header
     *            The header name.
     * @param values
     *            The list of strings to join together for the header value.
     */
    private static void addStringListHeader(Request<?> request, String header, List<String> values) {
        if (values != null && !values.isEmpty()) {
            request.addHeader(header, ServiceUtils.join(values));
        }
    }

	@Override
	public UserSpaceStat getUserStat(CreateGetUserStatRequest createGetUserStatRequest)
			throws OnestClientException, OnestServiceException {
		// TODO Auto-generated method stub
    	assertParameterNotNull(createGetUserStatRequest,"The CreateGetUserStatRequest parameter must be specified when GetUserStatRequest");
		
		Request<Void> request = createLocationRequest("", createGetUserStatRequest);
		request.addParameter("userstat", null);
		request.addParameter("user", createGetUserStatRequest.GetUserName());
		
		signLocationRequest(request, HttpMethodName.GET, null, null);
		HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);
		
		OnestXmlResponseHandler<UserSpaceStat> responseHandler =
		    new OnestXmlResponseHandler<UserSpaceStat>(new Unmarshallers.UserStatUnmarshaller());
		
		return (UserSpaceStat)client.execute(httpRequest, responseHandler, errorResponseHandler);
		
	}

	@Override
	public BucketStat getBucketStat(CreateGetBucketStatRequest createGetBucketStatRequest)
			throws OnestClientException, OnestServiceException {
		// TODO Auto-generated method stub
    	assertParameterNotNull(createGetBucketStatRequest,"The CreateGetBucketStatRequest parameter must be specified when GetUserStatRequest");
		
		Request<Void> request = createLocationRequest("", createGetBucketStatRequest);
		request.addParameter("bucketstat", null);
		request.addParameter("bucket", createGetBucketStatRequest.GetBucketName());
		
		signLocationRequest(request, HttpMethodName.GET, null, null);
		HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);
		
		OnestXmlResponseHandler<BucketStat> responseHandler =
		    new OnestXmlResponseHandler<BucketStat>(new Unmarshallers.BucketStatUnmarshaller());
		
		return (BucketStat)client.execute(httpRequest, responseHandler, errorResponseHandler);
	}

	@Override
	public UserSpaceStat getUserStat(String userName)
			throws OnestClientException, OnestServiceException {
		// TODO Auto-generated method stub
		return getUserStat(new CreateGetUserStatRequest(userName));
	}

	@Override
	public BucketStat getBucketStat(String bucketName)
			throws OnestClientException, OnestServiceException {
		// TODO Auto-generated method stub
		return getBucketStat(new CreateGetBucketStatRequest(bucketName));
	}

    /**
	 * @param containerName: the bucket name
	 * @param objectId: the object name
	 * @param expireTime: the openUrl expire time
	 * @param bAnonymous: generate the openUrl for anonymous or regiseter user, 
	 * 				true is for anonymous, false is for register user  
	 * @return URL: the returned open url, null if the open url is failed to be
	 *              generated with the reason of no permission to create or the anonymos
	 *              user to create the openurl with register user
	 */
	@Override
	public URL getObjectAccessUrl(String containerName,String objectId, long expireTime, boolean bAnonymous)
			throws OnestClientException, OnestServiceException {
		// TODO Auto-generated method stub
		checkObjectReadAcl(new CheckObjectReadAclRequest(containerName, objectId, expireTime, bAnonymous));
		String resourcePath = "/" +containerName + "/" + objectId;
		URL openURL = null;		
		String openUrl = endpoint.toString();
		log.info("openUrl: " + openUrl);
		if(bAnonymous == true){
			openUrl = openUrl + resourcePath + "?Expires=" + expireTime;
			System.out.println("openUrl: " + openUrl);
			try {
				openURL = new URL(openUrl);
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return openURL;
		}
		
		//calcature the Signature
		GetObjectRequest getObjectRequest  = new GetObjectRequest(containerName, objectId);
		Request<Void> request = createRequest(containerName, objectId, getObjectRequest);
		            
		OnestSigner os = new OnestSigner(onestCredentials, HttpMethodName.GET.toString(), 
									resourcePath);
		String Signature = null;
		try {
			Signature = os.sign(request, null, null, expireTime);
		} catch (SignatureException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return openURL;
		}
		
		log.info("Signature: " + Signature);
		try {
			Signature = URLEncoder.encode(Signature, "UTF-8");
		} catch (UnsupportedEncodingException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		log.info("Signature after encode: " + Signature);
		openUrl = openUrl + resourcePath + "?AccessId=" + onestCredentials.getOnestAccessID()
					+"&Expires=" + expireTime+"&Signature=" + Signature;
		
		log.info("openUrl: " + openUrl);
		
		try {
			openURL = new URL(openUrl);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return openURL;
		
	}

	@Override
	public void checkObjectReadAcl(CheckObjectReadAclRequest checkObjectReadAclRequest)
			throws OnestClientException, OnestServiceException {
		// TODO Auto-generated method stub
		String containerName = checkObjectReadAclRequest.getContainerName();
		String objectId = checkObjectReadAclRequest.getObjectId();
		long expireTime = checkObjectReadAclRequest.getExpireTime();
		boolean bAnonymous = checkObjectReadAclRequest.getBAnonymous();
		
        assertParameterNotNull(containerName, "The bucket name parameter must be specified when getObjectAccessUrl");
        assertParameterNotNull(objectId, "The objectId name parameter must be specified when getObjectAccessUrl");
        assertParameterNotNull(expireTime, "The bucket expires parameter must be specified when getObjectAccessUrl");
        assertParameterNotNull(bAnonymous, "The generate mode, anonymous or not must be specified when getObjectAccessUrl");
        if(expireTime <= (System.currentTimeMillis()/1000))
        	throw new OnestClientException("The expireTime is invalid, it should be bigger than the current time!"
        			+"current time: "+ System.currentTimeMillis()/1000+", expireTime: " +expireTime);
        	
        Request<Void> request = createRequest(containerName, objectId, checkObjectReadAclRequest);
        request.addParameter("checkAcl ", null);
        if(bAnonymous){
        	setBAnonymousUser(bAnonymous);
        }
        signRequest(request, HttpMethodName.GET, containerName, objectId);
        HttpRequest httpRequest = convertToHttpRequest(request, HttpMethodName.GET);
        client.execute(httpRequest, voidResponseHandler, errorResponseHandler);	
	}


}
