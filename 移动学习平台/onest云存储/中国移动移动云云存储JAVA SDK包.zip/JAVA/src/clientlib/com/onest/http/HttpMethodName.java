package com.onest.http;

public enum HttpMethodName {
	 GET, POST, PUT, DELETE, HEAD;
}
