package com.onest.handlers;

import com.onest.metainfo.ResponseMetadata;

/**
 * Represents the response from an Onest service, including the result payload and
 * any response metadata. Onest response metadata consists primarily of the Onest
 * request ID, which can be used for debugging purposes when services aren't
 * acting as expected.
 *
 * @param <T>
 *            The type of result contained by this response.
 */
public class OnestWebServiceResponse<T> {
	/** The result contained by this response */
    private T result;

    /** Additional Onest metadata for this response */
    private ResponseMetadata responseMetadata;

    /**
     * Returns the result contained by this response.
     *
     * @return The result contained by this response.
     */
    public T getResult() {
        return result;
    }

    /**
     * Sets the result contained by this response.
     *
     * @param result
     *            The result contained by this response.
     */
    public void setResult(T result) {
        this.result = result;
    }

    /**
     * Sets the response metadata associated with this response.
     * 
     * @param responseMetadata
     *            The response metadata for this response.
     */
    public void setResponseMetadata(ResponseMetadata responseMetadata) {
        this.responseMetadata = responseMetadata;
    }

    /**
     * Returns the response metadata for this response. Response metadata
     * provides additional information about a response that isn't necessarily
     * directly part of the data the service is returning. Response metadata is
     * primarily used for debugging issues with Onest support when a service isn't
     * working as expected.
     * 
     * @return The response metadata for this response.
     */
    public ResponseMetadata getResponseMetadata() {
        return responseMetadata;
    }

    /**
     * Returns the Onest request ID from the response metadata section of an Onest
     * response.
     *
     * @return The Onest request ID from the response metadata section of an Onest
     *         response.
     */
    public String getRequestId() {
        if (responseMetadata == null) return null;
        return responseMetadata.getRequestId();
    }
}
