package com.onest.auth;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
/**
 * Simple InputStream wrapper that examines the wrapped stream's contents as
 * they are read and calculates and MD5 digest.
 */
public class MD5DigestCalculatingInputStream extends FilterInputStream {
	/** The MD5 message digest being calculated by this input stream */
    private MessageDigest digest;
    
    public MD5DigestCalculatingInputStream(InputStream in) throws NoSuchAlgorithmException {
        super(in);
        
        digest = MessageDigest.getInstance("MD5");
    }

    public byte[] getMd5Digest() {
        return digest.digest();
    }

    /**
     * Resets the wrapped input stream and the in progress message digest.
     * 
     * @see java.io.InputStream#reset()
     */
    @Override
    public synchronized void reset() throws IOException {
        try {
            digest = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            /*
             * Not much to do here. We know the algorithm existed when we
             * created the initial MessageDigest in the constructor, so we
             * can be reasonably sure that it's still going to exist if the
             * stream gets reset.
             */
        }

        in.reset();
    }

    /**
     * @see java.io.InputStream#read()
     */
    @Override
    public int read() throws IOException {
        int ch = in.read();
        if (ch != -1) {
            digest.update((byte)ch);
        }
        return ch;
    }

    /**
     * @see java.io.InputStream#read(byte[], int, int)
     */
    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        int result = in.read(b, off, len);
        if (result != -1) {
            digest.update(b, off, result);
        }
        return result;
    }
}
