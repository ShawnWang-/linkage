package com.onest.handlers;

import java.text.ParseException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.onest.http.HttpResponse;
import com.onest.metainfo.Headers;
import com.onest.metainfo.ObjectMetadata;
import com.onest.metainfo.OnestResponseMetadata;
import com.onest.metainfo.ResponseMetadata;
import com.onest.util.ServiceUtils;

/**
 * Abstract HTTP response handler for Onest responses. Provides common
 * utilities that other specialized Onest response handlers need to share such as
 * pulling common response metadata (ex: request IDs) out of headers.
 *
 * @param <T>
 *            The output type resulting from handling a response.
 */
public abstract class AbstractOnestResponseHandler<T> implements
		HttpResponseHandler<OnestWebServiceResponse<T>> {
   /** Shared logger */
    private static final Log log = LogFactory.getLog(OnestMetadataResponseHandler.class);
		
    /** The set of response headers that aren't part of the object's metadata */
    private static final Set<String> ignoredHeaders;

    static {
        ignoredHeaders = new HashSet<String>();
        ignoredHeaders.add(Headers.DATE);
        ignoredHeaders.add(Headers.SERVER);
        ignoredHeaders.add(Headers.REQUEST_ID);
        ignoredHeaders.add(Headers.EXTENDED_REQUEST_ID);
    }

    /**
     * The majority of Onest response handlers read the complete response while
     * handling it, and don't need to manually manage the underlying HTTP
     * connection.
     *
     * @see com.onest.handlers.HttpResponseHandler#needsConnectionLeftOpen()
     */
    public boolean needsConnectionLeftOpen() {
        return false;
    }

    /**
     * Parses the Onest response metadata (ex: Onest request ID) from the specified
     * response, and returns a OnestWebServiceResponse<T> object ready for the
     * result to be plugged in.
     *
     * @param response
     *            The response containing the response metadata to pull out.
     *
     * @return A new, populated OnestWebServiceResponse<T> object, ready for
     *         the result to be plugged in.
     */
    protected OnestWebServiceResponse<T> parseResponseMetadata(HttpResponse response) {
        OnestWebServiceResponse<T> onestResponse = new OnestWebServiceResponse<T>();
        String onestRequestId = response.getHeaders().get(Headers.REQUEST_ID);
        String hostId = response.getHeaders().get(Headers.EXTENDED_REQUEST_ID);

        Map<String, String> metadataMap = new HashMap<String, String>();
        metadataMap.put(ResponseMetadata.ONEST_REQUEST_ID, onestRequestId);
        metadataMap.put(OnestResponseMetadata.HOST_ID, hostId);
        onestResponse.setResponseMetadata(new OnestResponseMetadata(metadataMap));

        return onestResponse;
    }

    /**
     * Populates the specified OnestObjectMetadata object with all object metadata
     * pulled from the headers in the specified response.
     *
     * @param response
     *            The HTTP response containing the object metadata within the
     *            headers.
     * @param metadata
     *            The metadata object to populate from the response's headers.
     */
    protected void populateObjectMetadata(HttpResponse response, ObjectMetadata metadata) {
        for (Entry<String, String> header : response.getHeaders().entrySet()) {
            String key = header.getKey();
            if (key.startsWith(Headers.ONEST_USER_METADATA_PREFIX)) {
                key = key.substring(Headers.ONEST_USER_METADATA_PREFIX.length());
                metadata.addUserMetadata(key, header.getValue());
            } else if (ignoredHeaders.contains(key)) {
                // ignore...
            } else if (key.equals(Headers.LAST_MODIFIED)) {
                try {
                    metadata.setHeader(key, ServiceUtils.parseRfc822Date(header.getValue()));
                } catch (ParseException pe) {
                    log.warn("Unable to parse last modified date: " + header.getValue(), pe);
                }
            } else if (key.equals(Headers.CONTENT_LENGTH)) {
                try {
                    metadata.setHeader(key, Long.parseLong(header.getValue()));
                } catch (NumberFormatException nfe) {
                    log.warn("Unable to parse content length: " + header.getValue(), nfe);
                }
            } else if (key.equals(Headers.ETAG)) {
                metadata.setHeader(key, ServiceUtils.removeQuotes(header.getValue()));
            } else {
                metadata.setHeader(key, header.getValue());
            }
        }
    }

}
