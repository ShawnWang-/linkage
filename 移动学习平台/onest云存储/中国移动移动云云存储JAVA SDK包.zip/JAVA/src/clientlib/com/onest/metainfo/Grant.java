package com.onest.metainfo;

import java.util.List;



/**
 * Specifies a grant, consisting of one grantee and one permission.
 * 
 * @see Grant#Grant(Grantee, Permission)
 */
public class Grant {
	    private Grantee grantee = null;
	    private List<Permission> permission = null;

	    /**
	     * Constructs a new {@link Grant} object using the specified grantee and permission
	     * objects.
	     *
	     * @param grantee
	     *            The grantee being granted a permission by this grant.
	     * @param permission
	     *            The permission being granted to the grantee by this grant.
	     */
	    public Grant(Grantee grantee, List<Permission> permission) {
	        this.grantee = grantee;
	        this.permission = permission;
	    }

	    /**
	     * Gets the grantee being granted a permission by this grant.
	     *
	     * @return The grantee being granted a permission by this grant.
	     * 
	     * @see Grant#getPermission()
	     */
	    public Grantee getGrantee() {
	        return grantee;
	    }

	    /**
	     * Gets the permission being granted to the grantee by this grant.
	     *
	     * @return The permission being granted to the grantee by this grant.
	     * 
	     * @see Grant#getGrantee()
	     */
	    public List<Permission> getPermission() {
	        return permission;
	    }
    
	    public void setGrantee(Grantee grantee) {
	    	this.grantee = grantee;
	    }
	    
	    public void setPermission(List<Permission> permission) {
	        this.permission = permission;
	    }
	    
	    public void addPermission(Permission permission) {
	        this.permission.add(permission);
	    }
	    
	    public int hashCode() {
	        return (grantee + ":" + permission.toString()).hashCode();
	    }

	    public boolean equals(Object obj) {
	        return (obj instanceof Grant
	            && this.getGrantee().getIdentifier().equals(((Grant)obj).getGrantee().getIdentifier())
	            && (this.getPermission() == ((Grant)obj).getPermission()));
	    }
}
