package com.onest.metainfo;

import java.util.Map;




public class OnestResponseMetadata extends ResponseMetadata {
    public static final String HOST_ID = "HOST_ID";

    /**
     * Creates a new OnestResponseMetadata object from a specified map of metadata
     * information.
     *
     * @param metadata
     *            The raw metadata for the new OnestResponseMetadata object.
     */
    public OnestResponseMetadata(Map<String, String> metadata) {
        super(metadata);
    }

    /**
     * Creates a new OnestResponseMetadata object from an existing ResponseMetadata
     * object.
     *
     * @param originalResponseMetadata
     *            The ResponseMetadata object from which to create the new
     *            object.
     */
    public OnestResponseMetadata(ResponseMetadata originalResponseMetadata) {
        super(originalResponseMetadata);
    }

    /**
     * Returns the Onest host ID, providing additional debugging information
     * about how a request was handled. You can provide Onest support with this ID
     * to help troubleshoot issues where Onest isn't handling your request
     * as expected.
     *
     * @return The Onest host ID, providing additional debugging information
     *         about how a request was handled.
     */
    public String getHostId() {
        return metadata.get(HOST_ID);
    }

}
