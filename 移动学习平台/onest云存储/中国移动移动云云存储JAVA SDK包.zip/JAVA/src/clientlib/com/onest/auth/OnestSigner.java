package com.onest.auth;

import java.security.SignatureException;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.onest.metainfo.Headers;
import com.onest.request.Request;
import com.onest.util.RestUtils;
import com.onest.util.ServiceUtils;

/**
 * Implementation of the {@linkplain Signer} interface specific to Onest's signing
 * algorithm.
 */
public class OnestSigner extends AbstractOnestSigner implements Signer {

    /** Onest Credentials */
    private final OnestCredentials credentials;

    /** Shared log for signing debug output */
    private static final Log log = LogFactory.getLog(OnestSigner.class);

    /**
     * The HTTP verb (GET, PUT, HEAD, DELETE) the request to sign
     * is using.
     *
     * TODO: We need to know the HTTP verb in order to
     *       create the authentication signature, but we don't
     *       have easy access to it through the request object.
     *
     *       Maybe it'd be better for the Onest signer (or all signers?)
     *       to work directly off of the HttpRequest instead of
     *       the Request object?
     */
    private final String httpVerb;

    /**
     * The canonical resource path portion of the Onest string to sign.
     * Examples: "/", "/<bucket name>/", or "/<bucket name>/<key>"
     *
     * TODO: We don't want to hold the resource path as member data in the Onest
     *       signer, but we need access to it and can't get it through the
     *       request yet.
     */
    private final String resourcePath;

    /**
     * Constructs a new OnestSigner to sign requests based on the
     * Onest credentials, HTTP method and canonical Onest resource path.
     *
     * @param credentials
     *            The Onest credentials to use to sign the request.
     * @param httpVerb
     *            The HTTP verb (GET, PUT, POST, HEAD, DELETE) the request is
     *            using.
     * @param resourcePath
     *            The canonical Onest resource path (ex: "/", "/<bucket name>/", or
     *            "/<bucket name>/<key>".
     */
    public OnestSigner(OnestCredentials credentials, String httpVerb, String resourcePath) {
        this.credentials = credentials;
        this.httpVerb = httpVerb;
        this.resourcePath = resourcePath;

        if (resourcePath == null)
            throw new IllegalArgumentException("Parameter resourcePath is empty");
    }

    /* (non-Javadoc)
     * @see com.onest.auth.Signer#sign(com.onest.request.Request, com.onest.auth.SignatureVersion, com.onest.auth.SigningAlgorithm)
     */
    public void sign(Request<?> request, SignatureVersion version,
            SigningAlgorithm algorithm) throws SignatureException {
        request.addHeader(Headers.DATE, ServiceUtils.formatRfc822Date(new Date()));
        if (credentials == null) {
            log.debug("Canonical string will not be signed, as no Onest Secret Key was provided");
            request.addHeader("Authorization", "CMCC0 ");
            return;
        }
        
        String canonicalString = RestUtils.makeOnestCanonicalString(
                httpVerb, resourcePath, request, null);
        log.info("Calculated string to sign:\n\"" + canonicalString + "\"");

        String secretKey;
        String accessKeyId;
        synchronized (credentials) {
            secretKey = credentials.getOnestAccessSecretKey();
            accessKeyId = credentials.getOnestAccessID();
        }
        
        String signature = super.sign(canonicalString, secretKey, SigningAlgorithm.HmacSHA1);
        request.addHeader("Authorization", "CMCC " + accessKeyId + ":" + signature);
 
    }

    public String sign(Request<?> request, SignatureVersion version,
            SigningAlgorithm algorithm, long expireTime) throws SignatureException {
        request.addHeader(Headers.DATE, Long.toString(expireTime));
        if (credentials == null) {
            log.debug("Canonical string will not be signed, as no Onest Secret Key was provided");
            request.addHeader("Authorization", "CMCC0 ");
            return null;
        }
        
        String canonicalString = RestUtils.makeOnestCanonicalString(
                httpVerb, resourcePath, request, null);
        log.info("Calculated string to sign:\n\"" + canonicalString + "\"");

        String secretKey;
        synchronized (credentials) {
            secretKey = credentials.getOnestAccessSecretKey();
        }
        
        return super.sign(canonicalString, secretKey, SigningAlgorithm.HmacSHA1);
 
    }
}
