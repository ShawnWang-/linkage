package com.onest.metainfo;

import java.util.Date;


/**
 * Contains the summary of an object stored in an Onest bucket. This object
 * doesn't contain contain the
 * object's full metadata or any of its contents.
 * 
 * @see OnestObject
 */
public class OnestObjectSummary {
    /** The name of the bucket in which this object is stored */
    protected String bucketName;

    /** The key under which this object is stored */
    protected String key;

    /** Hex encoded MD5 hash of this object's contents, as computed by Onest */
    protected String eTag;

    /** The size of this object, in bytes */
    protected long size;

    /** The date, according to Onest, when this object was last modified */
    protected Date lastModified;

    /** The class of storage used by Onest to store this object */
    protected String storageClass;
    
    /**
     * The owner of this object - can be null if the requester doesn't have
     * permission to view object ownership information
     */
    protected Owner owner;

    protected String createTime;
    /**
     * Gets the name of the Onest bucket in which this object is stored.
     * 
     * @return The name of the Onest bucket in which this object is stored.
     * 
     * @see OnestObjectSummary#setBucketName(String)
     */
    public String getBucketName() {
        return bucketName;
    }

    /**
     * Sets the name of the Onest bucket in which this object is stored.
     * 
     * @param bucketName
     *            The name of the Onest bucket in which this object is
     *            stored.
     *            
     * @see OnestObjectSummary#getBucketName()          
     */
    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    /**
     * Gets the key under which this object is stored in Onest.
     * 
     * @return The key under which this object is stored in Onest.
     * 
     * @see OnestObjectSummary#setKey(String)
     */
    public String getKey() {
        return key;
    }

    /**
     * Sets the key under which this object is stored in Onest.
     * 
     * @param key
     *            The key under which this object is stored in Onest.
     *            
     * @see OnestObjectSummary#getKey()          
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * Gets the hex encoded 128-bit MD5 hash of this object's contents as
     * computed by Onest.
     * 
     * @return The hex encoded 128-bit MD5 hash of this object's contents as
     *         computed by Onest.
     *         
     * @see OnestObjectSummary#setETag(String)       
     */
    public String getETag() {
        return eTag;
    }

    /**
     * Sets the hex encoded 128-bit MD5 hash of this object's contents as
     * computed by Onest.
     * 
     * @param eTag
     *            The hex encoded 128-bit MD5 hash of this object's contents as
     *            computed by Onest.
     *            
     * @see OnestObjectSummary#getETag()             
     */
    public void setETag(String eTag) {
        this.eTag = eTag;
    }

    /**
     * Gets the size of this object in bytes.
     * 
     * @return The size of this object in bytes.
     * 
     * @see 3ObjectSummary#setSize(long)
     */
    public long getSize() {
        return size;
    }

    /**
     * Sets the size of this object in bytes.
     * 
     * @param size
     *            The size of this object in bytes.
     *            
     * @see OnestObjectSummary#getSize()           
     */
    public void setSize(long size) {
        this.size = size;
    }

    /**
     * Gets the date when, according to Onest, this object
     * was last modified.
     * 
     * @return The date when, according to Onest, this object
     *         was last modified.
     *         
     * @see OnestObjectSummary#setLastModified(Date)
     */
    public Date getLastModified() {
        return lastModified;
    }

    /**
     * Sets the date, according to Onest, this object
     * was last modified.
     * 
     * @param lastModified
     *            The date when, according to Onest, this object
     *            was last modified.
     *            
     * @see OnestObjectSummary#getLastModified()          
     */
    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }

    /**
     * Gets the owner of this object. Returns <code>null</code> 
     * if the requester doesn't have
     * {@link Permission#ReadAcp} permission for this object or owns the bucket
     * in which it resides.
     * 
     * @return The owner of this object. Returns <code>null</code> 
     *         if the requester doesn't have
     *         permission to see object ownership.
     *         
     * @see OnestObjectSummary#setOwner(Owner)        
     */
    public Owner getOwner() {
        return owner;
    }

    /**
     * Sets the owner of this object.
     * 
     * @param owner
     *            The owner of this object.
     *            
     * @see OnestObjectSummary#getOwner()                   
     */
    public void setOwner(Owner owner) {
        this.owner = owner;
    }

    /**
     * Gets the storage class used by Onest for this object.
     * 
     * @return The storage class used by Onest for this object.
     * 
     * @see OnestObjectSummary#setStorageClass(String)
     */
    public String getStorageClass() {
        return storageClass;
    }

    /**
     * Sets the storage class used by Onest for this object.
     * 
     * @param storageClass
     *            The storage class used by Onest for this object.
     *            
     * @see OnestObjectSummary#getStorageClass()            
     */
    public void setStorageClass(String storageClass) {
        this.storageClass = storageClass;
    }
    
    public void setCtime(String createTime) {
        this.createTime = createTime;
    }
    
    public String getCtime() {
        return createTime;
    }
}
