package com.onest.metainfo;

/**
 * Specifies constants defining a group of Onest users 
 * who can be granted permissions to
 * Onest buckets and objects. This enumeration contains all the valid Onest
 * group grantees.
 */
public enum GroupGrantee implements Grantee {
	   /**
     * Grants anonymous access to any Onest object or bucket. Any user will
     * be able to access the object by omitting the Onest Key ID and Signature
     * from a request.
     * <p>
     * Onest highly recommends that users do not grant the 
     * <code>AllUsers</code> group write
     * access to their buckets. If granted, users will have no control over the objects
     * others can store and their associated charges.
     * </p>
     */
    AllUsers("http://onest.com/groups/global/AllUsers"),

    /**
     * Grants access to buckets or objects to anyone with an Onest account.
     * Although this is inherently insecure as any onest user who is aware of the
     * bucket or object will be able to access it, users may find this authentication
     * method useful.
     */
    AuthenticatedUsers("http://onest.com/groups/global/AuthenticatedUsers"),

    /**
     * Grants access to Onest log delivery so that an Onest bucket can receive
     * server access logs. Turning on server access logging for an Onest
     * bucket requires that the bucket receiving the logs is granted permission
     * for the log delivery group to deliver logs.
     */
    LogDelivery("http://onest.com/groups/LogDelivery");


    private String groupUri;
    
    private GroupGrantee(String groupUri) {
        this.groupUri = groupUri;
    }
    
    /**
     * Gets the group grantee's URI.
     * 
     * @return The group grantee's URI. 
     */
    public String getIdentifier() {
        return groupUri;
    }

    /**
     * For internal use only. Group grantees have preset identifiers that cannot
     * be modified.
     */
    public void setIdentifier(String id) {
        throw new UnsupportedOperationException(
                "Group grantees have preset identifiers that cannot be modified.");
    }
    
    /**
     * @see java.lang.Enum#toString()
     */
    public String toString() {
        return "GroupGrantee [" + groupUri + "]";
    }

    /**
     * Gets the {@link GroupGrantee} enumeration value
     * with the specified Onest group URI (eg.
     * http://onest.com/groups/global/AllUsers).
     * Returns <code>null</code> if an invalid
     * Onest group URI is specified.
     * 
     * @param groupUri
     *            A string representation of an Onest group URI (eg.
     *            http://onest.com/groups/global/AllUsers)
     * 
     * @return The {@link GroupGrantee} object represented by the given Onest group
     *         URI string. Returns <code>null</code>
     *         if the string isn't a valid Onest group
     *         URI.
     */
    public static GroupGrantee parseGroupGrantee(String groupUri) {
        for (GroupGrantee grantee : GroupGrantee.values()) {
            if (grantee.groupUri.equals(groupUri)) {
                return grantee;
            }
        }
     
        return null;
    }
}
