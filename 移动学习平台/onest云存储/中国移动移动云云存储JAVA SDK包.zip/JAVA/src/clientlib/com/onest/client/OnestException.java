package com.onest.client;




public class OnestException extends OnestServiceException {
    private static final long serialVersionUID = 7573680383273658477L;

    /**
     * An Onest specific request ID that provides additional debugging information.
     */
    private String extendedRequestId;


    /**
     * Constructs a new {@link OnestException} with the specified message.
     *
     * @param message
     *            The error message describing why this exception was thrown.
     *
     * @see OnestException#OnestException(String, Exception)
     */
    public OnestException(String message) {
        super(message);
    }

    /**
     * Constructs a new {@link OnestException} with the specified message and root
     * cause.
     *
     * @param message
     *            The error message describing why this exception was thrown.
     * @param cause
     *            The root exception that caused this exception to be thrown.
     *
     * @see OnestException#OnestException(String)
     */
    public OnestException(String message, Exception cause) {
        super(message, cause);
    }

    /**
     * Gets Onest's extended request ID. This ID is required debugging information in the case
     * the user needs to contact Amazon about an issue where Onest is incorrectly
     * handling a request.
     *
     * @return Onest's extended request ID.
     *
     * @see OnestException#setExtendedRequestId(String)
     */
    public String getExtendedRequestId() {
        return extendedRequestId;
    }

    /**
     * Sets Onest's extended request ID.
     *
     * @param extendedRequestId
     *            Onest's extended request ID.
     *
     * @see OnestException#getExtendedRequestId()
     */
    public void setExtendedRequestId(String extendedRequestId) {
        this.extendedRequestId = extendedRequestId;
    }

    /**
     * Extends the implementation from AmazonServiceException to include
     * additional information on Onest's extended request ID.
     */
    @Override
    public String toString() {
        return super.toString() + ", "
            + "Onest Extended Request ID: " + getExtendedRequestId();
    }
}
