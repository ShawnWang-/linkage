package com.onest.metainfo;

public class HealerThreadSummary{

	private String address;
	private String key;
	
	public void setAddress(String address){
		this.address = address;
	}
	
	public String getAddress(){
		return address;
	}
	
	public void setKey(String key){
		this.key = key;
	}
	
	public String getKey(){
		return key;
	}	
	
	public String toString(){
		
		StringBuffer sb = new StringBuffer();
		sb.append("[address=").append(address)
		.append(", key=").append(key).append("]");
		return sb.toString();
	}
}