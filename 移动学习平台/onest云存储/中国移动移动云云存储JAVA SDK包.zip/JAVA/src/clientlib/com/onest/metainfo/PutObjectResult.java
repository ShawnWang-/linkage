package com.onest.metainfo;


/**
 * Contains the data returned by Onest from the <code>putObject</code>
 * operation.
 * Use this request to access information about the new object created from the
 * <code>putObject</code> request, such as its ETag and optional version ID.
 * 
 * @see Onest#putObject(String, String, java.io.File)
 * @see Onest#putObject(String, String, java.io.InputStream, OnestObjectMetadata)
 * @see Onest#putObject(PutObjectRequest)
 */
public class PutObjectResult {
    /**
     * The version ID of the new, uploaded object. This field will only be
     * present if object versioning has been enabled for the bucket to which the
     * object was uploaded.
     */
    private String versionId;

    /** The ETag value of the new object */
    private String eTag;

    /**
     * Gets the optional version ID of the newly uploaded object. This field will 
     * be set only if object versioning is enabled for the bucket the
     * object was uploaded to.
     * 
     * @return The optional version ID of the newly uploaded object.
     * 
     * @see PutObjectResult#setVersionId(String)
     */
    public String getVersionId() {
        return versionId;
    }

    /**
     * Sets the optional version ID of the newly uploaded object.
     * 
     * @param versionId
     *            The optional version ID of the newly uploaded object.
     *            
     * @see PutObjectResult#getVersionId()        
     */
    public void setVersionId(String versionId) {
        this.versionId = versionId;
    }

    /**
     * Gets the ETag value for the newly created object.
     * 
     * @return The ETag value for the new object.
     * 
     * @see PutObjectResult#setETag(String)
     */
    public String getETag() {
        return eTag;
    }

    /**
     * Sets the ETag value for the new object that was created from the
     * associated <code>putObject</code> request.
     * 
     * @param eTag
     *            The ETag value for the new object.
     *            
     * @see PutObjectResult#getETag()           
     */
    public void setETag(String eTag) {
        this.eTag = eTag;
    }
    
}
