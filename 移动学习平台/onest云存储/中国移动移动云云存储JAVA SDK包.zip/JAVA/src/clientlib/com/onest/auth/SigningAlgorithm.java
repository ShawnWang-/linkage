package com.onest.auth;

public enum SigningAlgorithm {
    HmacSHA1,
    HmacSHA256;

}
