package com.onest.auth;

import java.security.SignatureException;

import com.onest.request.Request;



public interface Signer {
    public void sign(Request<?> request, SignatureVersion version, SigningAlgorithm algorithm) throws SignatureException;

}
