package com.onest.metainfo;

import java.util.Date;

import com.onest.request.CopyObjectRequest;

/**
 * <p>
 * Contains the data returned by Onest from the 
 * {@link Onest#copyObject(CopyObjectRequest copyObjectRequest)} call.
 * This result may be ignored if not needed; otherwise, use this result
 * to access information about the new object created from the copyObject call.
 * </p>
 * 
 * @see OnestClient#copyObject(String, String, String, String)
 * @see OnestClient#copyObject(com.onest.request.CopyObjectRequest)
 */
public class CopyObjectResult {
	   /** The ETag value of the new object */
    private String etag;
    
    /** The last modified date for the new object */
    private Date lastModifiedDate;

    /**
     * The version ID of the new, copied object. This field will only be present
     * if object versioning has been enabled for the bucket to which the object
     * was copied.
     */
    private String versionId;

    
    /**
     * Gets the ETag value for the new object that was created in the
     * associated {@link CopyObjectRequest}.
     * 
     * @return The ETag value for the new object.
     * 
     * @see CopyObjectResult#setETag(String)
     */
    public String getETag() {
        return etag;
    }

    /**
     * Sets the ETag value for the new object that was created from the
     * associated copy object request.
     * 
     * @param etag
     *            The ETag value for the new object.
     *            
     * @see CopyObjectResult#getETag()           
     */
    public void setETag(String etag) {
        this.etag = etag;
    }

    /**
     * Gets the date the newly copied object was last modified.
     * 
     * @return The date the newly copied object was last modified.
     * 
     * @see CopyObjectResult#setLastModifiedDate(Date)
     */
    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    /**
     * Sets the date the newly copied object was last modified.
     * 
     * @param lastModifiedDate
     *            The date the new, copied object was last modified.
     *            
     * @see CopyObjectResult#getLastModifiedDate()          
     */
    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    /**
     * Gets the version ID of the newly copied object. This field is only
     * present if object versioning has been enabled for the bucket the
     * object was copied to.
     * 
     * @return The version ID of the newly copied object.
     * 
     * @see CopyObjectResult#setVersionId(String)
     */
    public String getVersionId() {
        return versionId;
    }

    /**
     * Sets the version ID of the newly copied object.
     * 
     * @param versionId
     *            The version ID of the newly copied object.
     *            
     * @see CopyObjectResult#getVersionId()
     */
    public void setVersionId(String versionId) {
        this.versionId = versionId;
    }
}
