package com.onest.metainfo;


/**
 * Specifies constants that define Onest Regions.
 * <p>
 * Onest Regions allow the user to choose the geographical region where Onest
 * will store the buckets the user creates. Choose a Onest Region to optimize
 * latency, minimize costs, or address regulatory requirements.
 * </p>
 * <p>
 * Objects stored in a Onest Region never leave that region unless explicitly
 * transfered to another region.
 * </p>
 */
public enum Region {
    /**
     * The China Standard Region. This region
     * uses Onest servers located in China.
     * <p>
     * This is the default Onest Region. All requests sent to
     * <code>onest.com</code> go
     * to this region unless a location constraint is specified when creating a bucket.
     * </p>
     */
    CN_Standard(null);



    /** The unique ID representing each region. */
    private final String regionId;

    /**
     * Constructs a new region with the specified region ID.
     *
     * @param regionId
     *            The unique ID representing the Onest region.
     */
    private Region(String regionId) {
        this.regionId = regionId;
    }

    /* (non-Javadoc)
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
        return regionId;
    }

    /**
     * Returns the Onest Region enumeration value representing the specified Onest
     * Region ID string. If specified string doesn't map to a known Onest
     * Region, then an <code>IllegalArgumentException</code> is thrown.
     *
     * @param onestRegionString
     *            The Onest region ID string.
     *
     * @return The Onest Region enumeration value representing the specified Onest
     *         Region ID.
     *
     * @throws IllegalArgumentException
     *             If the specified value does not map to one of the known
     *             Onest regions.
     */
    public static Region fromValue(String onestRegionString) throws IllegalArgumentException {
        for (Region region : Region.values()) {
            String regionString = region.toString();
            if (regionString == null && onestRegionString == null) return region;
            if (regionString != null && regionString.equals(onestRegionString)) return region;
        }

        throw new IllegalArgumentException(
                "Cannot create enum from " + onestRegionString + " value!");
    }
}
