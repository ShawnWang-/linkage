package com.onest.handlers;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.onest.client.OnestClientException;

/**
 * Factory for creating request/response handler chains.
 */
public class HandlerChainFactory {
    public List<RequestHandler> newRequestHandlerChain(String resource) {
        List<RequestHandler> handlers = new ArrayList<RequestHandler>();

        try {
            InputStream input = getClass().getResourceAsStream(resource);
            if (input == null) return handlers;
            
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            while (true) {
                String requestHandlerClassName = reader.readLine();
                if (requestHandlerClassName == null) break;
                requestHandlerClassName = requestHandlerClassName.trim();
                if (requestHandlerClassName.equals("")) continue;
                
                Class<?> requestHandlerClass = getClass().getClassLoader().loadClass(requestHandlerClassName);
                Object requestHandlerObject = requestHandlerClass.newInstance();
                if (requestHandlerObject instanceof RequestHandler) {
                    handlers.add((RequestHandler)requestHandlerObject);
                } else {
                    throw new OnestClientException("Unable to instantiate request handler chain for client.  "
                            + "Listed request handler ('" + requestHandlerClassName + "') "
                            + "does not implement the RequestHandler interface.");
                }
            }
        } catch (Exception e) {
            throw new OnestClientException("Unable to instantiate request handler chain for client: " 
                    + e.getMessage(), e);
        }
        
        return handlers;
    }
}
