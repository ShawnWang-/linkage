package com.onest.auth;


/**
 * Provides access to the Onest credentials used for accessing Onest services: Onest
 * access key ID and secret access key. These credentials are used to securely
 * sign requests to Onest services.
 */
public interface OnestCredentials {
    /**
     * Returns the onest access key ID for this credentials object. 
     * 
     * @return The onest access key ID for this credentials object. 
     */
    public String getOnestAccessID();

    /**
     * Returns the onest secret access key for this credentials object.
     * 
     * @return The onest secret access key for this credentials object.
     */
    public String getOnestAccessSecretKey();

}
