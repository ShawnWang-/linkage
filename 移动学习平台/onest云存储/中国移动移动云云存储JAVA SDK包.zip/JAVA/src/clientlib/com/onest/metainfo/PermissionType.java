package com.onest.metainfo;

public class PermissionType {
	public static int READ = 0x01;
	public static int WRITE = 0x01<<1;
	public static int READ_ACP= 0x01<<2;
	public static int WRITE_ACP = 0x01<<3;
	public static int FULL_CONTROL = READ | WRITE | READ_ACP | WRITE_ACP;
	
}
