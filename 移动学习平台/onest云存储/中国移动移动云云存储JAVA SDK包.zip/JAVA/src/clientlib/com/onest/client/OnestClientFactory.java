package com.onest.client;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.onest.auth.OnestCredentials;
import com.onest.metainfo.BucketStat;
import com.onest.metainfo.UserSpaceStat;
import com.onest.request.CreateGetBucketStatRequest;
import com.onest.request.CreateGetUserStatRequest;


public class OnestClientFactory {
	private static Log log = LogFactory.getLog(OnestClientFactory.class);		
	private static OnestClientFactory instance = null;
	private OnestClient onest = null;
	private OnestCredentials onestCredentials = null;
	private String hostName = null;
	private ConcurrentHashMap<String, Onest> interSrvOnestLocationMap = new ConcurrentHashMap<String, Onest>();
	private ConcurrentHashMap<String, Onest> interMgrOnestLocationMap = new ConcurrentHashMap<String, Onest>();
	private ConcurrentHashMap<String, Onest> outerOnestLocationMap = new ConcurrentHashMap<String, Onest>();
	
	public static OnestClientFactory getInstance() {
		if(instance==null){
			instance = new OnestClientFactory();
		}
		return instance;
	}
	
	private OnestClientFactory() {

	}
	
	public void setFactoryInfo(OnestCredentials onestCredentials, String hostName){
		this.onestCredentials = onestCredentials;
		this.hostName = hostName;
		onest = new OnestClient(this.onestCredentials, this.hostName);		
	}
	
	public Onest getBucketLocation(String bucketName){
		return getBucketLocation(false, bucketName);
	}
	
	public Onest getBucketLocation(boolean isReconnect, String bucketName ){
		Onest onestClientOnest = null;
		if(isReconnect){
			removeOnestClient(bucketName, true, true);
		}
		else{
			onestClientOnest = getOnestClient(bucketName, true, true);
			if(onestClientOnest != null)
				return onestClientOnest;			
		}
		
		List<String> locationList = onest.getBucketLocation(bucketName);
		String location = locationList.get(0);
		onestClientOnest = new OnestClient(this.onestCredentials, location);
		putOnestClient(bucketName, onestClientOnest, true, true);
		return onestClientOnest;		
	}
	
	/*	
	 *	@param isOuterLocation - The flag of obtain out address location or intra address location
	 *	@param isIntraSrvLocation �C If isOuterLocation is false, it means obtaining the 
	 *								intra address, the intra address is divided into two class 
	 *								of addresses which are intra business address and intra manager
	 *								address. isIntraSrvLocation is the flag of obtain intra business
	 *								address location or intra manager address location. 
	 *								If isIntraSrvLocation is false it means obtaining the 
	 *								intra manager address, else is intra business address.
	*/	
	public Onest getLocation(boolean isOuterLocation, boolean isIntraSrvLocation)
			throws OnestClientException, OnestServiceException{
		Onest onestClientOnest = null;
		List<String> locationList = onest.getBucketLocation(isOuterLocation,isIntraSrvLocation);
		String location = locationList.get(0);
		onestClientOnest = new OnestClient(this.onestCredentials, location);
		return onestClientOnest;	
	}
	
	public Onest getBucketLocation(String bucketName, boolean isOuterLocation,boolean isIntraSrvLocation)
			throws OnestClientException, OnestServiceException{
		return getBucketLocation(false, bucketName, isOuterLocation, isIntraSrvLocation);
	}
	
	/*	
	 *	@param isReconnect - The flag of wheather reinitialization the OnestClient for 
	 *                       the specific bucket. As OnestClient will be cached when it 
	 *                       has done the operation of getBucketLocation. So if isReconnect
	 *                       is specific as true, it will remove the OnestClient in the 
	 *                       cache, then send the requeset to aaa server to obtain the
	 *                       master az��s lvs address where the bucket is in. if it is 
	 *                       specific as false, it will get first from the cache, if it 
	 *                       is not found ,it will go to the aaa server for address, 
	 *                       then initialization the OnestClient with the obtained address.
	 *	@param bucketName - The bucket name which the invoker want to get location for.
	 *	@param isOuterLocation - The flag of obtain out address location or intra address location
	 *	@param isIntraSrvLocation �C If isOuterLocation is false, it means obtaining the 
	 *								intra address, the intra address is divided into two class 
	 *								of addresses which are intra business address and intra manager
	 *								address. isIntraSrvLocation is the flag of obtain intra business
	 *								address location or intra manager address location. 
	 *								If isIntraSrvLocation is true it means obtaining the 
	 *								intra manager address, else is intra business address.
	*/
	
	public Onest getBucketLocation(boolean isReconnect, String bucketName, 
			boolean isOuterLocation,boolean isIntraSrvLocation)
				throws OnestClientException, OnestServiceException{
		Onest onestClientOnest = null;
		if(isReconnect){
			removeOnestClient(bucketName, isOuterLocation, isIntraSrvLocation);
		}
		else{
			onestClientOnest = getOnestClient(bucketName, isOuterLocation, isIntraSrvLocation);
			if(onestClientOnest != null)
				return onestClientOnest;			
		}		
		
		List<String> locationList = onest.getBucketLocation(bucketName, isOuterLocation, isIntraSrvLocation);
		String location = locationList.get(0);
		onestClientOnest = new OnestClient(this.onestCredentials, location);
		putOnestClient(bucketName, onestClientOnest, isOuterLocation,isIntraSrvLocation);
		return onestClientOnest;		
	}
	
	public Onest getOnestClient(String bucketName, boolean isOuterLocation, boolean isIntraSrvLocation){
		if(isOuterLocation)
			return outerOnestLocationMap.get(bucketName);
		else if(isIntraSrvLocation)
			return interSrvOnestLocationMap.get(bucketName);
		else
			return interMgrOnestLocationMap.get(bucketName);
	}
	
	public void putOnestClient(String bucketName, Onest onestClient, boolean isOuterLocation, boolean isIntraSrvLocation){
		if(isOuterLocation)
			outerOnestLocationMap.put(bucketName, onestClient);
		else if(isIntraSrvLocation)
			interSrvOnestLocationMap.put(bucketName, onestClient);
		else
			interMgrOnestLocationMap.put(bucketName, onestClient);
	}
	
	public void removeOnestClient(String bucketName, boolean isOuterLocation, boolean isIntraSrvLocation){
		if(isOuterLocation)
			outerOnestLocationMap.remove(bucketName);
		else if(isIntraSrvLocation)
			interSrvOnestLocationMap.remove(bucketName);
		else
			interMgrOnestLocationMap.remove(bucketName);
	}
	
	public UserSpaceStat getUserStat(String userName )
			throws OnestClientException, OnestServiceException{
		return onest.getUserStat(userName);
	}
	
	public BucketStat getBucketStat(String bucketName )
			throws OnestClientException, OnestServiceException{
		return onest.getBucketStat(bucketName);
	}
	
	public UserSpaceStat getUserStat(CreateGetUserStatRequest createGetUserStatRequest)
			throws OnestClientException, OnestServiceException{
		return onest.getUserStat(createGetUserStatRequest);
	}
	
	public BucketStat getBucketStat(CreateGetBucketStatRequest createGetBucketStatRequest)
			throws OnestClientException, OnestServiceException{
		return onest.getBucketStat(createGetBucketStatRequest);
	}
}
