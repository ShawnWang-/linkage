
package com.onest.metainfo;

import java.util.List;
import java.util.ArrayList;

public class HealerSummary{

	private List<HealerThreadSummary> objectScanList;
	private List<HealerThreadSummary> blockScanList;
	private List<HealerThreadSummary> interAzList;
	private List<HealerThreadSummary> intraAzList;
	
	public List<HealerThreadSummary> getObjectScanList(){
		if(null == objectScanList)
			objectScanList = new ArrayList<HealerThreadSummary>();
		return objectScanList;
	}
	
	public List<HealerThreadSummary> getBlockScanList(){
		if(null == blockScanList)
			blockScanList = new ArrayList<HealerThreadSummary>();
		return blockScanList;		
	}

	public List<HealerThreadSummary> getInterAzList(){
		if(null == interAzList)
			interAzList = new ArrayList<HealerThreadSummary>();
		return interAzList;		
	}
	
	public List<HealerThreadSummary> getIntraAzList(){
		if(null == intraAzList)
			intraAzList = new ArrayList<HealerThreadSummary>();
		return intraAzList;		
	}
	
	public String toString(){
		
		StringBuffer sb = new StringBuffer();
		sb.append("objectScanList:");
		if(null != objectScanList){
			for(HealerThreadSummary os: objectScanList){
				sb.append(os);
			}
		}	
		sb.append(";");
		
		sb.append("blockScanList:");
		if(null != blockScanList){
			for(HealerThreadSummary bs: blockScanList){
				sb.append(bs);
			}
		}
		sb.append(";");
		
		sb.append("interAzList:");
		if(null != interAzList){
			for(HealerThreadSummary ia: interAzList){
				sb.append(ia);
			}
		}
		sb.append(";");
		
		sb.append("intraAzList:");
		if(null != intraAzList){
			for(HealerThreadSummary ira: intraAzList){
				sb.append(ira);
			}	
		}
		sb.append(";");
		return sb.toString();
	}
}