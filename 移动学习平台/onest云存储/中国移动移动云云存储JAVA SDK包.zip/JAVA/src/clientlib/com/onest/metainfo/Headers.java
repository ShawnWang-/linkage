package com.onest.metainfo;

/**
 * Common Onest HTTP header values used throughout the Onest Java client.
 */
public interface Headers {
    /*
     * Standard HTTP Headers
     */

    public static final String CACHE_CONTROL = "Cache-Control";
    public static final String CONTENT_DISPOSITION = "Content-Disposition";
    public static final String CONTENT_ENCODING = "Content-Encoding";
    public static final String CONTENT_LENGTH = "Content-Length";
    public static final String CONTENT_OFFSET  = "Content-Offset";    
    public static final String CONTENT_MD5 = "Content-MD5";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String DATE = "Date";
    public static final String ETAG = "ETag";
    public static final String LAST_MODIFIED = "Last-Modified";
    public static final String SERVER = "Server";
    public static final String HOST = "Host";
    public static final String COPYPOLICY = "copypolicy";
    /*
     * Onest HTTP Headers
     */

    /** Prefix for general Onest headers: x-cmcc- */
    public static final String ONEST_PREFIX = "x-cmcc-";

    /** Onest's canned ACL header: x-cmcc-acl */
    public static final String ONEST_CANNED_ACL = "x-cmcc-acl";

    /** Onest's alternative date header: x-cmcc-date */
    public static final String ONEST_ALTERNATE_DATE = "x-cmcc-date";

    /** Prefix for Onest user metadata: x-cmcc-usermeta- */
    public static final String ONEST_USER_METADATA_PREFIX = "x-cmcc-usermeta-";

    /** Onest's version ID header */
    public static final String ONEST_VERSION_ID = "x-cmcc-version-id";

    /** Onest's Multi-Factor Authentication header */
    public static final String ONEST_MFA = "x-cmcc-mfa";

    /** Onest response header for a request's onest request ID */
    public static final String REQUEST_ID = "x-cmcc-request-id";

    /** Onest response header for a request's extended debugging ID */
    public static final String EXTENDED_REQUEST_ID = "x-cmcc-id-2";

    /** Onest request header indicating how to handle metadata when copying an object */
    public static final String METADATA_DIRECTIVE = "x-cmcc-metadata-directive";

    /** DevPay token header */
    public static final String SECURITY_TOKEN = "x-cmcc-security-token";

    /** Header describing what class of storage a user wants */
    public static final String STORAGE_CLASS = "x-cmcc-storage-class";

    /** ETag matching constraint header for the copy object request */
    public static final String COPY_SOURCE_IF_MATCH = "x-cmcc-copy-source-if-match";

    /** ETag non-matching constraint header for the copy object request */
    public static final String COPY_SOURCE_IF_NO_MATCH = "x-cmcc-copy-source-if-none-match";

    /** Unmodified since constraint header for the copy object request */
    public static final String COPY_SOURCE_IF_UNMODIFIED_SINCE = "x-cmcc-copy-source-if-unmodified-since";

    /** Modified since constraint header for the copy object request */
    public static final String COPY_SOURCE_IF_MODIFIED_SINCE = "x-cmcc-copy-source-if-modified-since";

    /** Range header for the get object request */
    public static final String RANGE = "Range";

    /** Modified since constraint header for the get object request */
    public static final String GET_OBJECT_IF_MODIFIED_SINCE = "If-Modified-Since";

    /** Unmodified since constraint header for the get object request */
    public static final String GET_OBJECT_IF_UNMODIFIED_SINCE = "If-Unmodified-Since";

    /** ETag matching constraint header for the get object request */
    public static final String GET_OBJECT_IF_MATCH = "If-Match";

    /** ETag non-matching constraint header for the get object request */
    public static final String GET_OBJECT_IF_NONE_MATCH = "If-None-Match";

    /** Encrypted symmetric key header that is used in the envelope encryption mechanism */
    public static final String CRYPTO_KEY = "x-cmcc-key";
    
    /** Initialization vector (IV) header that is used in the symmetric and envelope encryption mechanisms */
    public static final String CRYPTO_IV = "x-cmcc-iv";

    /** JSON-encoded description of encryption materials used during encryption */ 
    public static final String MATERIALS_DESCRIPTION = "x-cmcc-matdesc";
    
    /** Instruction file header to be placed in the metadata of instruction files */
    public static final String CRYPTO_INSTRUCTION_FILE = "x-cmcc-crypto-instr-file";
}
