package com.onest.handlers;

import com.onest.http.HttpResponse;
import com.onest.metainfo.ObjectMetadata;

/**
 * Onest response handler that knows how to pull Onest object metadata out of a
 * response and unmarshall it into an OnestObjectMetadata object.
 */
public class OnestMetadataResponseHandler extends
		AbstractOnestResponseHandler<ObjectMetadata> {
    /**
     * @see com.onest.handlers.HttpResponseHandler#handle(com.onest.http.HttpResponse)
     */
    public OnestWebServiceResponse<ObjectMetadata> handle(HttpResponse response) throws Exception {
        ObjectMetadata metadata = new ObjectMetadata();
        populateObjectMetadata(response, metadata);

        OnestWebServiceResponse<ObjectMetadata> onestResponse = parseResponseMetadata(response);
        onestResponse.setResult(metadata);
        return onestResponse;
    }
}
