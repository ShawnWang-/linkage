package com.onest.client;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

import com.onest.metainfo.Constants;
import com.onest.metainfo.ProgressEvent;

/**
 * Simple InputStream wrapper that occasionally notifies a progress listener
 * about the number of bytes transfered.
 */
public class ProgressReportingInputStream extends FilterInputStream {
    /** The threshold of bytes between notifications. */
    private static final int NOTIFICATION_THRESHOLD = 8 * Constants.KB;

    /** The listener to notify. */
    private final ProgressListener listener;
    
    /** The number of bytes read that the listener hasn't been notified about yet. */
    private int unnotifiedByteCount;

    /**
     * Creates a new progress reporting input stream that simply wraps the
     * specified input stream and notifies the specified listener occasionally
     * about the number of bytes transfered.
     * 
     * @param in
     *            The input stream to wrap.
     * @param listener
     *            The listener to notify about progress.
     */
    public ProgressReportingInputStream(final InputStream in, final ProgressListener listener) {
        super(in);
        this.listener = listener;
    }

    @Override
    public int read() throws IOException {
        int data = super.read();
        if (data != -1) notify(1);
        return data;
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        int bytesRead = super.read(b, off, len);
        if (bytesRead != -1) notify(bytesRead);
        return bytesRead;
    }

    @Override
    public void close() throws IOException {
        if (unnotifiedByteCount > 0) {
            listener.progressChanged(new ProgressEvent(unnotifiedByteCount));
            unnotifiedByteCount = 0;
        }
        super.close();
    }
    
    private void notify(int bytesRead) {
        unnotifiedByteCount += bytesRead;
        if (unnotifiedByteCount >= NOTIFICATION_THRESHOLD) {
            listener.progressChanged(new ProgressEvent(unnotifiedByteCount));
            unnotifiedByteCount = 0;
        }
    }
}
