package com.onest.auth;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Simple implementation OnestCredentials that reads in Onest access keys from a
 * properties file. The Onest access key is expected to be in the "AccessID"
 * property and the Onest secret key id is expected to be in the "AccessSecretKey"
 * property.
 */
public class PropertiesCredentials implements OnestCredentials {

    private final String accessID;
    private final String accessSecretKey;
    private final String bucketName;
    private final String objectKey;
    private final String hostAddr;
    private final String isIntraAddr;
    private final String isIntraSvrAddr;    
    private final String userName;
    private final String bucketAclUser1;
    private final String bucketAclUser2;
    /**
     * Reads the specified file as a Java properties file and extracts the
     * Onest access key from the "AccessID" property and Onest secret access
     * key from the "AccessSecretKey" property. If the specified file doesn't
     * contain the Onest access keys an IOException will be thrown.
     *
     * @param file
     *            The file from which to read the Onest credentials
     *            properties.
     *
     * @throws FileNotFoundException
     *             If the specified file isn't found.
     * @throws IOException
     *             If any problems are encountered reading the Onest access
     *             keys from the specified file.
     * @throws IllegalArgumentException
     *             If the specified properties file does not contain the
     *             required keys.
     */
    public PropertiesCredentials(File file) throws FileNotFoundException, IOException, IllegalArgumentException {
        if (!file.exists()) {
            throw new FileNotFoundException("File doesn't exist:  " + file.getAbsolutePath());
        }

        Properties accountProperties = new Properties();
        accountProperties.load(new FileInputStream(file));

        if (accountProperties.getProperty("AccessID") == null ||
            accountProperties.getProperty("AccessSecretKey") == null) {
            throw new IllegalArgumentException("The specified file (" + file.getAbsolutePath() + ") " +
                    "doesn't contain the expected properties 'AccessID' and 'AccessSecretKey'.");
        }

        accessID = accountProperties.getProperty("AccessID");
        accessSecretKey = accountProperties.getProperty("AccessSecretKey");
        bucketName = accountProperties.getProperty("bucketName");
        objectKey = accountProperties.getProperty("objectKey");
        hostAddr = accountProperties.getProperty("hostAddr");
        userName = accountProperties.getProperty("userName");
        bucketAclUser1 = accountProperties.getProperty("bucketAclUser1");
        bucketAclUser2 = accountProperties.getProperty("bucketAclUser2");
        isIntraAddr = accountProperties.getProperty("isIntraAddr");
        isIntraSvrAddr = accountProperties.getProperty("isIntraSvrAddr");
        
    }

    /**
     * Reads the specified input stream as a stream of Java properties file
     * content and extracts the Onest access key ID and secret access key from the
     * properties.
     *
     * @param inputStream
     *            The input stream containing the Onest credential properties.
     *
     * @throws IOException
     *             If any problems occur while reading from the input stream.
     */
    public PropertiesCredentials(InputStream inputStream) throws IOException {
        Properties accountProperties = new Properties();
        try {
            accountProperties.load(inputStream);
        } finally {
            try {inputStream.close();} catch (Exception e) {}
        }

        if (accountProperties.getProperty("AccessID") == null ||
            accountProperties.getProperty("AccessSecretKey") == null) {
            throw new IllegalArgumentException("The specified properties data " +
                    "doesn't contain the expected properties 'AccessID' and 'AccessSecretKey'.");
        }

        accessID = accountProperties.getProperty("AccessID");
        accessSecretKey = accountProperties.getProperty("AccessSecretKey");
        bucketName = accountProperties.getProperty("bucketName");
        objectKey = accountProperties.getProperty("objectKey");
        hostAddr = accountProperties.getProperty("hostAddr");
        userName = accountProperties.getProperty("userName");
        bucketAclUser1 = accountProperties.getProperty("bucketAclUser1");
        bucketAclUser2 = accountProperties.getProperty("bucketAclUser2");       
        isIntraAddr = accountProperties.getProperty("isIntraAddr");   
        isIntraSvrAddr = accountProperties.getProperty("isIntraSvrAddr");
    }

    /* (non-Javadoc)
     * @see com.onest.auth.OnestCredentials#getOnestAccessID()
     */
    public String getOnestAccessID() {
        return accessID;
    }

    /* (non-Javadoc)
     * @see com.onest.auth.OnestCredentials#getOnestAccessSecretKey()
     */
    public String getOnestAccessSecretKey() {
        return accessSecretKey;
    }


    public String getOnestBucketName() {
        return bucketName;
    }

    public String getOnestObjectKey() {
        return objectKey;
    }

    public String getOnestHostAddr() {
        return hostAddr;
    }

    public String getUserName() {
        return userName;
    }

    public String getOnestBucketAclUser1() {
        return bucketAclUser1;
    }

    public String getOnestBucketAclUser2() {
        return bucketAclUser2;
    }

    public String getIsIntraAddr() {
        return isIntraAddr;
    }
    
    public String getIsIntraSvrAddr() {
        return isIntraSvrAddr;
    }
}
