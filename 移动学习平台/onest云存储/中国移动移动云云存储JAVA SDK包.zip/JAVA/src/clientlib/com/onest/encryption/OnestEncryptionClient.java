package com.onest.encryption;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.onest.auth.OnestCredentials;
import com.onest.client.OnestClient;
import com.onest.client.OnestClientException;
import com.onest.client.OnestServiceException;
import com.onest.metainfo.ObjectMetadata;
import com.onest.metainfo.OnestObject;
import com.onest.metainfo.PutObjectResult;
import com.onest.metainfo.UploadPartResult;
import com.onest.request.DeleteObjectRequest;
import com.onest.request.GetObjectRequest;
import com.onest.request.PutObjectRequest;
import com.onest.request.UploadPartRequest;
import com.onest.util.ClientConfiguration;

/**
 * The OnestEncryption class extends the Onest Client, allowing you to store data securely in Onest.
 * <p>
 * The encryption materials specified in the constructor will be used to encrypt and decrypt data.
 */
public class OnestEncryptionClient extends OnestClient {
    private EncryptionMaterials encryptionMaterials;
    private CryptoConfiguration cryptoConfig;

    /** Shared logger for encryption client events */
    private static Log log = LogFactory.getLog(OnestEncryptionClient.class);

    /**
     * <p>
     * Constructs a new Onest Encryption client that will make <b>anonymous</b>
     * requests to Onest.  If {@link #getObject(String, String)} is called,
     * the object contents will be decrypted with the encryption materials provided.
     * </p>
     * <p>
     * Only a subset of the Onest API will work with anonymous
     * <i>(i.e. unsigned)</i> requests, but this can prove useful in some situations.
     * For example:
     * <ul>
     *  <li>If an Onest bucket has {@link Permission#Read} permission for the
     *  {@link GroupGrantee#AllUsers} group, anonymous clients can call
     *  {@link #listObjects(String)} to see what objects are stored in a bucket.</li>
     *  <li>If an object has {@link Permission#Read} permission for the
     *  {@link GroupGrantee#AllUsers} group, anonymous clients can call
     *  {@link #getObject(String, String)} and
     *  {@link #getObjectMetadata(String, String)} to pull object content and
     *  metadata.</li>
     *  <li>If a bucket has {@link Permission#Write} permission for the
     *  {@link GroupGrantee#AllUsers} group, anonymous clients can upload objects
     *  to the bucket.</li>
     * </ul>
     * </p>
     *
     * @param encryptionMaterials
     *      The encryption materials to be used to encrypt and decrypt data.
     */
    public OnestEncryptionClient(EncryptionMaterials encryptionMaterials) {
        this(null, encryptionMaterials, new ClientConfiguration(), new CryptoConfiguration());
    }

    /**
     * <p>
     * Constructs a new Onest Encryption client that will make <b>anonymous</b>
     * requests to Onest.  If {@link #getObject(String, String)} is called,
     * the object contents will be decrypted with the encryption materials provided.
     * The encryption implementation of the provided crypto provider will be
     * used to encrypt and decrypt data.
     * </p>
     * <p>
     * Only a subset of the Onest API will work with anonymous
     * <i>(i.e. unsigned)</i> requests, but this can prove useful in some situations.
     * For example:
     * <ul>
     *  <li>If an Onest bucket has {@link Permission#Read} permission for the
     *  {@link GroupGrantee#AllUsers} group, anonymous clients can call
     *  {@link #listObjects(String)} to see what objects are stored in a bucket.</li>
     *  <li>If an object has {@link Permission#Read} permission for the
     *  {@link GroupGrantee#AllUsers} group, anonymous clients can call
     *  {@link #getObject(String, String)} and
     *  {@link #getObjectMetadata(String, String)} to pull object content and
     *  metadata.</li>
     *  <li>If a bucket has {@link Permission#Write} permission for the
     *  {@link GroupGrantee#AllUsers} group, anonymous clients can upload objects
     *  to the bucket.</li>
     * </ul>
     * </p>
     *
     * @param encryptionMaterials
     *      	  The encryption materials to be used to encrypt and decrypt data.
     * @param cryptoConfig
     * 			  The crypto configuration whose parameters will be used to encrypt and decrypt data.
     */
    public OnestEncryptionClient(EncryptionMaterials encryptionMaterials, CryptoConfiguration cryptoConfig) {
        this(null, encryptionMaterials, new ClientConfiguration(), cryptoConfig);
    }

    /**
     * <p>
     * Constructs a new Onest Encryption client using the specified Onest credentials to
     * access Onest.  Object contents will be encrypted and decrypted with the encryption
     * materials provided.
     * </p>
     *
     * @param credentials
     *            The Onest credentials to use when making requests to Onest
     *            with this client.
     * @param encryptionMaterials
     *            The encryption materials to be used to encrypt and decrypt data.
     */
    public OnestEncryptionClient(OnestCredentials credentials, EncryptionMaterials encryptionMaterials) {
        this(credentials, encryptionMaterials, new ClientConfiguration(), new CryptoConfiguration());
    }

    /**
     * <p>
     * Constructs a new Onest Encryption client using the specified Onest credentials to
     * access Onest.  Object contents will be encrypted and decrypted with the encryption
     * materials provided.  The encryption implementation of the provided crypto provider will
     * be used to encrypt and decrypt data.
     * </p>
     *
     * @param credentials
     *            The Onest credentials to use when making requests to Onest
     *            with this client.
     * @param encryptionMaterials
     *            The encryption materials to be used to encrypt and decrypt data.
     * @param cryptoConfig
     *            The crypto configuration whose parameters will be used to encrypt and decrypt data.
     */
    public OnestEncryptionClient(OnestCredentials credentials, EncryptionMaterials encryptionMaterials, CryptoConfiguration cryptoConfig) {
        this(credentials, encryptionMaterials, new ClientConfiguration(), cryptoConfig);
    }

    /**
     * <p>
     * Constructs a new Onest Encryption client using the specified Onest credentials and
     * client configuration to access Onest.  Object contents will be encrypted and decrypted
     * with the encryption materials provided. The crypto provider and storage mode denoted in
     * the specified crypto configuration will be used to encrypt and decrypt data.
     * </p>
     *
     * @param credentials
     *            The Onest credentials to use when making requests to Onest
     *            with this client.
     * @param encryptionMaterials
     *            The encryption materials to be used to encrypt and decrypt data.
     * @param clientConfiguration
     *            The client configuration options controlling how this client
     *            connects to Onest (ex: proxy settings, retry counts, etc).
     * @param cryptoConfig
     *            The crypto configuration whose parameters will be used to encrypt and decrypt data.
     * @throws IllegalArgumentException
     *            If either of the encryption materials or crypto configuration parameters are null.
     */
    public OnestEncryptionClient(OnestCredentials credentials, EncryptionMaterials encryptionMaterials,
            ClientConfiguration clientConfig, CryptoConfiguration cryptoConfig) {
        super(credentials, clientConfig);
        assertParameterNotNull(encryptionMaterials, "EncryptionMaterials parameter must not be null.");
        assertParameterNotNull(cryptoConfig, "CryptoConfiguration parameter must not be null.");
        this.encryptionMaterials = encryptionMaterials;
        this.cryptoConfig = cryptoConfig;
    }

    /* (non-Javadoc)
     * @see com.client.onest#putObject(com.request.PutObjectRequest)
     */
    @Override
    public PutObjectResult putObject(PutObjectRequest putObjectRequest)
    throws OnestClientException, OnestServiceException {
        if(this.cryptoConfig.getStorageMode() == CryptoStorageMode.InstructionFile) {
            return putObjectUsingInstructionFile(putObjectRequest);
        } else {
            return putObjectUsingMetadata(putObjectRequest);
        }
    }

    /* (non-Javadoc)
     * @see com.client.onest#getObject(ccom.request.GetObjectRequest)
     */ 
    @Override
    public OnestObject getObject(GetObjectRequest getObjectRequest)
    throws OnestClientException, OnestServiceException {
        // Adjust the crypto range to retrieve all of the cipher blocks needed to contain the user's desired
        // range of bytes.
        long[] desiredRange = getObjectRequest.getRange();
        long[] adjustedCryptoRange = EncryptionUtils.getAdjustedCryptoRange(desiredRange);
        if(adjustedCryptoRange != null) {
            getObjectRequest.setRange(adjustedCryptoRange[0], adjustedCryptoRange[1]);
        }

        // Get the object from Onest
        OnestObject retrievedObject = super.getObject(getObjectRequest);

        OnestObject objectToBeReturned;
        // Check if encryption info is in object metadata
        if(EncryptionUtils.isEncryptionInfoInMetadata(retrievedObject)) {
            objectToBeReturned = decryptObjectUsingMetadata(retrievedObject);
        } else {
            // Check if encrypted info is in an instruction file
            OnestObject instructionFile = getInstructionFile(getObjectRequest);
            if(EncryptionUtils.isEncryptionInfoInInstructionFile(instructionFile)) {
                objectToBeReturned = decryptObjectUsingInstructionFile(retrievedObject, instructionFile);
            } else {
                // The object was not encrypted to begin with.  Return the object without decrypting it.
                log.warn(String.format("Unable to detect encryption information for object '%s' in bucket '%s'. " +
                        "Returning object without decryption.",
                        retrievedObject.getKey(), retrievedObject.getBucketName()));
                objectToBeReturned = retrievedObject;
            }
        }

        // Adjust the output to the desired range of bytes.
        return EncryptionUtils.adjustOutputToDesiredRange(objectToBeReturned, desiredRange);
    }

    /* (non-Javadoc)
     * @see com.client.onest#getObject(com.request.GetObjectRequest, java.io.File)
     */
    @Override
    public ObjectMetadata getObject(GetObjectRequest getObjectRequest, File destinationFile)
    throws OnestClientException, OnestServiceException {
        assertParameterNotNull(destinationFile,
        "The destination file parameter must be specified when downloading an object directly to a file");

        OnestObject OnestObject = getObject(getObjectRequest);
        // getObject can return null if constraints were specified but not met
        if (OnestObject == null) return null;

        OutputStream outputStream = null;
        try {
            outputStream = new BufferedOutputStream(new FileOutputStream(destinationFile));
            byte[] buffer = new byte[1024*10];
            int bytesRead;
            while ((bytesRead = OnestObject.getObjectContent().read(buffer)) > -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            throw new OnestClientException(
                    "Unable to store object contents to disk: " + e.getMessage(), e);
        } finally {
            try {outputStream.close();} catch (Exception e) {}
            try {OnestObject.getObjectContent().close();} catch (Exception e) {}
        }

        /*
         * Unlike the standard Onest Client, the Onest Encryption Client does not do an MD5 check
         * here because the contents stored in Onest and the contents we just retrieved are different.  In
         * Onest, the stored contents are encrypted, and locally, the retrieved contents are decrypted.
         */

        return OnestObject.getObjectMetadata();
    }

    /* (non-Javadoc)
     * @see com.client.onest#deleteObject(com.request.DeleteObjectRequest)
     */
    @Override
    public void deleteObject(DeleteObjectRequest deleteObjectRequest) {
        // Delete the object
        super.deleteObject(deleteObjectRequest);
        // If it exists, delete the instruction file.
        DeleteObjectRequest instructionDeleteRequest = EncryptionUtils.createInstructionDeleteObjectRequest(deleteObjectRequest);
        super.deleteObject(instructionDeleteRequest);
    }

    /**
     * Not implemented - OnestEncryptionClient does not yet support
     * encrypting multipart uploads.
     */
    @Override
    public UploadPartResult uploadPart(UploadPartRequest uploadPartRequest)
        throws OnestClientException, OnestServiceException {
        throw new UnsupportedOperationException(
                "OnestEncryptionClient doesn't support encrypting parts yet.");
    }


    /*
     * Private helper methods
     */

    /**
     * Puts an encrypted object into Onest and stores encryption info in the object metadata.
     *
     * @param putObjectRequest
     *      The request object containing all the parameters to upload a
     *      new object to Onest.
     * @return
     *      A {@link PutObjectResult} object containing the information
     *      returned by Onest for the new, created object.
     * @throws OnestClientException
     *      If any errors are encountered on the client while making the
     *      request or handling the response.
     * @throws OnestServiceException
     *      If any errors occurred in Onest while processing the
     *      request.
     */
    private PutObjectResult putObjectUsingMetadata(PutObjectRequest putObjectRequest)
    throws OnestClientException, OnestServiceException {
        putObjectRequest = EncryptionUtils.encryptRequestUsingMetadata(putObjectRequest, this.encryptionMaterials, this.cryptoConfig.getCryptoProvider());
        return super.putObject(putObjectRequest);
    }

    /**
     * Puts an encrypted object into Onest, and puts an instruction file into Onest. Encryption info is stored in the instruction file.
     *
     * @param putObjectRequest
     *      The request object containing all the parameters to upload a
     *      new object to Onest.
     * @return
     *      A {@link PutObjectResult} object containing the information
     *      returned by Onest for the new, created object.
     * @throws OnestClientException
     *      If any errors are encountered on the client while making the
     *      request or handling the response.
     * @throws OnestServiceException
     *      If any errors occurred in Onest while processing the
     *      request.
     */
    private PutObjectResult putObjectUsingInstructionFile(PutObjectRequest putObjectRequest)
    throws OnestClientException, OnestServiceException {
        // Create instruction
        EncryptionInstruction instruction = EncryptionUtils.generateInstruction(putObjectRequest, this.encryptionMaterials, this.cryptoConfig.getCryptoProvider());

        // Encrypt the object data with the instruction
        PutObjectRequest encryptedObjectRequest = EncryptionUtils.encryptRequestUsingInstruction(putObjectRequest, instruction);

        // Put the encrypted object into Onest
        PutObjectResult encryptedObjectResult = super.putObject(encryptedObjectRequest);

        // Put the instruction file into Onest
        PutObjectRequest instructionRequest = EncryptionUtils.createInstructionPutRequest(putObjectRequest, instruction);
        super.putObject(instructionRequest);

        // Return the result of the encrypted object PUT.
        return encryptedObjectResult;
    }

    /**
     * Decrypts an object using information retrieved from metadata.  If decryption is not possible, returns null.
     *
     * @param object
     *      The OnestObject to be decrypted.
     * @return
     *      An OnestObject with decrypted object contents.  If decryption is not possible, returns null.
     */
    private OnestObject decryptObjectUsingMetadata(OnestObject object) {
        return EncryptionUtils.decryptObjectUsingMetadata(object, this.encryptionMaterials, this.cryptoConfig.getCryptoProvider());
    }

    /**
     * Decrypts an object using information retrieved from an instruction file.
     *
     * @param object
     *      The OnestObject to be decrypted.
     * @param instructionFile
     *      The OnestObject instruction file to be used to decrypt the object.
     * @return
     *      An OnestObject with decrypted object contents.
     */
    private OnestObject decryptObjectUsingInstructionFile(OnestObject object, OnestObject instructionFile) {
        // Create an instruction object from the retrieved instruction file
        EncryptionInstruction instruction = EncryptionUtils.buildInstructionFromInstructionFile(instructionFile, this.encryptionMaterials, this.cryptoConfig.getCryptoProvider());

        // Decrypt the object file with the instruction
        return EncryptionUtils.decryptObjectUsingInstruction(object, instruction);
    }

    /**
     * Retrieves an instruction file from Onest.  If no instruction file is found, returns null.
     *
     * @param getObjectRequest
     *      A GET request for an object in Onest.  The parameters from this request will be used
     *      to retrieve the corresponding instruction file.
     * @return
     *      An instruction file, or null if no instruction file was found.
     */
    private OnestObject getInstructionFile(GetObjectRequest getObjectRequest) {
        try {
            GetObjectRequest instructionFileRequest = EncryptionUtils.createInstructionGetRequest(getObjectRequest);
            return super.getObject(instructionFileRequest);
        } catch (OnestServiceException e) {
            // If no instruction file is found, log a debug message, and return null.
            log.debug("Unable to retrieve instruction file : " + e.getMessage());
            return null;
        }
    }

    /**
     * Asserts that the specified parameter value is not null and if it is,
     * throws an IllegalArgumentException with the specified error message.
     *
     * @param parameterValue
     *            The parameter value being checked.
     * @param errorMessage
     *            The error message to include in the IllegalArgumentException
     *            if the specified parameter is null.
     */
    private void assertParameterNotNull(Object parameterValue, String errorMessage) {
        if (parameterValue == null) throw new IllegalArgumentException(errorMessage);
    }

}
