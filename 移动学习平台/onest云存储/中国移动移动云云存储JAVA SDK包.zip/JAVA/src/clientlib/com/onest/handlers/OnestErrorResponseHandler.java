package com.onest.handlers;

import org.w3c.dom.Document;

import com.onest.client.OnestException;
import com.onest.client.OnestServiceException;
import com.onest.client.OnestServiceException.ErrorType;
import com.onest.http.HttpMethodName;
import com.onest.http.HttpResponse;
import com.onest.metainfo.Headers;
import com.onest.util.XpathUtils;

/**
 * Response handler for Onest error responses. Onest error responses are different
 * from other Onest error responses in a few ways. Most error responses will
 * contain an XML body, but not all (ex: error responses to HEAD requests will
 * not), so this error handler has to account for that. 
 */
public class OnestErrorResponseHandler implements
		HttpResponseHandler<OnestServiceException> {
    /**
     * @see com.onest.handlers.HttpResponseHandler#handle(com.onest.http.HttpResponse)
     */
    public OnestServiceException handle(HttpResponse errorResponse)
            throws Exception {
        /*
         * We don't always get an error response body back from Onest. When we send
         * a HEAD request, we don't receive a body, so we'll have to just return
         * what we can.
         */
        if (errorResponse.getContent() == null 
                || errorResponse.getRequest().getMethodName() == HttpMethodName.HEAD) {
            String requestId = errorResponse.getHeaders().get(Headers.REQUEST_ID);
            String extendedRequestId = errorResponse.getHeaders().get(Headers.EXTENDED_REQUEST_ID);
            OnestException ase = new OnestException(errorResponse.getStatusText());
            ase.setStatusCode(errorResponse.getStatusCode());
            ase.setRequestId(requestId);
            ase.setExtendedRequestId(extendedRequestId);
            fillInErrorType(ase, errorResponse);
            return ase;
        }

        Document document = XpathUtils.documentFrom(errorResponse.getContent());
        String message = XpathUtils.asString("Error/Message", document);
        String errorCode = XpathUtils.asString("Error/Code", document);
        String requestId = XpathUtils.asString("Error/RequestId", document);
        String extendedRequestId = XpathUtils.asString("Error/HostId", document);

        OnestException ase = new OnestException(message);
        ase.setStatusCode(errorResponse.getStatusCode());
        ase.setErrorCode(errorCode);
        ase.setRequestId(requestId);
        ase.setExtendedRequestId(extendedRequestId);
        fillInErrorType(ase, errorResponse);

        return ase;
    }

    /**
     * Fills in the Onest error type information in the specified
     * OnestServiceException by looking at the HTTP status code in the error
     * response. Onest error responses don't explicitly declare a sender or client
     * fault like other Onest services, so we have to use the HTTP status code to
     * infer this information.
     * 
     * @param ase
     *            The OnestServiceException to populate with error type
     *            information.
     * @param errorResponse
     *            The HTTP error response to use to determine the right error
     *            type to set.
     */
    private void fillInErrorType(OnestException ase, HttpResponse errorResponse) {
        if (errorResponse.getStatusCode() >= 500) {
            ase.setErrorType(ErrorType.Service);
        } else {
            ase.setErrorType(ErrorType.Client);
        }
    }

    /**
     * Since this response handler completely consumes all the data from the
     * underlying HTTP connection during the handle method, we don't need to
     * keep the HTTP connection open.
     *
     * @see com.onest.handlers.HttpResponseHandler#needsConnectionLeftOpen()
     */
    public boolean needsConnectionLeftOpen() {
        return false;
    }

}
