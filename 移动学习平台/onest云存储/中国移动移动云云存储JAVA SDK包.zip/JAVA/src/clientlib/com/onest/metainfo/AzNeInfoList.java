package com.onest.metainfo;

import java.util.ArrayList;
import java.util.List;

/**
 * The AZ Net Element list info 
 */
public class AzNeInfoList{
	
	private List<DataStorageSummary> dataStorageList;
	private List<StorageSummary> storageList;
	private List<OasSummary> oasList;
	private HealerSummary healer;
	
	public List<DataStorageSummary> getDataStorageList(){
		if(null == dataStorageList){
			dataStorageList = new ArrayList<DataStorageSummary>();
		}
		return dataStorageList;
	}
	
	public List<StorageSummary> getStorageList(){
		if(null == storageList){
			storageList = new ArrayList<StorageSummary>();
		}
		return storageList;
	}	
	
	public List<OasSummary> getOasList(){
		if(null == oasList){
			oasList = new ArrayList<OasSummary>();
		}
		return oasList;
	}		
	
	public HealerSummary getHealer(){
		if(null == healer){
			healer = new HealerSummary();
		}
		return healer;
	}
	
	public String toString(){
		
		StringBuffer sb = new StringBuffer();
		sb.append("DataStorageSummary:").append("\n");
		if(null != dataStorageList){
			for(DataStorageSummary ds : dataStorageList){
				sb.append(ds).append("\n");
			}
		}
		
		sb.append("StorageSummary:").append("\n");
		if(null != storageList){
			for(StorageSummary ss : storageList){
				sb.append(ss).append("\n");
			}
		}
		
		sb.append("OasSummary:").append("\n");
		if(oasList != null){
			for(OasSummary oas : oasList){
				sb.append(oas).append("\n");
			}
		}
		sb.append("HealerSummary:").append("\n");
		if(null != healer){
			sb.append(healer);
		}
		
		return sb.toString();
		
	}
}
