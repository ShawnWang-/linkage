package com.onest.handlers;


import com.onest.http.HttpResponse;
import com.onest.metainfo.OnestObject;

/**
 * Onest HTTP response handler that knows how to pull Onest object content and
 * metadata out of an HTTP response and unmarshall it into an OnestObject object.
 */
public class OnestObjectResponseHandler extends
		AbstractOnestResponseHandler<OnestObject> {

	 /**
     * @see com.onest.handlers.HttpResponseHandler#handle(com.onest.http.HttpResponse)
     */
    public OnestWebServiceResponse<OnestObject> handle(HttpResponse response) throws Exception {
        /*
         * TODO: It'd be nice to set the bucket name and key here, but the
         *       information isn't easy to pull out of the response/request
         *       currently.
         */
        OnestObject object = new OnestObject();
        object.setObjectContent(response.getContent());
        populateObjectMetadata(response, object.getObjectMetadata());

        OnestWebServiceResponse<OnestObject> onestResponse = parseResponseMetadata(response);
        onestResponse.setResult(object);
        return onestResponse;
    }

    /**
     * Returns true, since the entire response isn't read while this response
     * handler handles the response. This enables us to keep the underlying HTTP
     * connection open, so that the caller can stream it off.
     *
     * @see com.onest.handlers.HttpResponseHandler#needsConnectionLeftOpen()
     */
    @Override
    public boolean needsConnectionLeftOpen() {
        return true;
    }

}
