package com.onest.metainfo;

import java.io.InputStream;

/**
 * Represents an object stored in Onest. This object contains 
 * the data content
 * and the object metadata stored by Onest, such as content type,
 * content length, etc.
 * 
 * @see ObjectMetadata
 */
public class OnestObject {
    private static final long serialVersionUID = -2883501141593631181L;

    /** The key under which this object is stored */
    private String key = null;
    
    /** The name of the bucket in which this object is contained */
    private String bucketName = null;
    
    /** The metadata stored by Onest for this object */
    private ObjectMetadata metadata = new ObjectMetadata();

    /** The stream containing the contents of this object from Onest */
    private InputStream objectContent;


    /**
     * Gets the metadata stored by Onest for this object. The
     * {@link ObjectMetadata} object includes any custom user metadata supplied by the
     * caller when the object was uploaded, as well as HTTP metadata such as
     * content length and content type.
     * 
     * @return The metadata stored by Onest for this object.
     * 
     * @see OnestObject#getObjectContent()
     */
    public ObjectMetadata getObjectMetadata() {
        return metadata;
    }

    /**
     * Gets an input stream containing the contents of this object. Callers
     * should close this input stream as soon as possible, because the
     * object contents aren't buffered in memory and stream directly from
     * Onest.
     * 
     * @return An input stream containing the contents of this object.
     * 
     * @see OnestObject#getObjectMetadata()
     * @see OnestObject#setObjectContent(InputStream)
     */
    public InputStream getObjectContent() {
        return objectContent;
    }

    /**
     * Sets the input stream containing this object's contents.
     * 
     * @param objectContent
     *            The input stream containing this object's contents.
     *            
     * @see OnestObject#getObjectContent()        
     */
    public void setObjectContent(InputStream objectContent) {
        this.objectContent = objectContent;
    }

    /**
     * Gets the name of the bucket in which this object is contained.
     * 
     * @return The name of the bucket in which this object is contained.
     * 
     * @see OnestObject#setBucketName(String)     
     */
    public String getBucketName() {
        return bucketName;
    }

    /**
     * Sets the name of the bucket in which this object is contained.
     * 
     * @param bucketName
     *            The name of the bucket containing this object.
     *            
     * @see OnestObject#getBucketName()      
     */
    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    /**
     * Gets the key under which this object is stored.
     * 
     * @return The key under which this object is stored.
     * 
     * @see OnestObject#setKey(String)
     */
    public String getKey() {
        return key;
    }

    /**
     * Sets the key under which this object is stored.
     * 
     * @param key
     *            The key under which this object is stored.
     *            
     * @see OnestObject#getKey()           
     */
    public void setKey(String key) {
        this.key = key;
    }
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString() {
        return "OnestObject [key=" + getKey() 
            + ",bucket=" + (bucketName == null ? "<Unknown>" : bucketName)  
            + "]";
    }
}
