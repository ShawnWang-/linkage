package com.onest.auth;

public class MyOnestCredentials implements OnestCredentials {

    private final String accessID;
    private final String accessSecretKey;

    public MyOnestCredentials(String accessID, String accessSecretKey){
        this.accessID = accessID;
        this.accessSecretKey = accessSecretKey;
    }
    
	@Override
	public String getOnestAccessID() {
		// TODO Auto-generated method stub
		return accessID;
	}

	@Override
	public String getOnestAccessSecretKey() {
		// TODO Auto-generated method stub
		return accessSecretKey;
	}

}
