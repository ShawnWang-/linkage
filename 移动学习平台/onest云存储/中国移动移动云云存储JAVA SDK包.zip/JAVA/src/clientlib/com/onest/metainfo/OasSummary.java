
package com.onest.metainfo;

public class OasSummary{
	
	private String hostName;
	
	public String getHostName(){
		return hostName;
	}
	
	public void setHostName(String hostName){
		this.hostName = hostName;
	}
	
	public String toString(){
		StringBuffer sb = new StringBuffer();
		sb.append("hostName=").append(hostName);
		return sb.toString();
	}
}