package com.onest.metainfo;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "bucketStat")
public class BucketStat{
	
	private String userID;
	private String bucketName;
	private long spaceSize;
	private long objectNum;

	/**
	 * @return
	 */
	public String getUserID(){
		return userID;
	}
	
	/**
	 * @param userID
	 */
	public void setUserID(String userID){
		this.userID = userID;
	}
	
	/**
	 * @return
	 */
	public String getBucketName(){
		return bucketName;
	}
	
	/**
	 * @param bucketName
	 */
	public void setBucketName(String bucketName){
		this.bucketName = bucketName;
	}
	
	/**
	 * @return
	 */
	public long getSpaceSize(){
		return spaceSize;
	}
	
	/**
	 * @param spaceSize
	 */
	public void setSpaceSize(long spaceSize){
		this.spaceSize = spaceSize;
	}
	
	/**
	 * @return
	 */
	public long getObjectNum(){
		return objectNum;
	}
	
	/**
	 * @param objectNum
	 */
	public void setObjectNum(long objectNum){
		this.objectNum = objectNum;
	}
	
	public String toString(){
		StringBuffer sb = new StringBuffer();
		sb.append("[userID=").append(userID)
		.append(", bucketName=").append(bucketName)
		.append(", spaceSize=").append(spaceSize)
		.append(", objectNum=").append(objectNum).append("]");
		return sb.toString();
	}
	
}