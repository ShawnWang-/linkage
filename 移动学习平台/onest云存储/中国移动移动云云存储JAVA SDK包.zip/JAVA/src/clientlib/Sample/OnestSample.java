
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import com.onest.auth.PropertiesCredentials;
import com.onest.client.Onest;
import com.onest.client.OnestClientException;
import com.onest.client.OnestClientFactory;
import com.onest.client.OnestServiceException;
import com.onest.metainfo.AccessControlList;
import com.onest.metainfo.Bucket;
import com.onest.metainfo.CannedAccessControlList;
import com.onest.metainfo.CanonicalGrantee;
import com.onest.metainfo.CompleteMultipartUploadResult;
import com.onest.metainfo.CopyObjectResult;
import com.onest.metainfo.Grantee;
import com.onest.metainfo.InitiateMultipartUploadResult;
import com.onest.metainfo.MultipartUpload;
import com.onest.metainfo.MultipartUploadListing;
import com.onest.metainfo.ObjectListing;
import com.onest.metainfo.ObjectMetadata;
import com.onest.metainfo.OnestObject;
import com.onest.metainfo.OnestObjectSummary;
import com.onest.metainfo.Owner;
import com.onest.metainfo.PartETag;
import com.onest.metainfo.PartListing;
import com.onest.metainfo.PartSummary;
import com.onest.metainfo.Permission;
import com.onest.metainfo.UploadPartResult;
import com.onest.request.AbortMultipartUploadRequest;
import com.onest.request.CompleteMultipartUploadRequest;
import com.onest.request.CopyObjectRequest;
import com.onest.request.GetObjectMetadataRequest;
import com.onest.request.GetObjectRequest;
import com.onest.request.InitiateMultipartUploadRequest;
import com.onest.request.ListMultipartUploadsRequest;
import com.onest.request.ListObjectsRequest;
import com.onest.request.ListPartsRequest;
import com.onest.request.PutObjectRequest;
import com.onest.request.UploadPartRequest;

/**
 * This sample demonstrates how to make basic requests to Onest using
 * the Onest SDK for Java.
 * <p>
 * <b>Prerequisites:</b> You must have a valid Onest Web Services developer
 * account, and be signed up to use Onest. 
 * <p>
 * <b>Important:</b> Be sure to fill in your Onest access credentials in the
 *                   OnestCredentials.properties file before you try to run this
 *                   sample.
 */

public class OnestSample {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
         /*
         * Important: Be sure to fill in your Onest access credentials in the
         *            OnestCredentials.properties file before you try to run this
         *            sample. Or default, as anonymous, no need to be authentication
         */
		Onest onest1 = null;
        OnestClientFactory ocf = OnestClientFactory.getInstance();
        PropertiesCredentials onestProperites = new PropertiesCredentials(OnestSample.class.getResourceAsStream("OnestCredentials.properties"));
        ocf.setFactoryInfo(onestProperites, onestProperites.getOnestHostAddr());
        //Onest onest = new OnestClient("10.24.1.44:48080");
        //System.out.println("Start ANONYMOUS Access!");
        //onest.getObject(new GetObjectRequest("test11bk", "test"));
        //System.out.println("End ANONYMOUS Access!");
        //ocf.setFactoryInfo(onestProperites, "10.24.1.45:18080");
        
//        onest = new OnestClient(new PropertiesCredentials(
//				OnestSample.class.getResourceAsStream("OnestCredentials.properties")),
//				"10.24.1.46:18080"); //AAA address

        
        String bucketName = onestProperites.getOnestBucketName();
        String key = onestProperites.getOnestObjectKey();
        String userName = onestProperites.getUserName();
        String bucketAclUser1 = onestProperites.getOnestBucketAclUser1();
        String bucketAclUser2 = onestProperites.getOnestBucketAclUser2();
        
        boolean isIntraAddr = false;
        boolean isIntraSrvLocation = false;
        if(onestProperites.getIsIntraAddr() != null)
        	isIntraAddr = onestProperites.getIsIntraAddr().equals("true")?true:false;
        if(onestProperites.getIsIntraSvrAddr() != null)
        	isIntraSrvLocation = onestProperites.getIsIntraSvrAddr().equals("true")?true:false;
        
        try {
        	
        	//bucket op        	
        	onest1 = ocf.getLocation(!isIntraAddr,isIntraSrvLocation);
        	
        	//1 create bucket
        	System.out.println("=====================Test Case 1: creating bucket start=========================\n");
        	System.out.println("Try creating bucket " + bucketName + "......\n");
        	if(onest1.createBucket(bucketName) != null){
        		System.out.println("Creating bucket " + bucketName + " sucess!\n");
        	}
        	else {
        		System.out.println("Creating bucket " + bucketName + " failed!\n");        		
			}
        	System.out.println("=====================Test creating bucket end===========================\n\n");
        	
        	//2 set bucket acl
        	System.out.println("=====================Test Case 2: setting bucket acl start=======================\n");        	
          	AccessControlList acl = new AccessControlList();
          	Owner own = new Owner();
          	own.setId(userName);
        	acl.setOwner(own);
        	Grantee grantee1 = new CanonicalGrantee(bucketAclUser1);
        	Grantee grantee2 = new CanonicalGrantee(bucketAclUser2);
        	
        	List<Permission> listPermission = new LinkedList<Permission>();
        	listPermission.add(Permission.Read);
        	listPermission.add(Permission.Write);
        	acl.grantPermission(grantee1, listPermission);
        	
        	List<Permission> listPermission2 = new LinkedList<Permission>();        	
        	listPermission2.add(Permission.Read);
        	listPermission2.add(Permission.Write);
        	acl.grantPermission(grantee2, listPermission2);
        	System.out.println("Try setting bucket acl: " + acl.toString() + "......\n");
        	onest1.setBucketAcl(bucketName, acl);
        	System.out.println("Setting bucket acl sucess!\n");
        	System.out.println("=====================Test setting bucket acl end=======================\n\n");
        	
        	//3 get bucket acl
        	System.out.println("=====================Test Case 3: getting bucket acl start=======================\n");
        	System.out.println("Try getting bucket acl......\n");
        	acl = onest1.getBucketAcl(bucketName);
            System.out.println("Get bucket acl: "+ acl.toString() + " sucess!\n");
           	System.out.println("=====================Test getting bucket acl end=======================\n\n");
           	
        	//4 list onest user's buckets
        	System.out.println("=====================Test Case 4: listing bucket start=======================\n");
            System.out.println("Try listing buckets......\n");
            for (Bucket bucket : onest1.listBuckets()) {
                System.out.println(" - " + bucket.getName()+", create time:" + bucket.getCreationDate());
            }
            System.out.println("List buckets sucess!\n");
            System.out.println("=====================Test listing bucket end=======================\n\n");
            
        	//5 put object to specific bucket
            System.out.println("=====================Test Case 5: putting object start=======================\n");
            System.out.println("Try uploading a new object: " + bucketName + "/" + key + " to Onest from a file......\n");
            
            InputStream inputStream = new FileInputStream(createSampleFile());
			ObjectMetadata objectMetadataPut=new ObjectMetadata();
			Map<String,String> userMetadata1=new HashMap<String,String>();
			userMetadata1.put("onest-meta-asdc", "testvalue");
			objectMetadataPut.setUserMetadata(userMetadata1);
			objectMetadataPut.addUserMetadata("onest-meta-asdc1", "testvalue");
			PutObjectRequest objRequest=new PutObjectRequest(bucketName, key, inputStream,objectMetadataPut);
			onest1.putObject(objRequest);  
            //onest1.putObject(new PutObjectRequest(bucketName, key+"test", createSampleFile()));
            System.out.println("Put object sucess!\n");
            System.out.println("=====================Test putting object end=======================\n\n");
            
            //6 Generate open url with register user
            System.out.println("=====================Test Case 6: Generate open url with register user start============\n");
        	URL openurl1 = onest1.getObjectAccessUrl(bucketName, key, System.currentTimeMillis()/1000+9999, false);
        	System.out.println("Generate open url with register user is: " + openurl1.toString());
            System.out.println("=====================Test Generate open url with register user end=======================\n\n");

            //7 Generate open url with anonymos user
            System.out.println("=====================Test Case 7: Generate open url with anonymos start==================\n");
            System.out.println("Set CMCC-OBS-ANONYMOUS-USERS acl start...");
            AccessControlList obj_acl = new AccessControlList();
			Grantee grantee = new CanonicalGrantee("CMCC-OBS-ANONYMOUS-USERS");
			Owner obj_own = new Owner();
			obj_own.setId(userName);
			obj_acl.setOwner(obj_own);
			obj_acl.grantPermission(grantee, Permission.Read);
			System.out.println("Try setting object acl " + obj_acl.toString() + "......\n");  
			onest1.setObjectAcl(bucketName, key, obj_acl);            

        	URL openurl = onest1.getObjectAccessUrl(bucketName, key, System.currentTimeMillis()/1000+9999, true);
        	onest1.setBAnonymousUser(false);//set the register user mode
        	
        	System.out.println("Generate open url with anonymos user is: " + openurl.toString());
            System.out.println("=====================Test Generate open url with anonymos end=======================\n\n");
            
            //8 Getting object meta
            System.out.println("=====================Test Case 8: getting object meta start=======================\n");
            System.out.println("Try getting file metadata info......\n");
            GetObjectMetadataRequest getObjectMetadataRequest = new GetObjectMetadataRequest(bucketName, key);
            ObjectMetadata omd = onest1.getObjectMetadata(getObjectMetadataRequest);            
            Map<String, String> userMetadata = omd.getUserMetadata();             
            Iterator iter = userMetadata.entrySet().iterator(); 
            while (iter.hasNext()) { 
                Map.Entry entry = (Map.Entry) iter.next(); 
                Object key1 = entry.getKey(); 
                Object val = entry.getValue(); 
                System.out.println(" key: " + key1 +", val:" + val);
            } 
            System.out.println(omd.getContentType() + " " + omd.getContentLength() + " " 
            		+ omd.getETag() + " " + omd.getLastModified());
            System.out.println("=====================Test getting object meta end=======================\n\n");
            
            //9 Set object acl
            System.out.println("=====================Test Case 9: setting object acl start=======================\n");
            AccessControlList object_acl = new AccessControlList();
            object_acl.setOwner(own);
            object_acl.grantPermission(grantee1, Permission.Read);
            object_acl.grantPermission(grantee2, Permission.Write);
          	System.out.println("Try setting object acl " + object_acl.toString() + "......\n");          	
            onest1.setObjectAcl(bucketName, key, object_acl);
        	System.out.println("Setting object acl sucess!\n");
        	System.out.println("=====================Test setting object acl end=======================\n\n");
          
        	//10 get object acl
        	System.out.println("=====================Test Case 10: getting object acl start=======================\n");
        	System.out.println("Try getting object acl......\n");
        	obj_acl = onest1.getObjectAcl(bucketName, key);
            System.out.println("Get bucket acl: "+ obj_acl.toString() + " sucess!\n");
           	System.out.println("=====================Test getting object acl end=======================\n\n");

        	//11 get whole object file
        	System.out.println("=====================Test Case 11: getting object start=======================\n");
            System.out.println("Try downloading an object: " + bucketName + "/" + key + " from Onest......\n");
            OnestObject object = onest1.getObject(new GetObjectRequest(bucketName, key).withRange(0, 1));
            System.out.println("Content-Type: "  + object.getObjectMetadata().getContentType());
            displayTextInputStream(object.getObjectContent());
            System.out.println("Get object sucess!\n");
           	System.out.println("=====================Test getting object end=======================\n\n");

            //12 set object attribute
           	System.out.println("=====================Test Case 12: setting object meta start=======================\n");
            ObjectMetadata objMetadata = new ObjectMetadata();
            Map<String, String> userMeta = objMetadata.getUserMetadata();
            userMeta.put("description", "good!");
            System.out.println("Try Setting obeject meta......\n");
            onest1.setObjectMetadata(bucketName, key, objMetadata);
            System.out.println("Seting object meta sucess!\n");
           	System.out.println("=====================Test setting object meta end=======================\n\n");

        	//13 get all objects in the specfic bucket
           	System.out.println("=====================Test Case 13: listing object start=======================\n");
            System.out.println("Try listing objects......\n");
            ObjectListing objectListing = onest1.listObjects(new ListObjectsRequest()
                    .withBucketName(bucketName)
                    .withMaxResult(1));
            List<OnestObjectSummary> objList = objectListing.getObjectSummaries();
            for (OnestObjectSummary objectSummary : objList) {
                System.out.println(" - " + objectSummary.getKey() + "  " +
                                   "(size = " + objectSummary.getSize() + ")");
            }
            System.out.println("=====================Test listing object end=======================\n\n");
            
            //14 get User Space Stat
            System.out.println("=====================Test Case 14: getUserStat start=======================\n");
            System.out.println(ocf.getUserStat(userName).toString());
            System.out.println("=====================Test getUserStat end=======================\n\n");

            //15 get Bucket Space Stat
            System.out.println("=====================Test Case 15: getBucketStat start=======================\n");
            System.out.println(ocf.getBucketStat(bucketName));
            System.out.println("=====================Test getBucketStat end=======================\n\n");
        	
        	//16 delete the specific object 
            System.out.println("=====================Test Case 16: deleting object start=======================\n");
            System.out.println("Try deleting objects " + bucketName + "/" + key + "......\n");
            onest1.deleteObject(bucketName, key);
            System.out.println("Delete object sucess!\n");            
            System.out.println("=====================Test deleting object end=======================\n\n");
                   
        	//17 init mulitiupload part
            System.out.println("=====================Test Case 17: init mulitiupload part start=======================\n");
            CannedAccessControlList cacl = CannedAccessControlList.PublicRead;
            InitiateMultipartUploadRequest initiateMultipartUploadRequest = new InitiateMultipartUploadRequest(bucketName, key).withCannedACL(cacl);
            initiateMultipartUploadRequest.setCopyPolicy("AZ1:3;AZ2:3;");
            InitiateMultipartUploadResult result = onest1.initiateMultipartUpload(initiateMultipartUploadRequest);
            System.out.println(result.getBucketName() + " " + result.getKey() + " " + result.getUploadId()  );
            System.out.println("=====================Test init mulitiupload part end=======================\n\n");
           
        	//18 abort mulitiupload part
            System.out.println("=====================Test Case 18: abort mulitiupload part start=======================\n");
            AbortMultipartUploadRequest abortMultipartUploadRequest = new AbortMultipartUploadRequest(bucketName, key, result.getUploadId());
            onest1.abortMultipartUpload(abortMultipartUploadRequest);
            System.out.println("=====================Test abort mulitiupload part end=======================\n\n");
            
        	//19 re init mulitiupload part
            System.out.println("=====================Test Case 19: re init mulitiupload part start=======================\n");
            result = onest1.initiateMultipartUpload(initiateMultipartUploadRequest);
            System.out.println(result.getBucketName() + " " + result.getKey() + " " + result.getUploadId()  );
            System.out.println("=====================Test re init mulitiupload part end=======================\n\n");
                                    
            //20 upload mulitiupload part
            System.out.println("=====================Test Case 20: upload mulitiupload part start=======================\n");
            final long contentLength = 135;//file.length();
            long partSize = contentLength;
            System.out.println("OnestSample.java: " + contentLength + " " + partSize  );            
            UploadPartRequest uploadPartRequest = new UploadPartRequest().withBucketName(bucketName).withKey(key).
            											withFile(createSampleFile()).
            											withUploadId(result.getUploadId()).withPartNumber(1).
            											withPartSize(partSize).withFileOffset(0);            
            UploadPartResult uploadPartResult = onest1.uploadPart(uploadPartRequest);
            System.out.println(uploadPartResult.getETag() + " " + uploadPartResult.getPartNumber());
            System.out.println("=====================Test upload mulitiupload part end=======================\n\n");
            
            //21 list uploaded parts
            System.out.println("=====================Test Case 21: list uploaded parts start=======================\n");
            ListPartsRequest listPartsRequest = new ListPartsRequest(bucketName, key, result.getUploadId());
            PartListing partListing = onest1.listParts(listPartsRequest);
            System.out.println(partListing.getBucketName() + " " + partListing.getKey()
            					+ " " + partListing.getUploadId() + " "+partListing.getMaxParts() 
            					+ " " + partListing.getNextPartNumberMarker() + " "+ partListing.getPartNumberMarker()
            					+ " " + partListing.getParts() + " " + partListing.getOwner());
            System.out.println("=====================Test list uploaded parts end=======================\n\n");
            
            //22 list mulitipart uploads
            System.out.println("=====================Test Case 22: list mulitipart uploads start=======================\n");
            System.out.println("listMultipartUploads start....");
            ListMultipartUploadsRequest listMultipartUploadsRequest = new ListMultipartUploadsRequest(bucketName);
            MultipartUploadListing multipartUploadListing = onest1.listMultipartUploads(listMultipartUploadsRequest);
            System.out.println(multipartUploadListing.getBucketName() + " " + multipartUploadListing.getKeyMarker()
					+ " " + multipartUploadListing.getMaxUploads() + " "+multipartUploadListing.getNextKeyMarker() 
					+ " " + multipartUploadListing.getNextUploadIdMarker() + " "+ multipartUploadListing.getUploadIdMarker());            
            List<MultipartUpload> multipartUploads = multipartUploadListing.getMultipartUploads();
            for (MultipartUpload multipartUpload : multipartUploads) {
                System.out.println(" key: " + multipartUpload.getKey() + "  " +
                                   "uploadId = " + multipartUpload.getUploadId() + 
                                   "data = " + multipartUpload.getInitiated() );
            }
            System.out.println("=====================Test list mulitipart uploads end=======================\n\n");
                        
            //23 complete mulitiupload part
            System.out.println("=====================Test Case 23: complete mulitiupload part start=======================\n");
            List<PartSummary> partSummariesList = partListing.getParts();
            List<PartETag> partETags = new ArrayList<PartETag>();
            PartETag partETag = new PartETag(1, partSummariesList.get(0).getETag());
            partETags.add(partETag);          
            CompleteMultipartUploadRequest completeMultipartUploadRequest = new CompleteMultipartUploadRequest(bucketName, key, result.getUploadId(), partETags);
            CompleteMultipartUploadResult completeMultipartUploadResult = onest1.completeMultipartUpload(completeMultipartUploadRequest);
            System.out.println(completeMultipartUploadResult.getBucketName() + " " + completeMultipartUploadResult.getKey()
					+ " " + completeMultipartUploadResult.getETag() + " "+completeMultipartUploadResult.getLocation() 
					+ " " + completeMultipartUploadResult.getVersionId());
            System.out.println("=====================Test complete mulitiupload part end=======================\n\n");

            //24 copy a specific object from specific bucket to another bucket,currently not support 
//            System.out.println("=========Test Case 24: copy a specific object from specific bucket to another bucket start==========\n");
//            System.out.println("copy an object\n");
//            CannedAccessControlList cannedACL = CannedAccessControlList.Private;
//            CopyObjectRequest copyObjectRequest = new CopyObjectRequest(bucketName, key, "mybucket0", key).withCannedAccessControlList(cannedACL);
//            CopyObjectResult copyObjectResult = onest1.copyObject(copyObjectRequest);
//            System.out.println(copyObjectResult.getETag());
//            System.out.println("=========Test copy a specific object from specific bucket to another bucket end=================\n\n");

            //25 get specific range part of an object 
            System.out.println("================Test Case 25: get specific range part of an object start===============\n");
            onest1.getObject(new GetObjectRequest(bucketName, key).withRange(0, 100));
            System.out.println("Content-Type: "  + object.getObjectMetadata().getContentType()
            					+ "ETag: " + object.getObjectMetadata().getETag());
            displayTextInputStream(object.getObjectContent());
            System.out.println("=====================Test get specific range part of an object end=======================\n\n");
			
            //26 get the specific object's metadata part 
            System.out.println("=================Test Case 26: get the specific object's metadata part start===============\n");
            GetObjectMetadataRequest getObjectMetadataRequest1 = new GetObjectMetadataRequest(bucketName, key);
            ObjectMetadata omd1 = onest1.getObjectMetadata(getObjectMetadataRequest1);            
            Map<String, String> userMetadata11 = omd1.getUserMetadata();             
            Iterator iter1 = userMetadata11.entrySet().iterator(); 
            while (iter1.hasNext()) { 
                Map.Entry entry = (Map.Entry) iter1.next(); 
                Object key1 = entry.getKey(); 
                Object val = entry.getValue(); 
                System.out.println(" key: " + key1 +", val:" + val);
            } 
            System.out.println(omd1.getContentType() + " " + omd1.getContentLength() + " " 
            		+ omd1.getETag() + " " + omd1.getLastModified());
            System.out.println("=====================Test get the specific object's metadata part end=======================\n\n");
            
            //27 delete the multiuploaded object
            System.out.println("=====================Test Case 27: delete the multiuploaded object start=====================\n");
            System.out.println("Deleting an multiuploaded object\n");
            onest1.deleteObject(bucketName, key);
            System.out.println("=====================Test delete the multiuploaded object end=======================\n\n");
            
            //28 get all objects in the specfic bucket
           	System.out.println("=====================Test Case 28: listing object start=======================\n");
            System.out.println("Try listing objects......\n");
            objectListing = onest1.listObjects(new ListObjectsRequest()
                    .withBucketName(bucketName)
                    .withMaxResult(1));
            objList = objectListing.getObjectSummaries();
            for (OnestObjectSummary objectSummary : objList) {
                System.out.println(" - " + objectSummary.getKey() + "  " +
                                   "(size = " + objectSummary.getSize() + ")");
            }
            System.out.println("=====================Test listing object end=======================\n\n");
            
            
            //29 delete the specific bucket
            System.out.println("=====================Test Case 29: deleting bucket start=======================\n");
            System.out.println("Try deleting bucket " + bucketName + "......\n");
            onest1.deleteBucket(bucketName);
            System.out.println("Delete bucket sucess!\n");            
            System.out.println("=====================Test deleting bucket end=======================\n\n");

            System.out.println("Congratulations! All java sdk restful interface test sucess!!!\n\n");
			
        } catch (OnestServiceException ose) {
            System.out.println("Caught an OnestServiceException, which means your request made it "
                    + "to Onest, but was rejected with an error response for some reason.");
            System.out.println("Error Message:    " + ose.getMessage());
            System.out.println("HTTP Status Code: " + ose.getStatusCode());
            System.out.println("Onest Error Code:   " + ose.getErrorCode());
            System.out.println("Error Type:       " + ose.getErrorType());
            System.out.println("Request ID:       " + ose.getRequestId());

//            AccessControlList obj_acl = new AccessControlList();
//            Grantee grantee = new CanonicalGrantee("CMCC-OBS-ANONYMOUS-USERS");
//          	Owner obj_own = new Owner();
//          	obj_own.setId(userName);
//          	obj_acl.setOwner(obj_own);
//          	obj_acl.grantPermission(grantee, Permission.Read);
//          	System.out.println("Try setting object acl " + obj_acl.toString() + "......\n");  
//          	onest1.setBAnonymousUser(false);
//            onest1.setObjectAcl(bucketName, key, obj_acl);            
//            onest1.getObjectAccessUrl(bucketName, key, System.currentTimeMillis()/1000+9999, true);
            
        } catch (OnestClientException oce) {
            System.out.println("Caught an OnestClientException, which means the client encountered "
                    + "a serious internal problem while trying to communicate with Onest, "
                    + "such as not being able to access the network.");
            System.out.println("Error Message: " + oce.getMessage());
        }
    }

    /**
     * Creates a temporary file with text data to demonstrate uploading a file
     * to Onest
     *
     * @return A newly created temporary file with text data.
     *
     * @throws IOException
     */
    private static File createSampleFile() throws IOException {
        File file = File.createTempFile("onest-sample-", ".txt");
        file.deleteOnExit();

        Writer writer = new OutputStreamWriter(new FileOutputStream(file));
        writer.write("abcdefghijklmnopqrstuvwxyz\n");
        writer.write("01234567890112345678901234\n");
        writer.write("!@#$%^&*()-=[]{};':',.<>/?\n");
        writer.write("01234567890112345678901234\n");
        writer.write("abcdefghijklmnopqrstuvwxyz\n");
        writer.close();

        return file;
    }

    /**
     * Displays the contents of the specified input stream as text.
     *
     * @param input
     *            The input stream to display as text.
     *
     * @throws IOException
     */
    private static void displayTextInputStream(InputStream input) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(input));
        while (true) {
            String line = reader.readLine();
            if (line == null) break;

            System.out.println("    " + line);
        }
        System.out.println();
    }
	

}
