﻿#imagemagick----------------------------------------------------------------------------------------------------------------------------------------------------------
#yum install rabbitmq

yum install freetype freetype-devel zlib zlib-devel  libpng libpng-devel libjpeg libjpeg-devel libtiff libtiff-devel

wget http://www.imagemagick.org/download/ImageMagick.tar.gz

tar xvfz ImageMagick.tar.gz 
cd ImageMagick-6.8.9-4/
./configure
make;make install
ldconfig /usr/local/lib
make check

#eupel----------------------------------------------------------------------------------------------------------------------------------------------------------

#eupel
www.rackspace.com/knowledge_center/article/installing-rhel-epel-repo-on-centos-5x-or-6x

ls -1 /etc/yum.repos.d/epel* /etc/yum.repos.d/remi.repo /etc/yum.repos.d/epel.repo /etc/yum.repos.d/epel-testing.repo /etc/yum.repos.d/remi.repo



#yum install memcached----------------------------------------------------------------------------------------------------------------------------------------------------------
chkconfig --level 2345 memcached on

#rabbitmq install--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#yum install rabbitmq
http://my.oschina.net/indestiny/blog/192313

// 安装预环境
yum install gcc gcc-c++
yum install zlib zlin-devel
// 替换系统默认python2.6-->2.7
下载并解压：http://www.python.org/ftp/python/2.7.6/Python-2.7.6.tgz
cd Python-2.7.6
// 配置安装目录
./configure --prefix=/usr/local/python27
// 编译&&安装
make && make install
// 废弃旧python
mv /usr/bin/python /usr/bin/python2.6.6.old 
// 建立新版本python链接
ln -s /usr/bin/python2.6.6.old /usr/bin/python2.6
// 于是现在python -V:
Python 2.7.6
ln -s /usr/local/python27/bin/python /usr/bin/python
// 修改yum脚本的声明头: /usr/bin/yum

/usr/bin/python ----> /usr/bin/python2.6
// Erlang 安装
yum -y install make gcc gcc-c++ kernel-devel m4 ncurses-devel openssl-devel

// 下载Erlang:http://www.erlang.org/download/otp_src_R16B02.tar.gz，解压
// 配置安装
 ./configure --prefix=/usr/local/erlang --with-ssl -enable-threads -enable-smmp-support -enable-kernel-poll --enable-hipe --without-javac
// 编译安装
make && make install
// 配置环境变量, vim /etc/profile, 添加:
ERLANG_HOME=/usr/local/erlang
PATH=$ERLANG_HOME/bin:$PATH
export ERLANG_HOME
export PATH
source /etc/profile
输入命令erl检验是否安装成功
// rabbitmq-server安装:
// 依赖包xmlto
yum install xmlto
// 下载，解压之
http://www.rabbitmq.com/releases/rabbitmq-server/v3.1.5/rabbitmq-server-3.1.5.tar.gz
// 编译
make
// 安装
make install TARGET_DIR=/opt/rabbitmq SBIN_DIR=/opt/rabbitmq/sbin MAN_DIR=/opt/rabbitmq/man
安装web插件管理界面                                                                      
mkdir /etc/rabbitmq

RABBIT_HOME=/opt/rabbitmq/
PATH=$RABBIT_HOME/sbin:$PATH
export RABBIT_HOME
export PATH


rabbitmq-plugins enable rabbitmq_management
The following plugins have been enabled:
  mochiweb
  webmachine
  rabbitmq_web_dispatch
  amqp_client
  rabbitmq_management_agent
  rabbitmq_management
Plugin configuration has changed. Restart RabbitMQ for changes to take effect.
[root@rabbitmqmaster sbin]# ls /etc/rabbitmq
enabled_plugins
// 启动rabbitmq
rabbitmq-server start
// 有可能报主机名找不到的错误,
vim /etc/hosts
127.0.0.1 localhost ${hostName}
guest/guest 登录localhost:15672


#redis install--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


#yum install redis
http://ptylr.com/2013/08/15/installing-configuring-redis-in-centos-6/
Configuration of Redis
cd /home
curl http://dl.fedoraproject.org/pub/epel/6/x86_64/epel-release-6-8.noarch.rpm > epel-release-6-8.noarch.rpm
curl http://rpms.famillecollet.com/enterprise/remi-release-6.rpm > remi-release-6.rpm
rpm -Uvh remi-release-6*.rpm epel-release-6*.rpm
yum -y install redis
rm -f remi-release-6*.rpm epel-release-6*.rpm

#Finally, set the service to start on reboot, and start the Redis service:
chkconfig redis on
service redis start

Redis (by default) runs on TCP6379, with a Redis-specific protocol. To test that the installation has been successful:
redis-cli ping

If the result is ‘PONG’, installation is successful.

By default, Redis will bind itself to 127.0.0.1. This can be changed by amending the ‘bind’ directive in /etc/redis.conf. If you want it to listen on all interfaces, comment out the directive. Restart the Redis service for changes to take effect.

Additionally, if you want to enable a lightweight security layer on-top of Redis, you can add a client password. This is done by uncommenting the ‘requirepass’ line from within /etc/redis.conf, changing the password and restarting the Redis service.

#redis install--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


